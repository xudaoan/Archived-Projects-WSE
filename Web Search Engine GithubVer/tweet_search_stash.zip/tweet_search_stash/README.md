REAL TIME SEARCH ENGINE FOR TWITTER
===================================

How to RUN
----------
**IMPORTANT**  
please use **JAVA 6**
*DO NOT* use *JAVA 7*

1. install 3rd party jar  
    `./install_lib.sh`
2. start indexer  
    `./run_indexer.sh`  
3. start search engine  
    `./start_search_engine.sh`	
4. open your browser  
    `http://localhost:9090/tweet_search`  
and *enjoy*

Check Our Code
--------------

### ExpFileSystem
`src/main/java/tweet_search/search/index/persistent/BlockFileByteWriter.java`  
`src/main/java/tweet_search/search/index/persistent/BlockFileReverseReader.java`  

We also have a unit test for our ExpFile System:  
`/src/test/java/tweet_search/search/index/persistent/BlockFileByteWriterTest.java`  

### Ranking Algorithm
`/tweet_search/search/SearchEngine.java`  
Please refer to doSearch method line `50` to check the ranking algorithm
