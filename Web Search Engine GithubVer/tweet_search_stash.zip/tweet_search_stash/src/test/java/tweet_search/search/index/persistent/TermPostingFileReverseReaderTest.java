package tweet_search.search.index.persistent;

import junit.framework.Assert;
import org.junit.Test;
import tweet_search.search.index.TweetPosting;

import java.io.File;
import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/26/13
 * Time: 4:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class TermPostingFileReverseReaderTest {

  @Test
  public void testWriteAndReadTermPostingList() throws IOException {
    File indexFolder = new File("tmp/termIndex/");
    indexFolder.mkdirs();
    File postingFile = new File(indexFolder, "me.idx");
    postingFile.delete();

    TweetPosting[] postings = new TweetPosting[]{
            getPosting(1000, 3, 2, 1),
            getPosting(1001, 3, 2, 1),
            getPosting(1002, 3, 2, 1),
            getPosting(1009, 2, 1)
    };

    shouldReadAndWritePostings(postings, postingFile);


  }

  private void shouldReadAndWritePostings(TweetPosting[] postings, File postingFile) throws IOException {
    TermPostingFileWriter writer = new TermPostingFileWriter(postingFile);
    for (TweetPosting p : postings) {
      writer.appendPosting(p);
    }

    TermPostingFileReverseReader reader = new TermPostingFileReverseReader(postingFile);
    reader.seekToEndOfFile();

    for (int i = postings.length - 1; i >= 0; i--) {
      Assert.assertEquals(postings[i].toString(), reader.nextPosting().toString());
    }
  }

  TweetPosting getPosting(long id, int... occurs) {
    TweetPosting posting = new TweetPosting(id);
    for (int occur : occurs) {
      posting.addOccurrence(occur);
    }
    return posting;
  }
}
