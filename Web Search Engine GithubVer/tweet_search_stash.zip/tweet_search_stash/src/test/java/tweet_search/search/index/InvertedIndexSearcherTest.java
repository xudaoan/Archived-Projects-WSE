package tweet_search.search.index;

import junit.framework.Assert;
import org.junit.Test;
import tweet_search.search.Constants;
import tweet_search.search.index.persistent.IndexHeadsDAO;
import tweet_search.search.index.persistent.InvertedIndexSingleFile;
import tweet_search.corpus.TweetsDAO;
import tweet_search.search.index.memory.IndexBuilderImpl;
import tweet_search.search.index.memory.InvertedIndexInMemory;
import tweet_search.corpus.TweetsDAOInMemory;
import tweet_search.search.index.persistent.InvertedIndexInDisk;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.json.DataObjectFactory;

import java.io.*;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 4:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvertedIndexSearcherTest {
  @Test
  public void testSeachTweetsInMemory() throws Exception {
    InvertedIndexInMemory index=new InvertedIndexInMemory();
    TweetsDAO tweetsDAO=new TweetsDAOInMemory();
    IndexBuilderImpl builder=new IndexBuilderImpl(index);
    InvertedIndexSearcher invertedIndexSearcher=new InvertedIndexSearcher(index,tweetsDAO);

    loadTweets(builder,tweetsDAO);

    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"RT"},0);//RT is removed from tweets
    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"day"},1);
    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"me"},4);
    Assert.assertEquals("Out of uni... Such a long tiring day",invertedIndexSearcher.nextTweetByTerms(new String[]{"day", "such", "such"}, Constants.INFINITY_ID).getStatus().getText());
    Assert.assertEquals("Out of uni... Such a long tiring day",invertedIndexSearcher.nextTweetByPhrase(new String[]{"tiring", "day"},Constants.INFINITY_ID).getText());
  }

  @Test
  public void testSeachTweetsWithIndexInDisk() throws Exception {
    File indexFolder=new File("tmp/searchIndex/");
    indexFolder.delete();
    indexFolder.mkdirs();

    InvertedIndexInDisk index=new InvertedIndexInDisk(indexFolder);
    TweetsDAO tweetsDAO=new TweetsDAOInMemory();
    IndexBuilderImpl builder=new IndexBuilderImpl(index);
    InvertedIndexSearcher invertedIndexSearcher=new InvertedIndexSearcher(index,tweetsDAO);

    loadTweets(builder,tweetsDAO);

//    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"RT"},17);
    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"day"},1);
    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"me"},4);
    Assert.assertEquals("Out of uni... Such a long tiring day",invertedIndexSearcher.nextTweetByTerms(new String[]{"day", "such", "such"}, Constants.INFINITY_ID).getStatus().getText());
    Assert.assertEquals("Out of uni... Such a long tiring day",invertedIndexSearcher.nextTweetByPhrase(new String[]{"tiring", "day"},Constants.INFINITY_ID).getText());
  }



  @Test
  public void testSeachTweetsWithIndexSingleFile() throws Exception {
    File indexFolder=new File("tmp/searchIndex/");
    indexFolder.delete();
    indexFolder.mkdirs();

    String headsPath = "tmp/sindgle_heads";
    new File(headsPath).delete();

//    IndexHeadsDAO heads=new IndexHeadsDAO(headsPath);
    InvertedIndexSingleFile index= new InvertedIndexSingleFile(new RandomAccessFile("tmp/single_index","rw").getChannel(),headsPath);
    TweetsDAO tweetsDAO=new TweetsDAOInMemory();
    IndexBuilderImpl builder=new IndexBuilderImpl(index);
    InvertedIndexSearcher invertedIndexSearcher=new InvertedIndexSearcher(index,tweetsDAO);


    loadTweets(builder,tweetsDAO);
    index.saveHeads();

//    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"RT"},17);
    shouldGetResultsOfSize(invertedIndexSearcher, new String[]{"day"}, 1);
    shouldGetResultsOfSize(invertedIndexSearcher,new String[]{"me"},4);
    Assert.assertEquals("Out of uni... Such a long tiring day",invertedIndexSearcher.nextTweetByTerms(new String[]{"day", "such", "such"}, Constants.INFINITY_ID).getStatus().getText());
    Status status = invertedIndexSearcher.nextTweetByPhrase(new String[]{"tiring", "day"}, Constants.INFINITY_ID);
    Assert.assertEquals("Out of uni... Such a long tiring day", status.getText());
  }

  private void loadTweets(IndexBuilderImpl builder,TweetsDAO tweetsDAO) throws Exception {
    FileFilter filter = new FileFilter() {
      @Override
      public boolean accept(File pathname) {
        return pathname.getName().endsWith(".json");
      }
    };

    for (File f :new File("fixture/small/").listFiles(filter)){
//      Status tweet= DataObjectFactory.createStatus(readFirstLine(f));
      IndexedStatus indexedStatus=tweetsDAO.addTweet(readFirstLine(f));
      builder.indexTweet(indexedStatus);
    }
  }

  private void shouldGetResultsOfSize(InvertedIndexSearcher invertedIndexSearcher, String[] words, int expectedCount) throws Exception {
    int  count=0;
    IndexedStatus tweet;
    long pos= Constants.INFINITY_ID;

    while((tweet=invertedIndexSearcher.nextTweetByTerms(words,pos))!=null){
//      System.out.println(tweet.getIndexID());
        Assert.assertTrue("ID should be in decreasing order",pos>tweet.getIndexID());
        pos=tweet.getIndexID();
//        System.out.println(tweet.getStatus().getText());

      count++;
    }
    Assert.assertEquals(expectedCount,count);
  }


  private static String readFirstLine(File fileName) throws IOException {
    FileInputStream fis = null;
    InputStreamReader isr = null;
    BufferedReader br = null;
    try {
      fis = new FileInputStream(fileName);
      isr = new InputStreamReader(fis, "UTF-8");
      br = new BufferedReader(isr);
      return br.readLine();
    } finally {
      if (br != null) {
        try {
          br.close();
        } catch (IOException ignore) {
        }
      }
      if (isr != null) {
        try {
          isr.close();
        } catch (IOException ignore) {
        }
      }
      if (fis != null) {
        try {
          fis.close();
        } catch (IOException ignore) {
        }
      }
    }
  }
}
