package tweet_search.search.index;

import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/26/13
 * Time: 3:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvertedIndexInDiskTest {
  @Test
  public void testAddPosting() throws Exception {

  }
}
