package tweet_search.search.index.persistent;

import org.junit.Test;
import tweet_search.io.NumberEncoder;
import tweet_search.io.ReverseNumberDecoder;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/29/13
 * Time: 5:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlockFileByteWriterTest {
  @Test
  public void help(){
    System.out.println(Integer.toBinaryString(768));
    System.out.println(Integer.toBinaryString(Integer.decode("0x7f")));
  }
  @Test
  public void testReadAndWriteNumberSeries() throws IOException {
    String filePath = "tmp/numbers_single_file";
    new File(filePath).delete();
    FileChannel fileChannel = new RandomAccessFile(filePath,"rw").getChannel();
    BlockFileByteWriter writer= BlockFileByteWriter.createNewBlockFileWriter(fileChannel);
    NumberEncoder encoder = new NumberEncoder(writer);
    BlockFileByteWriter writer2= BlockFileByteWriter.createNewBlockFileWriter(fileChannel);
    NumberEncoder encoder2 = new NumberEncoder(writer2);

    for(long i=0;i<10000;i++){
      encoder.writeNumber(i*3000);
      encoder2.writeNumber(i * 30000000000000L);
    }

    BlockFileReverseReader reader=new BlockFileReverseReader(new RandomAccessFile(filePath,"r").getChannel(),writer.position,writer.currentBlockStart);
    ReverseNumberDecoder decoder=new ReverseNumberDecoder(reader);

    BlockFileReverseReader reader2=new BlockFileReverseReader(new RandomAccessFile(filePath,"r").getChannel(),writer2.position,writer2.currentBlockStart);
    ReverseNumberDecoder decoder2=new ReverseNumberDecoder(reader2);

    while(decoder.hasPrevious()||decoder2.hasPrevious()){
      System.out.println(decoder.previousNumber()+"|"+decoder2.previousNumber());
//      System.out.println((reader.previousByte()&0x7f) +"|"+(reader2.previousByte()&0x7f));
    }

  }
}
