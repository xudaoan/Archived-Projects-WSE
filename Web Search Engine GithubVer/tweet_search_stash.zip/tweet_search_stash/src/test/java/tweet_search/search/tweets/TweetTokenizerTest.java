package tweet_search.search.tweets;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/28/13
 * Time: 6:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class TweetTokenizerTest {
  @Test
  public void testTokenize(){
   TweetTokenizer tokenizer= new TweetTokenizer();
    Map<Integer,String> posTokenMap=tokenizer.tokenize("Hi, @Apple: @苹果 you have the most...kkkk which worth 1000$!!! I have 3 days");
    System.out.println(posTokenMap);
//    tokenizer.tokenize("中文测试");
  }

  @Test
  public void testDivide(){
    System.out.println((-1)/5);
  }
}
