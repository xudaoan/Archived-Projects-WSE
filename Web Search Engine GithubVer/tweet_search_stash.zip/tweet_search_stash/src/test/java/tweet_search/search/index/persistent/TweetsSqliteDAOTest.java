package tweet_search.search.index.persistent;

import org.junit.Test;
import tweet_search.corpus.TweetJsonLoader;
import tweet_search.corpus.TweetsSqliteDAO;

import java.io.File;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/28/13
 * Time: 5:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class TweetsSqliteDAOTest {
  @Test
  public void testGetTweetByIndexID() throws Exception {
    String dbPath="tmp/db/smallDb.sqlite";
    new File(dbPath).getParentFile().mkdirs();
    new File(dbPath).delete();
    TweetsSqliteDAO dao=new TweetsSqliteDAO(dbPath);
    File jsonFolder=new File("fixture/small/");
    long id=0;
    for(File f:jsonFolder.listFiles()){
      if (!f.getName().endsWith(".json"))
        continue;
      System.out.println(dao.addTweet(TweetJsonLoader.getStringContent(f)));
    }

    System.out.println(dao.getTweetByIndexID(1).getText());

  }
}
