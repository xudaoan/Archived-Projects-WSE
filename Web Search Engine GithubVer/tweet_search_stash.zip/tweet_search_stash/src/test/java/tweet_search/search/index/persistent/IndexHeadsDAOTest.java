package tweet_search.search.index.persistent;

import org.junit.Test;

import java.io.File;
import java.util.Date;

import static java.lang.Thread.sleep;
import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/9/13
 * Time: 5:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class IndexHeadsDAOTest {
  @Test
  public void testSaveAndLoadLatestHeads() throws Exception {
    String dbPath="tmp/headsdb.sqlite";
    new File(dbPath).delete();
    IndexHeadsDAO heads=new IndexHeadsDAO(dbPath);
    heads.addHead("apple",1000L,900L,new Date("2010/01/01"));
    sleep(1);
    heads.addHead("apple",103L,500L,new Date("2019/01/01"));
    heads.flushInsert();
    assertEquals(103L,heads.getLatestPos("apple").position);
  }

  @Test
  public void testSaveAndLoadLatestHeadsByDate() throws Exception {
    String dbPath="tmp/headsdb.sqlite";
    new File(dbPath).delete();
    IndexHeadsDAO heads=new IndexHeadsDAO(dbPath);
    heads.addHead("apple",100L,90L,new Date("2010/01/01"));
    sleep(1);
    heads.addHead("apple",101L,90L,new Date("2019/01/01"));
    heads.addHead("apple",103L,90L,new Date("2019/01/03"));
    heads.addHead("apple",104L,90L,new Date("2019/01/04"));
    heads.flushInsert();
    assertEquals(103L,heads.getLatestPosByDate("apple",new Date("2019/01/02")));
    assertEquals(100L,heads.getLatestPosByDate("apple",new Date("2009/01/02")));
  }
}
