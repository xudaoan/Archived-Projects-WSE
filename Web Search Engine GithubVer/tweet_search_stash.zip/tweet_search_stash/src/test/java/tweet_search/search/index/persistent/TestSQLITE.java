//package tweet_search.search.index.persistent;
//
//import org.junit.Test;
//
//import java.sql.*;
//
///**
// * Created with IntelliJ IDEA.
// * User: tsdeng
// * Date: 5/12/13
// * Time: 12:39 PM
// * To change this template use File | Settings | File Templates.
// */
//public class TestSQLITE {
//
//  @Test
//  public void neverTrim() throws Exception {
//    Class.forName("org.sqlite.JDBC");
//    Connection conn = DriverManager.getConnection("jdbc:sqlite:" + "tmp/bigdb.sqlite");
//    Statement statement = conn.createStatement();
//    statement.execute("PRAGMA journal_mode=WAL;");
////    statement.execute("PRAGMA journal_size_limit=1000000;");
//    statement.close();
//    conn.setAutoCommit(false);
//
//    Statement stat = conn.createStatement();
//    stat.executeUpdate("create table if not exists HEADS (" +
//            "term VARCHAR(100)," +
//            "pos INTEGER, " +
////            "tweet_search TEXT, " +
////            "topic VARCHAR(50), " +
////            "sentiment VARCHAR(25), " +
//            "timestamp DATETIME);" +
////            "primary key (term,timestamp,pos));" +
//            "create index if not exists term_index on HEADS(term);" +
//            "create index if not exists time_index on HEADS(term,timestamp);");
//    stat.close();
//    conn.commit();
//
//
//    PreparedStatement insertStatement;
//
//    insertStatement = conn.prepareStatement(
//            "insert into HEADS(term,pos,timestamp) values (?,?,?);");
//
//    int batchCount = 0;
//    while (true) {
//      insertStatement.setString(1, "aaa");
//      insertStatement.setLong(2, 1000);
//      java.util.Date d = new java.util.Date();
//      insertStatement.setDate(3, new java.sql.Date(d.getTime()));
//      insertStatement.addBatch();
//      if (batchCount++ == 10000) {
//        insertStatement.executeBatch();
//        insertStatement.clearBatch();
////        insertStatement.close();
//        conn.commit();
//        batchCount=0;
//      }
//    }
//
//  }
//
//  @Test
//  public void haha()throws Exception{
//    IndexHeadsDAO dao=new IndexHeadsDAO("tmp/myheads.sqlite");
//    int count=0;
//    while(true){
//      String term=new Integer(count).toString();
//      dao.addHead(term,1000,new java.util.Date());
//      try{
//      dao.getLatestPos("aaa");}catch (IndexHeadsDAO.HeadNotFoundException e){
////        System.out.println("alright");
//      }
//      if(((count++)%10000)==0){
//        System.out.println("flushing");
//        dao.flushInsert();
////        count=0;
//      }
//    }
//  }
//}
