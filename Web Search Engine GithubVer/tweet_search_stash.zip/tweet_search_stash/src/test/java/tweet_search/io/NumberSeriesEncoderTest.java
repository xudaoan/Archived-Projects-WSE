package tweet_search.io;

import org.junit.Test;

import java.io.*;
import java.nio.channels.FileChannel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * TODO: cleanup tests
 */
public class NumberSeriesEncoderTest {
  String filePath = "tmp/numbers.bin";

  @Test
  public void testEncodeAndDecodeNumbers() throws IOException {
//      shouldBeAbleToEncodeAndDecode(new long[] {10L,9L,8L,7L,6L,5L,4L,3L,2L,1L});
      shouldBeAbleToEncodeAndDecode(new long[] {2147483649887776655L});

  }

  private void shouldBeAbleToEncodeAndDecode(long[] numbers) throws IOException {
    NumberSeriesEncoder encoder = new NumberSeriesEncoder(new FileOutputStream(filePath));
    for (long n : numbers) {
      encoder.put(n);
    }
    encoder.closeStream();
    printFile(filePath);
    RandomAccessFile randomAccessFile = new RandomAccessFile(filePath, "rw");
    FileChannel channel = randomAccessFile.getChannel();
    channel.position(channel.size());//notice: it's not channel.size()-1
    NumberSeriesReverseDecoder decoder = new NumberSeriesReverseDecoder(channel);
    for (int i = numbers.length - 1; i >= 0; i--) {
      assertTrue(decoder.hasNext());
      long number = decoder.next();
//      System.out.println(number);
      assertEquals(numbers[i], number);
    }
    assertFalse(decoder.hasNext());
  }

  private void printFile(String filePath) throws IOException {
    FileInputStream fs=new FileInputStream(filePath);
     int val;
    while(((val=fs.read())!=-1)){
//      System.out.println(Integer.toBinaryString(val));
    }
  }

}

