package tweet_search.search.index;

import org.codehaus.jackson.annotate.JsonIgnore;

import tweet_search.search.analysis.TimeGetter;
import twitter4j.Status;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/9/13
 * Time: 7:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class ScoredStatus implements Comparable<ScoredStatus> {
  double score;


  IndexedStatus status;

  public ScoredStatus(double score, IndexedStatus status) {
    this.score = score;
    this.status = status;
  }

  @JsonIgnore
  public long getIndexedId(){
    return this.status.getIndexID();
  }

  public double getScore() {
    return score;
  }

  public String getUserHandle(){
    return status.getStatus().getUser().getScreenName();
  }

  public void setScore(double score) {
    this.score = score;
  }
  
  public String getFollower(){
    return Integer.toString(this.getStatus().getUser().getFollowersCount());
  }

  public String getText(){
    return this.status.getStatus().getText();
  }

  public String getTweetId(){
    return Long.toString(this.status.getStatus().getId());
  }

  public String getAvatarURL(){
    return this.getStatus().getUser().getProfileImageURL().toString();
  }

  public String getDate(){
    return Double.toString(TimeGetter.timeDiffInMin(this.getStatus().getCreatedAt())) + " Mins Ago ";
    //return this.getStatus().getCreatedAt().toString();
  }

  @JsonIgnore
  public Status getStatus() {
    return status.getStatus();
  }

//  public void setStatus(IndexedStatus status) {
//    this.status = status;
//  }

  @Override
  public int compareTo(ScoredStatus o) {
    if(this.score>o.score)
      return 1;
    else if(this.score<o.score)
      return -1;
    else
      return 0;
  }
}
