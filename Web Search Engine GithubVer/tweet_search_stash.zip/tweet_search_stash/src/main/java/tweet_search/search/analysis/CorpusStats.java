package tweet_search.search.analysis;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/11/13
 * Time: 8:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class CorpusStats {
  private final Connection conn;

  public CorpusStats(String dbpath) throws Exception{
    Class.forName("org.sqlite.JDBC");
    conn = DriverManager.getConnection("jdbc:sqlite:" + dbpath);
    Statement statement = conn.createStatement();
    statement.execute("PRAGMA journal_mode=WAL;");
    statement.close();
    ensureTable();
  }

  private void ensureTable() throws Exception{
    Statement stat = conn.createStatement();
    stat.executeUpdate("create table if not exists tweets (" +
//            "index_id INTEGER PRIMARY KEY AUTOINCREMENT," +
//            "tweet_id INTEGER, " +
            "term TEXT PRIMARY KEY, " +
            "count INTEGER" +
            ");");
//            "sentiment VARCHAR(25), " +
//            "created_at DATETIME) ;");
  }
}
