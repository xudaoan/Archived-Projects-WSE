package tweet_search.search.index.persistent;

import tweet_search.io.ReverseNumberDecoder;
import tweet_search.search.Constants;
import tweet_search.search.index.TweetPosting;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.LinkedList;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/2/13
 * Time: 6:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class CachedPostingListReader {
  private final FileChannel fileChannel;
  ReverseNumberDecoder decoder;
  TweetPosting cachedPosting;
  Long cachedPosition = null;
  Long cachedBlockStart = null;
  Long endingPostion;
  Long endingBlockStart;

  public CachedPostingListReader(long endingPos, long endingBlockStart, FileChannel indexFile) {
    this.endingPostion = endingPos;
    this.endingBlockStart = endingBlockStart;
    this.fileChannel = indexFile;
  }

  public long nextSmallerTweetId(long upperBound) throws IOException {
    long position;
    long blockStart;
    if (cachedPosition == null || cachedPosting.getTweetIndexId() < upperBound - 1) {
      position = endingPostion;
      blockStart=endingBlockStart;
//      System.out.println("!!!!!!!!!!!!! "+upperBound);
    } else if (cachedPosting.getTweetIndexId()==upperBound-1){
      return cachedPosting.getTweetIndexId();
    }else{
      position = cachedPosition;
      blockStart=cachedBlockStart;
//      System.out.println("using cached position :) "+position);
    }

    BlockFileReverseReader reverseByteReader = new BlockFileReverseReader(fileChannel, position,blockStart);
    ReverseNumberDecoder decoder = new ReverseNumberDecoder(reverseByteReader);
    int steps = 0;
    while (decoder.hasPrevious()) {
      TweetPosting posting = previousPosting(decoder);
      steps++;
      if (posting.getTweetIndexId() < upperBound) {
        cachedPosition = reverseByteReader.getPosition();
        cachedBlockStart = reverseByteReader.currentBlockStart;
        cachedPosting = posting;
//        System.out.println("steps: "+steps);
        return posting.getTweetIndexId();
      }
    }
    return Constants.ID_NOT_FOUND;
  }

  public TweetPosting previousPosting(ReverseNumberDecoder decoder) throws IOException {

    LinkedList<Long> numbers = new LinkedList<Long>();
    long currentNumber = decoder.previousNumber();

    if (currentNumber == Constants.POSTING_SEP)
      currentNumber = decoder.previousNumber();

    do {
      numbers.push(currentNumber);
    } while (decoder.hasPrevious() && (currentNumber = decoder.previousNumber()) != Constants.POSTING_SEP);

    TweetPosting posting = decodePosting(numbers);
    return posting;
  }

  private TweetPosting decodePosting(LinkedList<Long> numbers) {
    TweetPosting posting = new TweetPosting(numbers.pop());
    while (!numbers.isEmpty()) {
      long occur = numbers.pop();
      posting.addOccurrence((int) occur);
    }
    return posting;  //To change body of created methods use File | Settings | File Templates.
  }


}
