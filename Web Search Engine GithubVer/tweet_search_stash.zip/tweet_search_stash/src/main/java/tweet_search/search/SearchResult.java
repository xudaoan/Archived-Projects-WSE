package tweet_search.search;

import tweet_search.search.analysis.ScoredTweetsStats;
import tweet_search.search.index.ScoredStatus;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/13/13
 * Time: 7:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class SearchResult {
  List<ScoredStatus> results;
  List<ScoredTweetsStats.TagWithScore> scoredTags;

  public SearchResult(List<ScoredStatus> results, List<ScoredTweetsStats.TagWithScore> scoredTags) {
    this.results = results;
    this.scoredTags = scoredTags;
  }

  public List<ScoredStatus> getResults() {
    return results;
  }

  public void setResults(List<ScoredStatus> results) {
    this.results = results;
  }

  public void setScoredTags(List<ScoredTweetsStats.TagWithScore> scoredTags) {
    this.scoredTags = scoredTags;
  }

  public List<ScoredTweetsStats.TagWithScore> getScoredTags() {
    return scoredTags;
  }
}
