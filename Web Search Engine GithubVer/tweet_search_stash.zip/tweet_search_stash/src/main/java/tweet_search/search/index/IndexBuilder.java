package tweet_search.search.index;

import twitter4j.Status;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 3:30 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IndexBuilder {
  public void indexTweet(IndexedStatus tweet) throws IOException, Exception;

}
