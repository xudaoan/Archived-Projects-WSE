package tweet_search.search.index.persistent;

import twitter4j.json.DataObjectFactory;

import java.sql.*;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/9/13
 * Time: 5:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class IndexHeadsDAO {
  private final Connection conn;
  private PreparedStatement insertStatement;

  public static class HeadNotFoundException extends RuntimeException{

    public HeadNotFoundException(String s) {
      super(s);
    }
  }
  public IndexHeadsDAO(String dbpath) throws Exception {
    Class.forName("org.sqlite.JDBC");
    conn = DriverManager.getConnection("jdbc:sqlite:" + dbpath);
    Statement statement = conn.createStatement();
    statement.execute("PRAGMA journal_mode=WAL;");
    statement.close();
//    conn.setAutoCommit(false);
    ensureTable();
//    conn.commit();
  }

  //TODO: create index on timestamp
  public void ensureTable() throws Exception {
    Statement stat = conn.createStatement();
    stat.executeUpdate("create table if not exists HEADS (" +
            "term VARCHAR(100)," +
            "pos INTEGER, " +
            "blockstart INTEGER, " +
//            "tweet_search TEXT, " +
//            "topic VARCHAR(50), " +
//            "sentiment VARCHAR(25), " +
            "timestamp DATETIME);" +
//            "primary key (term,timestamp,pos));" +
            "create index if not exists term_index on HEADS(term);" +
            "create index if not exists time_index on HEADS(term,timestamp);");
  }

  public void flushInsert() throws SQLException {
    insertStatement.executeBatch();
    insertStatement.clearBatch();
//    conn.commit();
  }

  public void addHead(String term, long pos,long blockstart, Date date) throws SQLException {
   try{
    if (insertStatement == null) {
      insertStatement = conn.prepareStatement(
              "insert into HEADS(term,pos,blockstart,timestamp) values (?,?,?,?);");

    }
    insertStatement.setString(1,term);
    insertStatement.setLong(2, pos);
    insertStatement.setLong(3, blockstart);
    insertStatement.setDate(4,new java.sql.Date(date.getTime()));
    insertStatement.addBatch();
   }catch(SQLException e){
     System.err.println("can not add head:"+term+", "+date);
     e.printStackTrace();
   }
  }

  public InvertedIndexSingleFile.Position getLatestPos(String term) throws SQLException {
    String sqlStr="select pos, blockstart from HEADS where term = ? order by timestamp desc limit 1";
    PreparedStatement preparedStatement = conn.prepareStatement(sqlStr);
    preparedStatement.setString(1, term);
    ResultSet rs = preparedStatement.executeQuery();
    while (rs.next()) {
      long pos = rs.getLong("pos");
      long blockStart=rs.getLong("blockstart");
      preparedStatement.close();
      rs.close();
      return new InvertedIndexSingleFile.Position(blockStart,pos);
    }
    if (rs!=null)
      rs.close();
    if(preparedStatement!=null)
      preparedStatement.close();
    throw new HeadNotFoundException("cant get head pos for "+term);
  }

  public long getLatestPosByDate(String term, Date date) throws SQLException{
    String sqlStr="select pos from HEADS where term = ? AND timestamp > ? order by timestamp asc limit 1";
    PreparedStatement preparedStatement = conn.prepareStatement(sqlStr);
    preparedStatement.setString(1, term);
    preparedStatement.setDate(2, new java.sql.Date(date.getTime()));
    ResultSet rs = preparedStatement.executeQuery();
    while (rs.next()) {
      long pos = rs.getLong("pos");
      rs.close();
      return pos;
    }
    if (rs!=null)
      rs.close();
    if(preparedStatement!=null)
      preparedStatement.close();
    throw new HeadNotFoundException("cant get head pos for "+term);
  }
}
