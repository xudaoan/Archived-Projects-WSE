package tweet_search.search;

import tweet_search.corpus.TweetsSqliteDAO;
import tweet_search.search.analysis.GeoGetter;
import tweet_search.search.analysis.ScoredTweetsStats;
import tweet_search.search.analysis.TimeGetter;
import tweet_search.search.index.IndexedStatus;
import tweet_search.search.index.InvertedIndexSearcher;
import tweet_search.search.index.ScoredStatus;
import tweet_search.search.index.persistent.InvertedIndexSingleFile;
import twitter4j.GeoLocation;
import twitter4j.HashtagEntity;
import twitter4j.Place;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/13/13
 * Time: 10:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchEngine {
  public static final double SOCIAL_WEIGHT = 0.8;
  public static final double HASHTAG_WEIGHT = 0.2;
  String indexPath;
  String headsDBPath;
  String tweetsDbPath;

  InvertedIndexSearcher invertedIndexSearcher;
  TweetsSqliteDAO tweetsDAO;
  InvertedIndexSingleFile index;
  private HashMap<String, Double> scoredHashTagMap;
  private List<ScoredTweetsStats.TagWithScore> scoredTags;

  public SearchEngine(String indexPath, String headsDBPath, String tweetsDbPath) throws Exception {
    this.indexPath = indexPath;
    this.headsDBPath = headsDBPath;
    this.tweetsDbPath = tweetsDbPath;

    index = new InvertedIndexSingleFile(new RandomAccessFile(indexPath, "rw").getChannel(),
        headsDBPath);
    tweetsDAO = new TweetsSqliteDAO(tweetsDbPath);
    invertedIndexSearcher = new InvertedIndexSearcher(index, tweetsDAO);
  }

  public SearchResult doSearch(String[] words) throws Exception {
    Long pos = Constants.INFINITY_ID;
    IndexedStatus tweet;
    int resultCount = 0;
    List<ScoredStatus> result = searchAndScoreBySocial(words, pos, resultCount);
    reweightByLog(result);
    reweightByHashTag(result);
    reweightByGeo(result);
//    reweightByTime(result);

    index.clearReaderCache();
    return new SearchResult(result, scoredTags);
  }

  private List<ScoredStatus> searchAndScoreBySocial(String[] words, Long pos, int resultCount) throws Exception {
    IndexedStatus tweet;
    List<ScoredStatus> result = new ArrayList<ScoredStatus>();
    while ((tweet = invertedIndexSearcher.nextTweetByTerms(words, pos)) != null) {
      // System.out.println(tweet.getStatus().getUser().getFollowersCount()+" | "+tweet.getStatus().getText());
      // System.out.println(tweetID.getIndexID() + " | " +
      // tweetID.getStatus().getText());
      long score = (long) (tweet.getStatus().getUser().getFollowersCount() + 1) + (tweet.getStatus().getUser().getListedCount() + 1);
      result.add(new ScoredStatus(score, tweet));
      pos = tweet.getIndexID();
      resultCount++;
    }

    Collections.sort(result);
    return result;
  }

  private void reweightByLog(List<ScoredStatus> result) {

    for (ScoredStatus tweetWithScore : result) {
      tweetWithScore.setScore(Math.log(tweetWithScore.getScore()));
    }
    Collections.sort(result);
  }

  private void reweightByHashTag(List<ScoredStatus> result) {
    ScoredTweetsStats stats = new ScoredTweetsStats(result);
    scoredHashTagMap = stats.getScoredTagMap();

    for (ScoredStatus tweetWithScore : result) {
      double maxTagScore = 0.0;
      for (HashtagEntity hashtagEntity : tweetWithScore.getStatus().getHashtagEntities()) {
        String tag = hashtagEntity.getText().toLowerCase();
        Double tagScore = scoredHashTagMap.get(tag);
        maxTagScore = maxTagScore < tagScore ? tagScore : maxTagScore;
      }
      tweetWithScore.setScore(SOCIAL_WEIGHT * tweetWithScore.getScore() + HASHTAG_WEIGHT * (maxTagScore) / stats.maxUserCountOfHashTag);
    }
    scoredTags = stats.printHashTagScore(scoredHashTagMap);
    Collections.sort(result);
  }

  private void reweightByTime(List<ScoredStatus> result) {
    for (ScoredStatus tweetWithScore : result) {
      Date tweetDate = tweetWithScore.getStatus().getCreatedAt();
      Long timeDiff = tweetDate.getTime() - TimeGetter.getLong();
      timeDiff = (timeDiff / 1000) / 60;
      int validTime = 60 * 24;
      // In minutes
      // double multiplier = Math.max(0.0, 1.0 - Math.pow((double) timeDiff / validTime, 2));
       double multiplier = Math.pow(2, (timeDiff/60)/6);
      tweetWithScore.setScore(tweetWithScore.getScore() * multiplier);
    }

    Collections.sort(result);
  }

  private void reweightByGeo(List<ScoredStatus> result) {
    double maxDistance = 500.0;
    double maxInfluence = 1.0;
    int counter = result.size();
    for (ScoredStatus tweetWithScore : result) {
      double distance = 40000.0;
      boolean getit = false;

      Place place = tweetWithScore.getStatus().getPlace();
      if (place != null) {
        GeoLocation[][] locations = place.getGeometryCoordinates();
        if (locations != null) {
          for (int i = 0; i < locations.length; i++) {
            for (int j = 0; j < locations[i].length; j++) {
              double tempDis = GeoGetter.getdistance(locations[i][j]);
              distance = distance < tempDis ? distance : tempDis;
            }
          }
          getit = true;
        }
      }

      place = tweetWithScore.getStatus().getPlace();
      if (place != null) {
        GeoLocation[][] locations = place.getBoundingBoxCoordinates();
        if (locations != null) {
          for (int i = 0; i < locations.length; i++) {
            for (int j = 0; j < locations[i].length; j++) {
              double tempDis = GeoGetter.getdistance(locations[i][j]);
              distance = distance < tempDis ? distance : tempDis;
            }
          }
          getit = true;
        }
      }

      if (!getit) {
        GeoLocation geo = tweetWithScore.getStatus().getGeoLocation();
        if (geo != null) {
          double tempDis = GeoGetter.getdistance(geo);
          distance = distance < tempDis ? distance : tempDis;
        }
      }

      double factor = maxInfluence * 
          Math.max(0.0, 1.0 - Math.pow((double) distance / maxDistance, 2));
      tweetWithScore.setScore(tweetWithScore.getScore() + factor);

      if (getit){
        Long timeDiff = tweetWithScore.getStatus().getCreatedAt().getTime() - TimeGetter.getLong();
        timeDiff = timeDiff / 60 / 1000;
        System.out.println(distance + " miles | "
            + ">>" + counter
            + " | " + tweetWithScore.getScore() 
            + " | Mins before: " + timeDiff
            + " | " + tweetWithScore.getText());
      }
      counter --;
    }
    Collections.sort(result);
  }

}
