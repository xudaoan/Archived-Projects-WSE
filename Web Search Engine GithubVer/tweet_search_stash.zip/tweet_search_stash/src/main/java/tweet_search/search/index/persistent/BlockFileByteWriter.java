package tweet_search.search.index.persistent;

import tweet_search.io.ByteWriter;
import tweet_search.io.NumberEncoder;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.nio.channels.FileChannel;

public class BlockFileByteWriter implements ByteWriter {

  //IMPORTANT: since the diff of two block used two bytes, the block size can not be bigger than 2^16= 67108864 Bytes
//  public static int BLOCK_SIZE=30;//how many bytes per block

  public static int FIRST_BLOCK_SIZE=30;//30 bytes for first bytes
  public static int GROWTH_FACTOR=30;// the size of nth block is 30*(10^(n-1))

  FileChannel channel;
  long position;
  long currentBlockStart;
  long currentBlockSize=FIRST_BLOCK_SIZE;

  private BlockFileByteWriter(FileChannel channel, long position, long blockStart) {
    this.channel = channel;
    this.position=position;
    this.currentBlockStart=blockStart;
  }

  /**
   * This method will return a writer for a new number series or byte series
   * @param channel
   * @return
   * @throws IOException
   */
  public static BlockFileByteWriter createNewBlockFileWriter(FileChannel channel) throws IOException {
    //seek to the end of current File
    BlockFileByteWriter writer = new BlockFileByteWriter(channel, 0,0);
    writer.currentBlockSize=0;
    writer.currentBlockStart=-1;
    writer.allocateNewBlock();//new block that has no previous
//    System.out.println("created new writer at position: " + writer.position);
    return writer;
  }

  public static BlockFileByteWriter loadBlockFileWriter(FileChannel channel, long position, long blockStart) throws Exception {
     BlockFileByteWriter writer=new BlockFileByteWriter(channel,position,blockStart);
     writer.readCurrentBlockSize();
     return writer;
  }

  private void readCurrentBlockSize() throws Exception {
    channel.position(currentBlockStart);
    ByteBuffer bf=ByteBuffer.allocate(8*2);//two metadata
    channel.read(bf);
    bf.flip();
    LongBuffer lb=bf.asLongBuffer();
//    lb.flip();
    long previousStart=lb.get();
    long size=lb.get();
    this.currentBlockSize= (int) size;
  }

  /**
   * @throws IOException
   */
  private void allocateNewBlock() throws IOException {

    long previousBlockStart=currentBlockStart;
    //currently the positionshould be the end of block
    if(position%FIRST_BLOCK_SIZE!=0)
      throw new RuntimeException("Can not allocate New Block: current block is not finished");

    long newBlockStart=seekToEnd(channel);

    if(newBlockStart%FIRST_BLOCK_SIZE!=0)
      throw new RuntimeException("[FATAL] can not allocateNewBlock in the middle: "+newBlockStart);

    int newBlockSize;
    if (currentBlockSize==0)
      newBlockSize=FIRST_BLOCK_SIZE;
    else {
      long l = currentBlockSize * GROWTH_FACTOR;
      if (l>=Integer.MAX_VALUE){
        System.err.println("[FATAL]BLOCK size too big : "+l);
        l=Integer.MAX_VALUE-100;
      }
      newBlockSize= (int)l;
    }

    channel.write(ByteBuffer.allocate(newBlockSize));
    this.currentBlockSize=newBlockSize;
    this.currentBlockStart=newBlockStart;
    writeBlockMetadata(previousBlockStart);
//    System.out.println("allocated new block: "+currentBlockStart+" with size "+currentBlockSize+" with previous"+previousBlockStart);
    //TODO: following line is not necessary in single threaded program
//    this.position=channel.position();
  }

  private static long seekToEnd(FileChannel channel) throws IOException {
     channel.position(channel.size());
     return channel.position();
  }



  public void writeBytes(ByteBuffer buffer) throws IOException {
    while(buffer.hasRemaining()){
      writeByte(buffer.get());
    }
  }

  /**
   * TODO: not good: share same channel for all writers, easy to have bugs
   * @param b
   * @throws IOException
   */
  private void writeByte(Byte b) throws IOException {

    channel.position(position);
    ByteBuffer buffer=ByteBuffer.allocate(1);
    buffer.put(b);
    if (isEndOfBlock()){
      allocateNewBlock();
    }
    buffer.flip();
    channel.write(buffer);
    position=channel.position();
//    System.out.println("byte: "+position);
  }



  private void writeBlockMetadata(long previousBlockStart) throws IOException {
    channel.position(currentBlockStart);
    ByteBuffer buffer= ByteBuffer.allocate(1000);

    LongBuffer longBuffer=buffer.asLongBuffer();
    longBuffer.put(previousBlockStart);
    longBuffer.put(currentBlockSize);
//    longBuffer.flip();
    buffer.limit(8 * longBuffer.position());
    channel.write(buffer);//First number of block is the previous pointer
    position=channel.position();
  }






  private boolean isEndOfBlock() {
//    0 1 2 3 4 5 6 7 8
//     x x x x x x x x
    return position!=0&&(position==currentBlockStart+currentBlockSize);
  }

  public long getPosition() {
    return position;
  }
}
