package tweet_search.search.index;

import tweet_search.search.Constants;
import tweet_search.corpus.TweetsDAO;
import twitter4j.Status;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 1:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvertedIndexSearcher {
  InvertedIndex index;
  TweetsDAO tweetsDAO;
  public InvertedIndexSearcher(InvertedIndex index,TweetsDAO tweetsDAO) {
    this.index = index;
    this.tweetsDAO=tweetsDAO;
  }

  public long nextTweetIndexIdByTerms(String[] terms, long indexIdUpperBound) throws Exception {
    boolean haveSameTweetID = true;
    long previous = 0;// TweetIndexID Starts from 1;
    long minTweetIndexID = Constants.INFINITY_ID;
    if (terms.length == 0)
      throw new RuntimeException("query contains no words, maybe not processed");

    for (String term : terms) {
      long nextCandidateTweetId = index.nextTweetIdForTerm(term, indexIdUpperBound);
      if (nextCandidateTweetId== Constants.ID_NOT_FOUND)
        return Constants.ID_NOT_FOUND;//reaches the end of Term List, no tweet matches

      if (previous != 0 && previous!=nextCandidateTweetId)
        haveSameTweetID = false;

      if (nextCandidateTweetId < minTweetIndexID)
        minTweetIndexID = nextCandidateTweetId;

      previous = nextCandidateTweetId;
    }

    if (haveSameTweetID)
      return minTweetIndexID;
    else
      return nextTweetIndexIdByTerms(terms, minTweetIndexID+1);
  }

  public IndexedStatus nextTweetByTerms(String[] terms,long startingID) throws Exception {
     long tid=nextTweetIndexIdByTerms(terms,startingID);
    if (tid==Constants.ID_NOT_FOUND)
        return null;

    Status t = tweetsDAO.getTweetByIndexID(tid);
    if(t==null)
      throw new RuntimeException("cant find tweet:"+tid);
    return new IndexedStatus(tid, t);
  }

  public Status nextTweetByPhrase(String[] phrase, long indexIdUpperBound) throws Exception {


    long tweetIndexID;
    while((tweetIndexID=nextTweetIndexIdByTerms(phrase,indexIdUpperBound))!=Constants.ID_NOT_FOUND){
      int phraseLoaction=nextPhraseLocationInTweet(phrase, tweetIndexID, -1);//start search phrase from first location,TODO: record how many times the phrase occurs
      indexIdUpperBound=tweetIndexID;
      if (phraseLoaction!=Constants.INFINITY_POS)
        return tweetsDAO.getTweetByIndexID(tweetIndexID);

    }
    return null;
  }

  private int nextPhraseLocationInTweet(String[] terms, long tweetIndexID, int afterPos) throws Exception {
     int firstPos=Constants.INFINITY_POS;
     int previousPos = Constants.INFINITY_POS;

    for (int i = 0; i < terms.length; i++) {
      String term=terms[i];
      Integer nextPos = index.nextPosOfTermInTweet(term, tweetIndexID, afterPos);

      if (nextPos.equals(Constants.INFINITY_POS))
        return Constants.INFINITY_POS;//any term pos is infinity then return infinity

      if (i == 0) {
        firstPos = nextPos;//the pos of a phrase is the pos of the first word of the phrase
      }

      if (i >= 1 && nextPos - previousPos != 1) {
        return nextPhraseLocationInTweet(terms, tweetIndexID, firstPos);//not consecutive
      }

      previousPos = nextPos;
    }

    return firstPos;
  }
}
