package tweet_search.search.index.persistent;

import tweet_search.io.NumberSeriesEncoder;
import tweet_search.search.Constants;
import tweet_search.search.index.TweetPosting;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/26/13
 * Time: 4:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class TermPostingFileWriter {
  File termPostingFile;

  public TermPostingFileWriter(File termPostingFile) {
    this.termPostingFile = termPostingFile;
  }

  //TODO: may not open stream every time
  public void appendPosting(TweetPosting tweetTermPosting) throws IOException {
    FileOutputStream termIndexStream = new FileOutputStream(termPostingFile, true);
    writePosting(tweetTermPosting, termIndexStream);
    termIndexStream.close();
  }

  private void writePosting(TweetPosting tweetTermPosting, FileOutputStream termIndexStream) throws IOException {
    //id,occ1 occ2 occ3 0
    NumberSeriesEncoder encoder = new NumberSeriesEncoder(termIndexStream);
    encoder.put(tweetTermPosting.getTweetIndexId());

    for (int occurrence : tweetTermPosting.getOccurrences()) {
      encoder.put(occurrence);
    }
    encoder.put(Constants.POSTING_SEP);//0 is the separator between docPOSTING
    encoder.flush();
  }


}
