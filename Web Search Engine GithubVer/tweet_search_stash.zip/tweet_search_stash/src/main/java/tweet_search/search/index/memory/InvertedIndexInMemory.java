package tweet_search.search.index.memory;

import tweet_search.search.Constants;
import tweet_search.search.index.InvertedIndex;
import tweet_search.search.index.InvertedIndexAppendable;
import tweet_search.search.index.TweetPosting;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 3:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvertedIndexInMemory implements InvertedIndex, InvertedIndexAppendable {
  /**
   * a wrapper for List, but with hashindex to fast access Posting by tweetIndexID
   */
  private static class PostingList{
     List<TweetPosting> postings=new LinkedList<TweetPosting>();
    HashMap<Long,TweetPosting> postingHashMap=new HashMap<Long, TweetPosting>();

    public void add(TweetPosting tweetTermPosting) {
      postings.add(tweetTermPosting);
      postingHashMap.put(tweetTermPosting.getTweetIndexId(),tweetTermPosting);
    }

    public List<TweetPosting> getPostings() {
      return postings;
    }

    public TweetPosting getPostingByIndexID(long tweetIndexId) {
      return postingHashMap.get(tweetIndexId);
    }
  }
  HashMap<String,PostingList> index=new HashMap<String, PostingList>();

  public void addPosting(String term, TweetPosting tweetTermPosting, Date createdAt){
      ensurePostingList(term);
      index.get(term).add(tweetTermPosting);
  }

  private void ensurePostingList(String term) {
    if (!index.containsKey(term)){
      index.put(term,new PostingList());
    }
  }

  @Override
  public long nextTweetIdForTerm(String term, long idUpperBound) {
    PostingList postingList = index.get(term);
    if (postingList==null)
      return Constants.ID_NOT_FOUND;
    List<TweetPosting> postings=postingList.getPostings();
    for (int i=postings.size()-1;i>=0;i--) {
      TweetPosting posting=postings.get(i);
      if (posting.getTweetIndexId() < idUpperBound)
        return posting.getTweetIndexId();
    }
    return Constants.ID_NOT_FOUND;  //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public Integer nextPosOfTermInTweet(String term, long tweetIndexId, Integer startingPos) {
    TweetPosting posting=index.get(term).getPostingByIndexID(tweetIndexId);
    if (posting==null)
      return Constants.INFINITY_POS;
    for(int pos:posting.getOccurrences()){
      if (pos>startingPos)
        return pos;
    }
    return Constants.INFINITY_POS;  //To change body of implemented methods use File | Settings | File Templates.
  }
}
