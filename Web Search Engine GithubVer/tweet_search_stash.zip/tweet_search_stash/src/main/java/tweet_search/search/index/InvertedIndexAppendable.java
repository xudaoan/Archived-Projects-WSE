package tweet_search.search.index;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 3:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface InvertedIndexAppendable {
  public void addPosting(String term, TweetPosting tweetTermPosting, Date createdAt) throws FileNotFoundException, IOException, Exception;
}
