package tweet_search.search.analysis;

import java.util.Date;

public class TimeGetter {
  
  public static final Date date =  new Date(1367001872000L);
  //Fri Apr 26 14:44:32 EDT 2013
  public static long getLong(){
    return date.getTime();
  }
  
  public static long timeDiffInMin(Date time){
    return (date.getTime() - time.getTime()) / 1000 / 60;
  }
}
