package tweet_search.search.index;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 1:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface InvertedIndex {
  /**
   * return the next biggest TweetID that is smaller than startingID,
   * Bigger ID means newer, vice versa,
   * Should return bigger ID first
   * @param term
   * @param idUpperBound
   * @return
   * @throws FileNotFoundException
   * @throws IOException
   */
  public long nextTweetIdForTerm(String term, long idUpperBound) throws FileNotFoundException, IOException, Exception;

  /**
   * next occurrence of the same term in the same tweet
   * Notice that previousPos might be a negative number or a number that is bigger than the size of the posting list
   * @param term
   * @param tweetIndexId
   * @param previousPos
   * @return  the position of the word, return Constants.INFINITY_POS when can not find next Occurrence
   */
  Integer nextPosOfTermInTweet(String term, long tweetIndexId, Integer previousPos) throws FileNotFoundException, IOException, Exception;
}
