package tweet_search.search.index.persistent;

import tweet_search.io.NumberSeriesReverseDecoder;
import tweet_search.search.Constants;
import tweet_search.search.index.TweetPosting;

import java.io.*;
import java.util.LinkedList;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/26/13
 * Time: 4:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class TermPostingFileReverseReader {
  File termPostingFile;
  NumberSeriesReverseDecoder decoder;

  public TermPostingFileReverseReader(File termPostingFile) throws FileNotFoundException {
    this.termPostingFile = termPostingFile;
    decoder = new NumberSeriesReverseDecoder(new RandomAccessFile(termPostingFile, "r").getChannel());
  }

  public TweetPosting nextPosting() throws IOException {

    LinkedList<Long> numbers=new LinkedList<Long>();
    long currentNumber;

    while(decoder.next()!= Constants.POSTING_SEP){
    };

    while(decoder.hasNext()&&(currentNumber=decoder.next())!=Constants.POSTING_SEP){
      numbers.push(currentNumber);
    }
    if(decoder.hasNext())
         decoder.seekBack(1);//file not ending,0 is the dataBoundary

    TweetPosting posting= decodePosting(numbers);
    return posting;
  }

  public boolean hasNext() throws IOException {
    return decoder.hasNext();
  }

  public void seekToEndOfFile() throws IOException {
    decoder.seekToEnd();
  }

  private TweetPosting decodePosting(LinkedList<Long> numbers) {
    TweetPosting posting=new TweetPosting(numbers.pop());
    while(!numbers.isEmpty()){
      long occur=numbers.pop();
      posting.addOccurrence((int)occur);
    }
    return posting;  //To change body of created methods use File | Settings | File Templates.
  }


}
