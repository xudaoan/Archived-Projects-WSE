package tweet_search.search;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 2:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class Constants {
  public static final long ID_NOT_FOUND = 0;
  public static long INFINITY_ID=Long.MAX_VALUE;
  public static Integer INFINITY_POS=-100;
  public static long POSTING_SEP=0;
}
