package tweet_search.search.index;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 3:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class TweetPosting {
  long tweetIndexId;
  List<Integer> occurrences=new ArrayList<Integer>();

  public TweetPosting(long tweetIndexId) {
    this.tweetIndexId = tweetIndexId;
  }

  public long getTweetIndexId() {
    return tweetIndexId;
  }

  public void setTweetIndexId(long tweetIndexId) {
    this.tweetIndexId = tweetIndexId;
  }

  public List<Integer> getOccurrences() {
    return occurrences;
  }

  public void addOccurrence(int pos){
    occurrences.add(pos);
  }

  @Override
  public String toString() {
    return "TweetPosting{" +
            "tweetIndexId=" + tweetIndexId +
            ", occurrences=" + occurrences +
            '}';
  }
}
