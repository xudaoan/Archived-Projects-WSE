package tweet_search.search.tweets;

import cmu.arktweetnlp.Tagger;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/28/13
 * Time: 6:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class TweetTokenizer {
  Tagger tagger;
  public TweetTokenizer() {

    try {
      String modelFilename = "/cmu/arktweetnlp/model.20120919";
      tagger= new Tagger();
      tagger.loadModel(modelFilename);
    } catch (IOException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
  }

  /**
   * return a sorted Map(by pos)
   * @param text
   * @return
   */
  public Map<Integer, String> tokenize(String text) {
    TreeMap<Integer,String> posTokenMap=new TreeMap<Integer, String>();
    List<Tagger.TaggedToken> taggedTokens = tagger.tokenizeAndTag(text);
    for(int i=0;i<taggedTokens.size();i++){

      Tagger.TaggedToken token=taggedTokens.get(i);
//      System.out.println(token.tag+"  |  "+ token.token);


      //skip URL
      if(token.tag.equals("U")){
        continue;
      }
      //skip Garbage
      if(token.tag.equals("G")){
        continue;
      }
      //skip emoticon
      if(token.tag.equals("E")){
        continue;
      }

      //separators means .  skip!
      if(token.tag.equals(","))
      {
        continue;
      }

      //replace interjection(lol,) with , SKIP!
      if(token.tag.equals("!")){
        continue;
      }
      // ~ means discourse marker, indications of continuation across multiple tweets
      if(token.tag.equals("~")){
        continue;
      }

      //handle hashtag
      //^ means NN, it helps to parse hashtag
//      if(token.tag.equals("^"))
//      {
//        tagHint="->NNP";
//      }

//      if(token.tag.equals("N")){
//        tagHint="->NN";
//      }

      //A means Adjective
//      if(token.tag.equals("A"))
//      {
//        tagHint="->JJ";
//      }

      //R means adverb
//      if(token.tag.equals("R")){
//        tagHint="->RB";
//      }

      //& means coordination conjunction
//      if(token.tag.equals("&")){
//        tagHint="->CC";
//      }

      //V means V* verb
//      if(token.tag.equals("V")){
//        tagHint="->VB";
//      }

      //D means determiner
//      if(token.tag.equals("D")){
//        tagHint="->DT";
//      }

      //$ measn CD, SKIP!
      if(token.tag.equals("$")){
        continue;
      }

      //get rid of non-english
      if (!token.token.matches("[#@]?[a-zA-Z]+")) {
        continue;
      }

      posTokenMap.put(i, token.token.toLowerCase());

    }
//    System.out.println(posTokenMap);
    return posTokenMap;  //To change body of created methods use File | Settings | File Templates.
  }
}
