package tweet_search.search.analysis;

import tweet_search.search.index.ScoredStatus;
import twitter4j.HashtagEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/11/13
 * Time: 7:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class ScoredTweetsStats {
  List<ScoredStatus> tweets;
  public Integer maxUserCountOfHashTag = null;

  public ScoredTweetsStats(List<ScoredStatus> tweets) {
    this.tweets = tweets;
  }

  public static class TagWithScore implements Comparable<TagWithScore> {
    Double score;
    String tag;

    public Double getScore() {
      return score;
    }

    public int getIntScore(){
      return score.intValue();
    }

    public String getTag() {
      return tag;
    }

    public TagWithScore(String tag, Double score) {
      this.score = score;
      this.tag = tag;
    }

    @Override
    public int compareTo(TagWithScore o) {
      return 0 - score.compareTo(o.score);
    }
  }

  public List<TagWithScore> printHashTagScore(HashMap<String, Double> unlogedScoredHashTags) {
    HashMap<String, Double> tagWithFrequency = unlogedScoredHashTags;

    List<TagWithScore> tagsWithScore = new ArrayList<TagWithScore>();
    for (String tag : tagWithFrequency.keySet()) {
      Double score = tagWithFrequency.get(tag);
      //score = Math.max(0.0, Math.log(score));
      tagsWithScore.add(new TagWithScore(tag, score));
    }
    Collections.sort(tagsWithScore);

    for (TagWithScore t : tagsWithScore) {
      System.out.println(t.tag + "=" + t.score);
    }

    return tagsWithScore;
  }

  private static class TagScore {
    HashMap<Long, Double> userScore;
    String tag;

    TagScore(String tag) {
      this.tag = tag;
      userScore = new HashMap<Long, Double>();
    }

    void update(ScoredStatus scoredStatus) {
      long userId = scoredStatus.getStatus().getUser().getId();
      double score = scoredStatus.getScore();
      userScore.put(userId, Math.max(score,
              userScore.get(userId) == null ? 0.0 : userScore.get(userId)));
    }

    int getUserCount() {
      return userScore.size();
    }

    double getScore() {
      // if(userScore.size() < 2)
      // return 0.0;

      double result = 0.0;
      for (double value : userScore.values()) {
        result += value;
      }
      return (result);
    }
  }

  public HashMap<String, Double> getScoredTagMap() {
    HashMap<String, Double> resultTagWithScores = new HashMap<String, Double>();
    HashMap<String, TagScore> tags = new HashMap<String, TagScore>();

    for (ScoredStatus scoredStatus : tweets) {

      HashtagEntity[] hashTags = scoredStatus.getStatus().getHashtagEntities();
      for (HashtagEntity tagEntity : hashTags) {
        String tag = tagEntity.getText().toLowerCase();

        if (!tags.containsKey(tag)) {
          tags.put(tag, new TagScore(tag));
        }
        tags.get(tag).update(scoredStatus);
      }

    }

    double max = 0.0;
    maxUserCountOfHashTag=1;
    for (String tag : tags.keySet()) {
      double value = tags.get(tag).getScore();
      max = max > value ? max : value;
      maxUserCountOfHashTag = maxUserCountOfHashTag > tags.get(tag).getUserCount() ? maxUserCountOfHashTag : tags.get(tag).getUserCount();
      resultTagWithScores.put(tag, value);
    }

    return resultTagWithScores;
  }

}
