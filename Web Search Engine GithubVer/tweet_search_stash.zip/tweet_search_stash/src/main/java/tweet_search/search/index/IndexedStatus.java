package tweet_search.search.index;

import twitter4j.Status;

public class IndexedStatus{
  long indexID;
  Status status;

  public IndexedStatus(long indexID, Status status) {
    this.indexID = indexID;
    this.status = status;
  }

  public long getIndexID() {
    return indexID;
  }

  public void setIndexID(long indexID) {
    this.indexID = indexID;
  }

  public Status getStatus() {
    return status;
  }

  public void setStatus(Status status) {
    this.status = status;
  }
}
