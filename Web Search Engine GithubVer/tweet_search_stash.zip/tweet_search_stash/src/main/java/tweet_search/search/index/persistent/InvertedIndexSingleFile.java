package tweet_search.search.index.persistent;

import tweet_search.io.NumberEncoder;
import tweet_search.io.ReverseNumberDecoder;
import tweet_search.search.Constants;
import tweet_search.search.index.InvertedIndex;
import tweet_search.search.index.InvertedIndexAppendable;
import tweet_search.search.index.TweetPosting;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * This implementation stores linkedLists for all terms in a Single File. Each term
 * has its own linked list. The header of linkedlist of each term is stored
 * in a hashmap. Linked List is accessable via blocks.
 * Each block has a previous pointer pointing to previous block.
 * For each linkedlist, every time its block is filled up, a new block will be allocated
 * at the end of the file
 */
public class InvertedIndexSingleFile implements InvertedIndexAppendable, InvertedIndex {
  public static class Position{
    long blockStart;
    long position;

    public Position(long blockStart, long position) {
      this.blockStart = blockStart;
      this.position = position;
    }
  }
  public static final int HEAD_BATCH_SIZE = 10000;
  public static final int MAX_WRITER_SIZE = 10000;
  public static int indexPostingCount = 0;
  //TODO: termPos map should be persisted
  private Map<String, BlockFileByteWriter> termBytesWriter = new HashMap<String, BlockFileByteWriter>();
  public FileChannel indexFile;
  private IndexHeadsDAO headsDAO;
  private Map<String, Date> changedHeads = new HashMap<String, Date>();
  private long latestTweetDate;

  public InvertedIndexSingleFile(FileChannel indexFile, String headsPath) throws Exception {
    this.indexFile = indexFile;
    if (headsPath == null)
      throw new RuntimeException("Head is not provided!!!");
    loadHeads(headsPath);
  }

  private void loadHeads(String headPath) throws Exception {
    headsDAO = new IndexHeadsDAO(headPath);
  }

  //TODO: try to load position from dao firs, if not exist then create a new head
  @Override
  public void addPosting(String term, TweetPosting tweetTermPosting, Date createdAt) throws Exception {

    if (!termBytesWriter.containsKey(term)) {
//      long pos;
      try {
        Position pos = headsDAO.getLatestPos(term);
        termBytesWriter.put(term, BlockFileByteWriter.loadBlockFileWriter(indexFile, pos.position,pos.blockStart));
      } catch (IndexHeadsDAO.HeadNotFoundException e) {
        termBytesWriter.put(term, BlockFileByteWriter.createNewBlockFileWriter(indexFile));
      }

    }

    BlockFileByteWriter writer = termBytesWriter.get(term);
    writePosting(writer, tweetTermPosting);
    updateTermHeads(term, createdAt);
  }

  private void updateTermHeads(String term, Date createdAt) throws Exception {
    changedHeads.put(term, createdAt);
    if (indexPostingCount++ > HEAD_BATCH_SIZE) {
      saveHeads();
      changedHeads.clear();
      indexPostingCount = 0;
      if (termBytesWriter.keySet().size() >= MAX_WRITER_SIZE) {
        termBytesWriter.clear();
        System.out.println("clearing writer....");
      }
    }
  }

  private void writePosting(BlockFileByteWriter writer, TweetPosting tweetTermPosting) throws IOException {
    NumberEncoder encoder = new NumberEncoder(writer);
    encoder.writeNumber(tweetTermPosting.getTweetIndexId());
    for (int occurrence : tweetTermPosting.getOccurrences()) {
      encoder.writeNumber(occurrence);
    }
    encoder.writeNumber(Constants.POSTING_SEP);
  }

  public TweetPosting nextPosting(ReverseNumberDecoder decoder) throws IOException {

    LinkedList<Long> numbers = new LinkedList<Long>();
    long currentNumber = decoder.previousNumber();

    if (currentNumber == Constants.POSTING_SEP)
      currentNumber = decoder.previousNumber();

    do {
      numbers.push(currentNumber);
    } while (decoder.hasPrevious() && (currentNumber = decoder.previousNumber()) != Constants.POSTING_SEP);

    TweetPosting posting = decodePosting(numbers);
    return posting;
  }

  public boolean hasPrevious(ReverseNumberDecoder decoder) throws IOException {
    return decoder.hasPrevious();
  }

  //TODO: this map could become huge, may clear it after sometime
  HashMap<String, CachedPostingListReader> cachedPostingListReaderMap = new HashMap<String, CachedPostingListReader>();

  public void clearReaderCache() {
    cachedPostingListReaderMap.clear();
  }

  @Override
  public long nextTweetIdForTerm(String term, long idUpperBound) throws Exception {
    try{
    if (!cachedPostingListReaderMap.containsKey(term)) {
      Position pos=getLatestPositionForTerm(term);
      cachedPostingListReaderMap.put(term, new CachedPostingListReader(pos.position,pos.blockStart, indexFile));
    }
    CachedPostingListReader reader = cachedPostingListReaderMap.get(term);
//    System.out.println("searching "+term);
    long resultId = reader.nextSmallerTweetId(idUpperBound);
    return resultId;
    }catch(IndexHeadsDAO.HeadNotFoundException e){
      return Constants.ID_NOT_FOUND;
    }

  }

  @Override
  public Integer nextPosOfTermInTweet(String term, long tweetIndexId, Integer previousPos) throws Exception {
    Position postion = getLatestPositionForTerm(term);
    ReverseNumberDecoder decoder = new ReverseNumberDecoder(new BlockFileReverseReader(indexFile, postion.position,postion.blockStart));

    while (decoder.hasPrevious()) {
      TweetPosting posting = nextPosting(decoder);
      if (posting.getTweetIndexId() == tweetIndexId) {
        for (int pos : posting.getOccurrences()) {
          if (pos > previousPos)
            return pos;
        }
        return Constants.INFINITY_POS;//no occur
      }
    }

    return Constants.INFINITY_POS;
  }

  private TweetPosting decodePosting(LinkedList<Long> numbers) {
    TweetPosting posting = new TweetPosting(numbers.pop());
    while (!numbers.isEmpty()) {
      long occur = numbers.pop();
      posting.addOccurrence((int) occur);
    }
    return posting;  //To change body of created methods use File | Settings | File Templates.
  }

  //TODO: read position from file
  public Position getLatestPositionForTerm(String term) throws Exception {
    return headsDAO.getLatestPos(term);
  }

  /**
   * This method has to be called once at the end of a indexing
   */
  public void saveHeads() throws Exception {
    System.out.println("saving" + changedHeads.keySet().size() + "heads");
    for (String changedTerm : changedHeads.keySet()) {
//      System.out.println(changedTerm);
      long changedPos = termBytesWriter.get(changedTerm).getPosition();
      long changedBlockStart=termBytesWriter.get(changedTerm).currentBlockStart;
      Date changedDate = changedHeads.get(changedTerm);
      headsDAO.addHead(changedTerm, changedPos,changedBlockStart, changedDate);
    }
    System.out.println("flushing heads");
    headsDAO.flushInsert();

  }
}
