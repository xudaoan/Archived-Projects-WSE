package tweet_search.search.index.persistent;

import tweet_search.search.Constants;
import tweet_search.search.index.InvertedIndex;
import tweet_search.search.index.InvertedIndexAppendable;
import tweet_search.search.index.TweetPosting;

import java.io.File;
import java.io.IOException;
import java.util.Date;

/**
 * An implementation of InvertedIndex that is stored in files.
 * Each term has a file that stores the posting list of it.
 */
public class InvertedIndexInDisk implements InvertedIndexAppendable,InvertedIndex {
  File indexFolder;

  public InvertedIndexInDisk(File indexFolder) {
    this.indexFolder = indexFolder;
  }
  //TODO: delete this variable
//  static HashSet<String> words=new HashSet<String>();
  @Override
  public void addPosting(String term, TweetPosting tweetTermPosting, Date createdAt) throws IOException {
//    if (!words.contains(term))
//    {
//      System.out.println(term);
//      words.add(term);
//    }
    new TermPostingFileWriter(getTermIndexFile(term)).appendPosting(tweetTermPosting);
  }

  private File getTermIndexFile(String term) {
    int termHashCode=term.hashCode();
    File subFolder= new File(indexFolder,String.valueOf(termHashCode%3000));
    subFolder.mkdirs();
    return new File(subFolder,term.hashCode()+".idx");
  }


  /**
   * Current using naive implementation, TODO: add cache, offset and use binary search
   * @param term
   * @param idUpperBound
   * @return
   */
  @Override
  public long nextTweetIdForTerm(String term, long idUpperBound) throws IOException {
    TermPostingFileReverseReader postingReader=new TermPostingFileReverseReader(getTermIndexFile(term));
     postingReader.seekToEndOfFile();//TODO: when have cache, it's not necessary to seek to End every time
    while(postingReader.hasNext()){
      TweetPosting posting=postingReader.nextPosting();
      if (posting.getTweetIndexId()<idUpperBound)
        return posting.getTweetIndexId();
    }
    return Constants.ID_NOT_FOUND;  //To change body of implemented methods use File | Settings | File Templates.
  }

  /**
   * Naive implementation, TODO: add cache, binary search for tweet Posting
   * @param term
   * @param tweetIndexId
   * @param previousPos
   * @return
   */
  @Override
  public Integer nextPosOfTermInTweet(String term, long tweetIndexId, Integer previousPos) throws IOException {
    TermPostingFileReverseReader postingReader=new TermPostingFileReverseReader(getTermIndexFile(term));
    postingReader.seekToEndOfFile();//TODO: when have cache, it's not necessary to seek to End every time

    TweetPosting posting;
    while(postingReader.hasNext()){
      posting=postingReader.nextPosting();
      if(posting.getTweetIndexId()==tweetIndexId){
        for(int pos:posting.getOccurrences()){
          if (pos>previousPos)
            return pos;
        }
        return Constants.INFINITY_POS;//no occur
      }
    }

    return Constants.INFINITY_POS; //no posting
  }
}
