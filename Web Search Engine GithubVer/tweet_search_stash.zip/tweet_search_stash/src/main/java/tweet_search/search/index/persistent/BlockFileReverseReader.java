package tweet_search.search.index.persistent;

import tweet_search.io.ReverseByteReader;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.nio.channels.FileChannel;
/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/29/13
 * Time: 6:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlockFileReverseReader implements ReverseByteReader {
  FileChannel channel;
  long position;
  long previousBlockStart;
  long dataBoundary;
  long currentBlockStart;
  private long currentBlockSize;

  public BlockFileReverseReader(FileChannel channel, long position,long blockStart) throws IOException {
    this.channel = channel;
    this.position = position;
    this.currentBlockStart=blockStart;
    readBlockMetaData();
  }


  public boolean hasPreviousByte() {
    return (position!= dataBoundary)||hasPreviousBlock();  //To change body of created methods use File | Settings | File Templates.
  }

  private boolean hasPreviousBlock() {
    return previousBlockStart !=-1;
  }

  public void forwardOneByte() throws IOException {
    position++;
    channel.position(position);
  }

  public byte previousByte() throws IOException {
    //TODO can use cache
    //TODO: don't need to calculate dataBoundary every time
//    readBlockMetaData();
    if (position== dataBoundary)
      loadEndOfPreviousBlock();

    position--;//backward one byte
    channel.position(position);
    byte result=readForwardByte();
    channel.position(position);
    return result;
  }

  private void readBlockMetaData() throws IOException {
    dataBoundary =getBlockDataStartingPoint();
  }

  //TODO
  private void loadEndOfPreviousBlock() throws IOException {
//    if (previousBlockStart==0)
    if(!hasPreviousBlock()){
            throw new RuntimeException("reached end of File");
    }
    currentBlockStart= previousBlockStart;
    readBlockMetaData();
    position=currentBlockStart+currentBlockSize;
//    System.out.println("current blockStart "+currentBlockStart);
//    System.out.println("current blockSize "+currentBlockSize);
//    System.out.println("position is "+position+" "+channel.size());

    channel.position(position);
//    System.out.println("ending position: "+position);
    readBlockMetaData();
    //To change body of created methods use File | Settings | File Templates.
  }

  private long getBlockDataStartingPoint() throws IOException {
//    long blockCount=(position-1)/BLOCK_SIZE;
//    long blockStart=blockCount*BLOCK_SIZE;

    channel.position(currentBlockStart);
    ByteBuffer metaByteBuffer=ByteBuffer.allocate(8*2);
    channel.read(metaByteBuffer);
    metaByteBuffer.flip();
    LongBuffer lbf=metaByteBuffer.asLongBuffer();
    previousBlockStart =lbf.get();
    currentBlockSize=lbf.get();

    long dataStartPosition=channel.position();
    channel.position(position);//restore position
    return dataStartPosition;
  }




  private byte readForwardByte() throws IOException {
    ByteBuffer buffer= ByteBuffer.allocate(1);
    channel.read(buffer);
    return buffer.get(0);  //To change body of created methods use File | Settings | File Templates.
  }

  public long getPosition() {
    return position;
  }
}
