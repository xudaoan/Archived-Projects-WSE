package tweet_search.search.index.memory;

import tweet_search.corpus.TweetsDAO;
import tweet_search.search.index.IndexBuilder;
import tweet_search.search.index.IndexedStatus;
import tweet_search.search.index.InvertedIndexAppendable;
import tweet_search.search.index.TweetPosting;
import tweet_search.search.tweets.TweetTokenizer;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.json.DataObjectFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 3:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class IndexBuilderImpl implements IndexBuilder {
  private final TweetTokenizer tweetTokenizer;
  private InvertedIndexAppendable invertedIndex;

  public IndexBuilderImpl(InvertedIndexAppendable invertedIndex) {
    this.invertedIndex = invertedIndex;
    this.tweetTokenizer=new TweetTokenizer();
  }


  public void indexTweet(IndexedStatus tweet) throws Exception {
//    String[] terms = getWordsFromTweet(tweet);
    addToIndex(tweet.getIndexID(), tweet.getStatus());
  }

  private long addToIndex(long index_id, Status tweet) throws Exception {
    HashMap<String,TweetPosting> postingMap=new HashMap<String, TweetPosting>();

    Map<Integer,String> posTokenMap=tweetTokenizer.tokenize(tweet.getText());
    for(Integer pos:posTokenMap.keySet()){
      String term=posTokenMap.get(pos);
      if(!postingMap.containsKey(term)){
        postingMap.put(term,new TweetPosting(index_id));
      }
      postingMap.get(term).addOccurrence(pos+1);//TODO: BUG!!! OCC can not be 0, since 0 is the separator!!!
    }


    for(String term:postingMap.keySet()){
      invertedIndex.addPosting(term,postingMap.get(term),tweet.getCreatedAt());
    }
    return index_id;
  }

  private String[] getWordsFromTweet(Status tweet) {
    return tweet.getText().split(" ");  //To change body of created methods use File | Settings | File Templates.
  }

}
