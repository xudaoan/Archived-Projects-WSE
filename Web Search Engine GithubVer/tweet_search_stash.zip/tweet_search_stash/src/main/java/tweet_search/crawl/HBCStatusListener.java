package tweet_search.crawl;

import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.json.DataObjectFactory;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/24/13
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class HBCStatusListener implements StatusListener {
    @Override
    public void onStatus(Status status) {
      System.out.println(DataObjectFactory.getRawJSON(status));
    }

    @Override
    public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {}

    @Override
    public void onTrackLimitationNotice(int limit) {}

    @Override
    public void onScrubGeo(long user, long upToStatus) {}

    @Override
    public void onException(Exception e) {}
}
