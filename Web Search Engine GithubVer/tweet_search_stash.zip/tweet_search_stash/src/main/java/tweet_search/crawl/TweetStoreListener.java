package tweet_search.crawl;

//import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.json.DataObjectFactory;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TweetStoreListener implements StatusListener {
  private final String corpusDir;
  String folderName=null;
  public static final int MAX_FILE_COUNT=5000;
  public TweetStoreListener(String corpusDir) {
    this.corpusDir=corpusDir;
  }
  private int count = 0;
  private void storeJSON(Status status) throws IOException {
    String rawJSON = DataObjectFactory.getRawJSON(status);

    if(count==MAX_FILE_COUNT)
      count=0;
    if (count==0){
      //create folder with current timestamp
      setCurrentTimeFolder();
    }

    String fileName = folderName + status.getId() + ".json";
    if (new File(fileName).exists()) {
      System.err.println("duplicated: " + fileName);
      return;
    }
//    System.out.println(count++);
    FileOutputStream fos = null;
    OutputStreamWriter osw = null;
    BufferedWriter bw = null;
    try {
      fos = new FileOutputStream(fileName);
      osw = new OutputStreamWriter(fos, "UTF-8");
      bw = new BufferedWriter(osw);
      bw.write(rawJSON);
      bw.flush();
    } finally {
      if (bw != null) {
        try {
          bw.close();
        } catch (IOException ignore) {
        }
      }
      if (osw != null) {
        try {
          osw.close();
        } catch (IOException ignore) {
        }
      }
      if (fos != null) {
        try {
          fos.close();
        } catch (IOException ignore) {
        }
      }
    }
  }

  private void setCurrentTimeFolder() {
    String timeStr=getCurrentTimeString();
    String[] fields=timeStr.split("-");
    String year=fields[0];
    String month=fields[1];
    String day=fields[2];
    String dayFolder=year+"-"+month+"-"+day+"/";
    folderName=corpusDir+dayFolder+timeStr+"/";
    new File(folderName).mkdirs();
    System.out.println("persisting tweets into: "+folderName);
  }

  private String getCurrentTimeString() {
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
    Calendar cal = Calendar.getInstance();
    return dateFormat.format(cal.getTime());
  }

  public void onStatus(Status status) {
    try {
      storeJSON(status);
    } catch (IOException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
  }

  public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {
  }

  public void onTrackLimitationNotice(int numberOfLimitedStatuses) {
  }

  public void onScrubGeo(long l, long l2) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

//  public void onStallWarning(StallWarning stallWarning) {
//    System.out.println("Warning: " + stallWarning.toString());
//    //To change body of implemented methods use File | Settings | File Templates.
//  }

  public void onException(Exception ex) {
    ex.printStackTrace();
  }

}