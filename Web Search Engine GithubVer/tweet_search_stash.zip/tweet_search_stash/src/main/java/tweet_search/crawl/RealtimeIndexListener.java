package tweet_search.crawl;

import tweet_search.runner.RealtimeIndexer;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/13/13
 * Time: 4:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class RealtimeIndexListener implements StatusListener {
  RealtimeIndexer indexer;
  public RealtimeIndexListener(String indexFilePath,String headsDbPath,String tweetsDbPath) throws Exception {
    indexer=new RealtimeIndexer(indexFilePath,headsDbPath,tweetsDbPath);
  }

  @Override
  public void onStatus(Status status) {
    //To change body of implemented methods use File | Settings | File Templates.
    try {
      indexer.index(status);
      System.out.println(status.getText());
    } catch (Exception e) {
      System.out.println("[ERROR] can not index ");
      e.printStackTrace();

    }
  }

  @Override
  public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public void onTrackLimitationNotice(int i) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public void onScrubGeo(long l, long l2) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public void onException(Exception e) {
    //To change body of implemented methods use File | Settings | File Templates.
  }
}
