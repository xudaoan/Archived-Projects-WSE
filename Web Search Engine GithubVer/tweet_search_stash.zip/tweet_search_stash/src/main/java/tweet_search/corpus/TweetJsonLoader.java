package tweet_search.corpus;

import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.json.DataObjectFactory;

import java.io.*;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/28/13
 * Time: 5:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class TweetJsonLoader {
  public static Status loadFromFile(File f) throws IOException, TwitterException {
    return DataObjectFactory.createStatus(getStringContent(f));
  }
  public static String getStringContent(File fileName) throws IOException {
    FileInputStream fis = null;
    InputStreamReader isr = null;
    BufferedReader br = null;
    try {
      fis = new FileInputStream(fileName);
      isr = new InputStreamReader(fis, "UTF-8");
      br = new BufferedReader(isr);
      return br.readLine();
    } finally {
      if (br != null) {
        try {
          br.close();
        } catch (IOException ignore) {
        }
      }
      if (isr != null) {
        try {
          isr.close();
        } catch (IOException ignore) {
        }
      }
      if (fis != null) {
        try {
          fis.close();
        } catch (IOException ignore) {
        }
      }
    }
  }
}
