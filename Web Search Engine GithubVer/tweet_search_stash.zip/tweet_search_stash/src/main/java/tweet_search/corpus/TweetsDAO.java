package tweet_search.corpus;

import tweet_search.search.index.IndexedStatus;
import twitter4j.Status;
import twitter4j.Tweet;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TweetsDAO {
  IndexedStatus addTweet(Status tweet);
  IndexedStatus addTweet(String tweetJson);
  Status getTweetByIndexID(long indexID);//indexID is the self-increment ID stored in Database, not the TweetID for each Tweet
}
