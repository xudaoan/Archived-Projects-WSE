package tweet_search.corpus;

import tweet_search.search.index.IndexedStatus;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.json.DataObjectFactory;

import java.util.HashMap;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/25/13
 * Time: 4:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class TweetsDAOInMemory implements TweetsDAO {
  HashMap<Long,Status> tweetsHashMap=new HashMap<Long, Status>();
  long autoId=0;
  @Override
  public IndexedStatus addTweet(Status tweet) {
    tweetsHashMap.put(autoId++,tweet);
    return new IndexedStatus(autoId-1,tweet);
  }

  @Override
  public IndexedStatus addTweet(String tweetJson) {
    try {
      Status t= DataObjectFactory.createStatus(tweetJson);
      return addTweet(t);
    } catch (TwitterException e) {
      e.printStackTrace();
    }
    throw new UnsupportedOperationException("can not add json");
  }

  @Override
  public Status getTweetByIndexID(long indexID) {
    return tweetsHashMap.get(indexID);  //To change body of implemented methods use File | Settings | File Templates.
  }
}
