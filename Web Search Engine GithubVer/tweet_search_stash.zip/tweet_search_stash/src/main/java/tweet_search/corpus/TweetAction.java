package tweet_search.corpus;

import twitter4j.Status;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/2/13
 * Time: 4:47 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TweetAction {
  public void processTweet(Status tweet);
}
