package tweet_search.corpus;

import tweet_search.search.index.IndexedStatus;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.json.DataObjectFactory;

import java.sql.*;
import java.util.Properties;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/28/13
 * Time: 4:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class TweetsSqliteDAO implements TweetsDAO {
  public static final int FETCH_SIZE = 100000;
  private final Connection conn;
  PreparedStatement insertStatement = null;

  public TweetsSqliteDAO(String dbpath) throws Exception {
//    final Properties p = new Properties();
//    p.setProperty("journal_mode", "WAL");
    Class.forName("org.sqlite.JDBC");
    conn = DriverManager.getConnection("jdbc:sqlite:" + dbpath);
    Statement statement = conn.createStatement();
    statement.execute("PRAGMA journal_mode=WAL;");
    statement.close();
    ensureTable();
  }
  @Override
  public IndexedStatus addTweet(Status tweet) {
//    if (jsonStr == null)
      String jsonStr = DataObjectFactory.getRawJSON(tweet);
    if (jsonStr==null)
      throw new RuntimeException("[ERROR] can not load json string");
    return addTweet(jsonStr);
  }

  int count = 0;
  public void processEach(TweetAction action) throws SQLException, TwitterException {
      Statement st=conn.createStatement();
      st.setFetchSize(FETCH_SIZE);
      ResultSet rs=st.executeQuery("select * from tweets");
      while(rs.next()){
        String json=rs.getString("tweet_json");
        Status tweet=DataObjectFactory.createStatus(json);
        action.processTweet(tweet);
      }
    rs.close();
  }

  public IndexedStatus addTweet(String jsonStr) {


    if (jsonStr == null)
      throw new RuntimeException("can't get Json from Tweet");
    try {
      Status tweet = DataObjectFactory.createStatus(jsonStr);
      if (insertStatement == null) {
        insertStatement = conn.prepareStatement(
                "insert into tweets(tweet_json) values (?);");
      }
//      insertStatement.setLong(1, indexID);
//      insertStatement.setString(1, String.valueOf(tweet.getId()));

      insertStatement.setString(1, jsonStr);
//      if ((count++) % 10000 == 0) {
//        insertStatement.executeBatch();
//      } else {
//        insertStatement.addBatch();
//      }
      insertStatement.execute();

      ResultSet ids=insertStatement.getGeneratedKeys();
      if(ids.next()){
        long newID = ids.getLong(1);
        ids.close();
        return new IndexedStatus(newID,tweet);
      }else{
        throw new RuntimeException("can not get AUTO-GENERATED ID");
      }

//      insertStatement.close();

    } catch (Exception e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      throw new RuntimeException("can not add tweet");
    }
  }

  @Override
  public Status getTweetByIndexID(long indexID) {
    try {
      String selectSQL = "SELECT * FROM tweets WHERE index_id = ?";
      PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
      preparedStatement.setLong(1, indexID);


      ResultSet rs = preparedStatement.executeQuery();
      while (rs.next()) {
        String jsonString = rs.getString("tweet_json");
        rs.close();
        return DataObjectFactory.createStatus(jsonString);
      }
    } catch (Exception e) {

      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }



  public void ensureTable() throws Exception {
    Statement stat = conn.createStatement();
    stat.executeUpdate("create table if not exists tweets (" +
            "index_id INTEGER PRIMARY KEY AUTOINCREMENT," +
//            "tweet_id INTEGER, " +
            "tweet_json TEXT, " +
//            "topic VARCHAR(50), " +
//            "sentiment VARCHAR(25), " +
            "created_at DATETIME) ;");
  }

}
