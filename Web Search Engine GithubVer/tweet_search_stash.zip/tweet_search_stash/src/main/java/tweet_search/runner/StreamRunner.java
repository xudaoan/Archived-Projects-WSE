package tweet_search.runner;

import tweet_search.crawl.RealtimeIndexListener;
import tweet_search.crawl.TweetStoreListener;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;

import java.util.HashSet;

/**
* Created with IntelliJ IDEA.
* User: tsdeng
* Date: 4/20/13
* Time: 9:32 PM
* To change this template use File | Settings | File Templates.
*/
public class StreamRunner {

  public static void main(String[] args) throws Exception {
//    if (args.length==0) {
//      throw new RuntimeException("please specify where to save corpus");
//    }
//    final String corpusDir = args[0];
    ConfigurationBuilder cb = new ConfigurationBuilder();
    cb.setDebugEnabled(true)
            .setOAuthConsumerKey("JXGO4GRlZysXnGq4uoRqw")
            .setOAuthConsumerSecret("JOhtyw6fCipt59wKR0jvHOAnizxtEuMNMu07kY0a0")
            .setOAuthAccessToken("186757020-rGDf1II5tksSq04TKj81A17qwuDDGtV64Xz5AOek")
            .setOAuthAccessTokenSecret("6AMRKhUb7Fzh9j4EOYXJONuZpsoy2sagnRmT0FwA")
            .setJSONStoreEnabled(true);
    Configuration conf = cb.build();

    StatusListener listener = new RealtimeIndexListener("tmp/real_time/index.bin","tmp/real_time/heads.sqlite","tmp/real_time/tweets.sqlite");
    TwitterStream twitterStream = new TwitterStreamFactory(conf).getInstance();
    // sample() method internally creates a thread which manipulates TwitterStream and calls these adequate listener methods continuously.
    twitterStream.addListener(listener);

    twitterStream.sample();
//    long[] users={186757020};
//    twitterStream. filter(new FilterQuery(users));
  }




}


