package tweet_search.runner;

import tweet_search.corpus.TweetsDAO;
import tweet_search.corpus.TweetsSqliteDAO;
import tweet_search.search.index.IndexedStatus;
import tweet_search.search.index.memory.IndexBuilderImpl;
import tweet_search.search.index.persistent.InvertedIndexSingleFile;
import twitter4j.Status;

import java.io.File;
import java.io.RandomAccessFile;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/13/13
 * Time: 4:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class RealtimeIndexer {

  public String INDEX_FILE_PATH;
  public String HEADS_DB_PATH ;
  public String TWEETS_DB_PATH;

   IndexBuilderImpl builder;
   InvertedIndexSingleFile index;
   TweetsDAO tweetsDAO;



  public RealtimeIndexer(String indexFilePath, String headsDbPath, String tweetsDbPath) throws Exception{
    this.INDEX_FILE_PATH = indexFilePath;
    this.HEADS_DB_PATH = headsDbPath;
    this.TWEETS_DB_PATH = tweetsDbPath;
    tweetsDAO = new TweetsSqliteDAO(TWEETS_DB_PATH);

    index = new InvertedIndexSingleFile(new RandomAccessFile(INDEX_FILE_PATH, "rw").getChannel(), HEADS_DB_PATH);
    builder = new IndexBuilderImpl(index);
  }

  public void index(Status tweet) throws Exception{
    IndexedStatus t=tweetsDAO.addTweet(tweet);
    builder.indexTweet(t);
  }

  public void finish() throws Exception {
    index.saveHeads();
  }

}
