package tweet_search.runner;

import tweet_search.corpus.TweetsSqliteDAO;
import tweet_search.search.Constants;
import tweet_search.search.SearchEngine;
import tweet_search.search.analysis.ScoredTweetsStats;
import tweet_search.search.analysis.TimeGetter;
import tweet_search.search.index.IndexedStatus;
import tweet_search.search.index.InvertedIndexSearcher;
import tweet_search.search.index.ScoredStatus;
import tweet_search.search.index.persistent.IndexHeadsDAO;
import tweet_search.search.index.persistent.InvertedIndexSingleFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.RandomAccessFile;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/2/13
 * Time: 5:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExampleSearch {
  public static final String INDEX_FOLDER="data/";
  public static final String TWEETS_DB_PATH = INDEX_FOLDER+"full_tweets.sqlite";

  public static final String INDEX_PATH = INDEX_FOLDER+"single_index";

//  static String headObjPath="tmp/bigIndex/heads.bin";
  static String headsDBPath=INDEX_FOLDER+"heads.sqlite";

  static SearchEngine searchEngine;

  public static void main(String[] args) throws Exception {
    System.out.println("started");
    searchEngine=new SearchEngine(INDEX_PATH,headsDBPath,TWEETS_DB_PATH);
    doSearch();
  }


  private static void doSearch() throws Exception {
    String input;

    while (!(input = readInput()).equals("exit")) {
      String[] words = input.split(" ");
      List<ScoredStatus> result=searchEngine.doSearch(words).getResults();

      int counter = result.size();
      for(ScoredStatus t:result){
        Long timeDiff = t.getStatus().getCreatedAt().getTime() - TimeGetter.getLong();
        timeDiff = timeDiff / 60 / 1000;
        
//        System.out.println(t.getScore() +" | "+t.getStatus().getId()+" "
//                + " | Mins before: " + timeDiff
//                + " | "+ t.getStatus().getUser().getScreenName()
//                +" | listCount:"+t.getStatus().getUser().getListedCount()
//                +" | followerCount:"+t.getStatus().getUser().getFollowersCount()
////                +" |friendCount:"+t.getStatus().getUser().getFriendsCount()
////                +" |location:"+t.getStatus().getUser().getLocation()
////                +" |"+t.getStatus().getGeoLocation()
//                +" |"+t.getStatus().getSource()
//                +" | "+t.getStatus().getText());
        
        System.out.println(
            String.format("| %7.4f",t.getScore())
                + " | " + String.format("%-8d",(-timeDiff))
                + " | " + String.format("%-9d", t.getStatus().getUser().getListedCount())
                + " | " + String.format("%d", t.getStatus().getUser().getFollowersCount())
                + " \n| " + counter + " >> " + t.getStatus().getText().replaceAll("\n", " "));
        System.out.println("+---------+----------+-----------+------------------------");
        counter --;

      }
      System.out.println("|  Score  | Mins Ago | ListCount | FollowerCount ");
      System.out.println("+---------+----------+-----------+------------------------");
    }
  }

  private static String readInput() {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter words to search: ");
    return scanner.nextLine();
  }
}
