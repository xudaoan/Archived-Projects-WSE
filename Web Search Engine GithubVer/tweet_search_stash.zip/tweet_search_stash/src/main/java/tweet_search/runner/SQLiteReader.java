package tweet_search.runner;

import tweet_search.corpus.TweetAction;
import tweet_search.corpus.TweetsSqliteDAO;
import twitter4j.Status;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 5/1/13
 * Time: 12:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class SQLiteReader {
  static int count=0;
  public static void main(String[] args) throws Exception {
//    Class.forName("org.sqlite.JDBC");
//    Connection conn = DriverManager.getConnection("jdbc:sqlite:" + "/Volumes/slim/tweets.sqlite");
//    Statement st = conn.createStatement();
//    ResultSet rs = st.executeQuery("select count(*) from tweets");
//    System.out.println(rs.getInt(0));

    TweetsSqliteDAO dao = new TweetsSqliteDAO("/Volumes/slim/tweets.sqlite");
    TweetAction action = new TweetAction() {
      @Override
      public void processTweet(Status tweet) {
        //System.out.println(tweet.getText());
        if(count++%1000==0){
          System.out.println(count);
        }
      }
    };

    dao.processEach(action);

  }
}
