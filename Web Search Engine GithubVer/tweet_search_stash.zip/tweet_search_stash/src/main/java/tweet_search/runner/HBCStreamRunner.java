package tweet_search.runner;

import com.twitter.hbc.ClientBuilder;
import com.twitter.hbc.core.Constants;
import com.twitter.hbc.core.endpoint.StatusesSampleEndpoint;
import com.twitter.hbc.core.processor.StringDelimitedProcessor;
import com.twitter.hbc.httpclient.BasicClient;
import com.twitter.hbc.httpclient.auth.Authentication;
import com.twitter.hbc.httpclient.auth.OAuth1;

import java.util.concurrent.*;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/24/13
 * Time: 11:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class HBCStreamRunner {
  public static void main(String[] args) throws Exception {
    String consumerKey = "JXGO4GRlZysXnGq4uoRqw";
    String consumerSecret = "JOhtyw6fCipt59wKR0jvHOAnizxtEuMNMu07kY0a0";
    String accessToken = "186757020-rGDf1II5tksSq04TKj81A17qwuDDGtV64Xz5AOek";
    String accessTokenSecret = "6AMRKhUb7Fzh9j4EOYXJONuZpsoy2sagnRmT0FwA";


    // Create an appropriately sized blocking queue
    BlockingQueue<String> queue = new LinkedBlockingQueue<String>(10000);

    // Define our endpoint: By default, delimited=length is set (we need this for our processor)
    // and stall warnings are on.
    StatusesSampleEndpoint endpoint = new StatusesSampleEndpoint();

    Authentication auth = new OAuth1(consumerKey, consumerSecret, accessToken, accessTokenSecret);
    // Authentication auth = new BasicAuth(username, password);

    // Create a new BasicClient. By default gzip is enabled.
    BasicClient client = new ClientBuilder()
            .hosts(Constants.STREAM_HOST)
            .endpoint(endpoint)
            .authentication(auth)
            .processor(new StringDelimitedProcessor(queue))
            .build();

    client.connect();
    while(!client.isDone()){
      System.out.println(queue.take());
    }
//    // Create an executor service which will spawn threads to do the actual work of parsing the incoming messages and
//    // calling the listeners on each message
//    int numProcessingThreads = 4;
//    ExecutorService service = Executors.newFixedThreadPool(numProcessingThreads);
//
//    // Wrap our BasicClient with the twitter4j client
//    Twitter4jStatusClient t4jClient = new Twitter4jStatusClient(
//            client, queue, Lists.newArrayList(new HBCStatusListener()), service);
//
//    // Establish a connection
//    t4jClient.connect();
//    for (int threads = 0; threads < numProcessingThreads; threads++) {
//      // This must be called once per processing thread
//      t4jClient.process();
//    }
//    t4jClient.process();
//    service.wait();
//
//    client.stop();
  }
}
