package tweet_search.runner;

import tweet_search.corpus.TweetsSqliteDAO;
import tweet_search.search.index.IndexedStatus;
import tweet_search.search.index.memory.IndexBuilderImpl;
import tweet_search.search.index.persistent.InvertedIndexSingleFile;
import tweet_search.corpus.TweetsDAO;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.json.DataObjectFactory;

import java.io.*;
import java.util.Arrays;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/28/13
 * Time: 4:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExampleTweetsIndexer {
  public static final String INDEX_FOLDER = "tmp/full_test_exp/";
  public static final String CORPUS_FOLDER = "/Volumes/slim/Develop/tweet_corpus";

  public static final String INDEX_FILE_PATH = INDEX_FOLDER+"single_index";
  public static final String HEADS_DB_PATH = INDEX_FOLDER+"heads.sqlite";
  public static final String TWEETS_DB_PATH = INDEX_FOLDER+"full_tweets.sqlite";

  static IndexBuilderImpl builder;
  static InvertedIndexSingleFile index;
  static TweetsDAO tweetsDAO;

  static {
    try {
      tweetsDAO = new TweetsSqliteDAO(TWEETS_DB_PATH);
    } catch (Exception e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
  }

  public static void main(String[] args) throws Exception {
    String indexFolderPath = INDEX_FOLDER;
    new File(indexFolderPath).mkdirs();
    File corpusFolder = new File(CORPUS_FOLDER);
    index = new InvertedIndexSingleFile(new RandomAccessFile(INDEX_FILE_PATH, "rw").getChannel(), HEADS_DB_PATH);
    builder = new IndexBuilderImpl(index);

    indexFolder(corpusFolder);

    index.saveHeads();
  }

  static long count = 0;

  private static void indexFolder(File folder) throws IOException, TwitterException {
    File[] files = folder.listFiles();
    Arrays.sort(files);
    for (File f : files) {
      if (f.isDirectory())
        indexFolder(f);
      else {
        //if name ends in json index the file
        if (!f.getName().endsWith(".json"))
          continue;
        try {
          IndexedStatus t=tweetsDAO.addTweet(readFirstLine(f));
          builder.indexTweet(t);
        } catch (Exception e) {
          System.out.println("[Fatal] Can not index " + f.getName());
          e.printStackTrace();
        }
        if ((++count) % 100 == 0) {
          System.out.println(count);
        }

      }
    }
  }


  private static String readFirstLine(File fileName) throws IOException {
    FileInputStream fis = null;
    InputStreamReader isr = null;
    BufferedReader br = null;
    try {
      fis = new FileInputStream(fileName);
      isr = new InputStreamReader(fis, "UTF-8");
      br = new BufferedReader(isr);
      return br.readLine();
    } finally {
      if (br != null) {
        try {
          br.close();
        } catch (IOException ignore) {
        }
      }
      if (isr != null) {
        try {
          isr.close();
        } catch (IOException ignore) {
        }
      }
      if (fis != null) {
        try {
          fis.close();
        } catch (IOException ignore) {
        }
      }
    }
  }
}
