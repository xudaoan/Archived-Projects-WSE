package tweet_search.io;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * This class will decode number series in revers order, starting from current position, readBack one integer
 * For example:
 *  if the file containing numbers 1,2,3
 *  The decoder will decode 3,2,1 when started from the end of the file
 */
public class NumberSeriesReverseDecoder {
  FileChannel fileChannel;
  /**
   * The reverse Decoder requires FileInputStream, since it reads the bytes in reverse order;
   * @param fileChannel
   */
  public NumberSeriesReverseDecoder(FileChannel fileChannel) {
    this.fileChannel=fileChannel;
  }
  //TODO: Add buffer to increase read speed
  public long next() throws IOException {
      long result=0;
      int thisByte=readAByteBackward();
      //if FirstByte does not start with 1, then raise exception
      if ((thisByte&0x80)==0)
        throw new RuntimeException("[decoding error] wrong position, first bit of current byte is not 1");

      result=(thisByte&0x7f);//get rid of the first 1 bit of the byte, and added to result
      if(fileChannel.position()==0l)
        return result; // only one number

      int byteCount=1;
      while(hasNext()){
        thisByte=readAByteBackward();
        if(!isFirstBitOne(thisByte)){
          long longByte=(long)thisByte;//avoid int overflow
          result=(longByte<<(7*byteCount))+result;
          byteCount++;
        }else{
          forwardOneByte();
          break;
        }
      }
    return result;


  }

  private void forwardOneByte() throws IOException {
    fileChannel.position(fileChannel.position()+1);
  }

  private boolean isFirstBitOne(int thisByte) {
    return ((thisByte&0x80)!=0);  //To change body of created methods use File | Settings | File Templates.
  }

  public boolean hasNext() throws IOException {
    return (fileChannel.position()!=0L);
  }
  private Byte readAByteBackward() throws IOException {

    long position=fileChannel.position();
    if (position==0L)
      throw new IOException("reached beginning");
    fileChannel.position(position-1);

    ByteBuffer bf=ByteBuffer.allocate(1);
    fileChannel.read(bf);
    fileChannel.position(position-1);
    return bf.get(0);  //To change body of created methods use File | Settings | File Templates.
  }

  public void seekBack(int i) throws IOException {
    fileChannel.position(fileChannel.position()+1);
  }

  public void seekToEnd() throws IOException {
    fileChannel.position(fileChannel.size());
  }
}
