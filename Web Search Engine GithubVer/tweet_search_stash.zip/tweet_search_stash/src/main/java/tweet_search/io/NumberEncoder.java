package tweet_search.io;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/30/13
 * Time: 3:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class NumberEncoder {

  ByteWriter byteWriter;

  public NumberEncoder(ByteWriter byteWriter) {
    this.byteWriter = byteWriter;
  }

  public void writeNumber(long i) throws IOException {
    byteWriter.writeBytes(getEncodedBuffer(i));
  }
  /**
   * given a value, return a *flipped* variable bytes encoded bytebuffer
   * the buffer can be directly used: FileChannel#write(buffer)
   * @param value
   * @return flipped byte buffer
   */
  public static ByteBuffer getEncodedBuffer(long value) {
//    B
    ByteBuffer buffer=ByteBuffer.allocate(100);//100 byte for a single number is more than enough

    if(value < 0)
      throw new RuntimeException("The value to be encoded by ByteAligned not positive");

    //10000000   1 means the last byte to read, following are 0s
    if(value == 0){
      buffer.put((byte) 0x80);
      buffer.flip();
      return buffer;
    }

    byte[] byteArr = new byte[100];
    int count = 0;
    while(value > 0){
      // 0x7f=011111111
      byteArr[count] = (byte)(value & 0x7f);//get first 7 bits
      count++;
      value = value >>> 7;
    }
    count --;
    byteArr[0] = (byte) (byteArr[0] | 0x80);//set the firt bit of last byte to 1
    while(count >= 0){
      buffer.put(byteArr[count]);
      count --;
    }

    buffer.flip();
    return buffer;

  }
}
