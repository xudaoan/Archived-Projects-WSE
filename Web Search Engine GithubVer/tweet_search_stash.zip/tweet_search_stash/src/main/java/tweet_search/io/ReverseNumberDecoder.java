package tweet_search.io;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/30/13
 * Time: 5:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReverseNumberDecoder {
  ReverseByteReader reverseByteReader;

  public ReverseNumberDecoder(ReverseByteReader reverseByteReader) {
    this.reverseByteReader = reverseByteReader;
  }

  public boolean hasPrevious(){
    return reverseByteReader.hasPreviousByte();
  }
  public long previousNumber() throws IOException {
    long result=0;
    int thisByte=reverseByteReader.previousByte();
    //if FirstByte does not start with 1, then raise exception
    if ((thisByte&0x80)==0)
      throw new RuntimeException("[decoding error] wrong position, first bit of current byte is not 1");

    result=(thisByte&0x7f);//get rid of the first 1 bit of the byte, and added to result


    int byteCount=1;
    while(reverseByteReader.hasPreviousByte()){
      thisByte=reverseByteReader.previousByte();
      if(!isFirstBitOne(thisByte)){
        long longByte=(long)thisByte;//avoid int overflow
        result=(longByte<<(7*byteCount))+result;
        byteCount++;
      }else{
        //TODO: forwardOneByte may cause trouble when bytes are cross blocks, maybe add a readWithoutAdvanceMethod
        reverseByteReader.forwardOneByte();
        break;
      }
    }
    return result;

  }
  private boolean isFirstBitOne(int thisByte) {
    return ((thisByte&0x80)!=0);  //To change body of created methods use File | Settings | File Templates.
  }
}
