package tweet_search.io;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/30/13
 * Time: 3:44 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ByteWriter {
  public void writeBytes(ByteBuffer buffer) throws IOException;
}
