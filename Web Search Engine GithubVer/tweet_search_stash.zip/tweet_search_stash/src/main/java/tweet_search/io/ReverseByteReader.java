package tweet_search.io;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/30/13
 * Time: 5:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ReverseByteReader {
  public boolean hasPreviousByte();
  public byte previousByte() throws IOException;
  void forwardOneByte() throws IOException;
}
