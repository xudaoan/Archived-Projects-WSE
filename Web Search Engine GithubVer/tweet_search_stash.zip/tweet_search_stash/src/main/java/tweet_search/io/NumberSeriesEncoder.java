package tweet_search.io;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/24/13
 * Time: 2:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class NumberSeriesEncoder {
  OutputStream outputStream;

  public NumberSeriesEncoder(OutputStream outputStream) {
    this.outputStream = outputStream;
  }

  public void put(long value) throws IOException {
    if(value < 0)
      throw new RuntimeException("The value to be encoded by ByteAligned not positive");

    //10000000   1 means the last byte to read, following are 0s
    if(value == 0){
      outputStream.write(0x80);
      return;
    }

    byte[] byteArr = new byte[100];
    int count = 0;
    while(value > 0){
      // 0x7f=011111111
      byteArr[count] = (byte)(value & 0x7f);//get first 7 bits
      count++;
      value = value >>> 7;
    }
    count --;
    byteArr[0] = (byte) (byteArr[0] | 0x80);//set the firt bit of last byte to 1
    while(count >= 0){
      outputStream.write(byteArr[count]);
      count --;
    }
  }

  public void closeStream() throws IOException {
    outputStream.close();
  }

  public void flush() throws IOException {
    outputStream.flush();
  }
}
