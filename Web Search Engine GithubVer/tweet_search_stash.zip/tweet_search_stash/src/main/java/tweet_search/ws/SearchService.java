package tweet_search.ws;

import com.sun.jersey.api.NotFoundException;
import tweet_search.search.SearchEngine;
import tweet_search.search.SearchResult;
import tweet_search.search.index.ScoredStatus;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;



import javax.ws.rs.*;

import java.util.*;
import javax.ws.rs.core.MediaType;

/**
 * curl -X GET http://127.0.0.1:9090/WebService/tweetsent/topic/ipad
 */

@Path("search_service")
public class SearchService {
  public static final String INDEX_FOLDER="tmp/full_test_exp/";
  public static final String TWEETS_DB_PATH = INDEX_FOLDER+"full_tweets.sqlite";

  public static final String INDEX_PATH = INDEX_FOLDER+"single_index";
  static String headsDBPath=INDEX_FOLDER+"heads.sqlite";

  static SearchEngine searchEngine;

  static{
    try {
      searchEngine=new SearchEngine("tmp/real_time/index.bin","tmp/real_time/heads.sqlite","tmp/real_time/tweets.sqlite");;
    } catch (Exception e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
  }
  @Path("/search")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public SearchResult find(@FormParam("query") String query) throws Exception {
//    String[] strings = {"a", "b"};
    query=query.toLowerCase();
    System.out.println("query is "+query);

    SearchResult r=searchEngine.doSearch(query.split(" "));

    List<ScoredStatus> result=r.getResults();
    result=result.subList(Math.max(0, result.size() - 200), result.size());
    r.setResults(result);

    return r;
  }
//
//    @Path("/config/{_configPara}")
//    @POST
//    @Produces("text/html")
//    public String config(@PathParam("_configPara") String configPara) {
//        try {
//            if (configPara.equals("genmodel")) {
//                OpenAPI.setFolderPath("../TweetSentiment/");
//                OpenAPI.generateModel("../TweetSentiment/TrainTweetData.txt", "./ModelRequested.dat");
//                return "<p>Model Generated.</p>\n";
//            } else {
//                return "<p>Request Argument " + configPara + " Invalid!</p>\n";
//            }
//        } catch (Exception e) {
//            throw new NotFoundException("message:" + e.getMessage());
//        }
//
//    }

}
