mvn exec:java -Dexec.mainClass="tweet_search.runner.StreamRunner"
