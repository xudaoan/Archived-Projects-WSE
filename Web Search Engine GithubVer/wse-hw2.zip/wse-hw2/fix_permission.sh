chgrp -R cs2580g11sp13 * 2>/dev/null
chmod -R 770 * 2>/dev/null
