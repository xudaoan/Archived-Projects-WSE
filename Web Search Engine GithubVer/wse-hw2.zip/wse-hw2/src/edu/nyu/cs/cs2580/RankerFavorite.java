package edu.nyu.cs.cs2580;

import edu.nyu.cs.cs2580.QueryHandler.CgiArguments;
import edu.nyu.cs.cs2580.SearchEngine.Options;

import java.util.*;

/**
 * @CS2580: Implement this class for HW2 based on a refactoring of your favorite
 * Ranker (except RankerPhrase) from HW1. The new Ranker should no longer rely
 * on the instructors' {@link IndexerFullScan}, instead it should use one of
 * your more efficient implementations.
 */
public class RankerFavorite extends Ranker {

  public RankerFavorite(Options options,
                        CgiArguments arguments, Indexer indexer) {
    super(options, arguments, indexer);
    System.out.println("Using Ranker: " + this.getClass().getSimpleName());
  }

  @Override
  public Vector<ScoredDocument> runQuery(Query query, int numResults) {
    try {
      Vector<ScoredDocument> retrieval_results = new Vector<ScoredDocument>();
      DocumentIndexed doc = (DocumentIndexed) _indexer.nextDoc(query, -1);

        while (doc != null) {
          Integer docId = doc.getDocId();
          double score = 0.0;
          //handle pure Phrase

          for (String queryWord : query.getTokens()) {
            //calculate word frequency in a document which is fqi,D/|D|, |D| is the number of words in document
            double queryWordCountInDocument = doc.getTermCount(queryWord);
            double totalWordCountInDocument = doc.getWordCount();
            double likeliHoodInDocument = queryWordCountInDocument / totalWordCountInDocument;
            //calculate word frequency in the collection which is Cqi/|C|

            double lambda = 0.2;
            double queryWordCountInCorpus = _indexer.corpusTermFrequency(queryWord);
            double totolWordCountInCorpus = _indexer.totalTermFrequency();
            double likeliHoodInCollection = ((double) queryWordCountInCorpus) / ((double) totolWordCountInCorpus);

            //System.out.println(queryWordCountInDocument +"|" +totalWordCountInDocument +"|" +queryWordCountInCorpus +"|" +totolWordCountInCorpus);
            score += Math.log((1 - lambda) * likeliHoodInDocument  + lambda * likeliHoodInCollection);
          }

          score = Math.pow(2, score);
          retrieval_results.add(new ScoredDocument(doc, score));
          doc = (DocumentIndexed) _indexer.nextDoc(query, docId);
        }
      Collections.sort(retrieval_results);
      Collections.reverse(retrieval_results);
      System.out.println("found " + retrieval_results.size() + " matching documents");

      if (numResults > retrieval_results.size())
        numResults = retrieval_results.size();
      return new Vector<ScoredDocument>(retrieval_results.subList(0, numResults));
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }
}
