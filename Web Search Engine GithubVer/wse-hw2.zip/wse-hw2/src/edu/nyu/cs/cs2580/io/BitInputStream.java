package edu.nyu.cs.cs2580.io;

import java.io.IOException;
import java.io.InputStream;

public class BitInputStream {

    private InputStream input;
    private int currentByte = 0;
    private int shift = 0;

    public BitInputStream(InputStream input) {
        this.input = input;
    }

    /**
     * 
     * @return return -1 if reaches the End of Stream, otherwise return next bit
     * @throws IOException
     */
    public int readBit() throws IOException {
        if (shift == 0) {
            currentByte = readByte();
            if (currentByte == -1) {
                return -1;
            }
            shift = 1 << 7;
        }

        int result = (currentByte & shift) == 0 ? 0 : 1;
        shift = (shift >>> 1);
        return result;
    }

    public int readByte() throws IOException {
        int result = input.read();
        shift = 7;
        return result;
    }

}
