package edu.nyu.cs.cs2580.index;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.io.IndexIO;

public class InvertIndexFromMulti implements InvertIndex {
    ArrayList<FileInputStream> inputIndexs;
    ArrayList<Map<String, Integer>> offsetss;
    Map<String, PostingList> cache;
    CodeType codeType;
    int size;

    public InvertIndexFromMulti(String indexPrefix, int fileCount, CodeType codeType)
            throws FileNotFoundException {
        this.inputIndexs = new ArrayList<FileInputStream>(fileCount);
        this.offsetss = new ArrayList<Map<String, Integer>>(fileCount);
        this.cache = new HashMap<String, PostingList>();
        this.codeType = codeType;
        for (int i = 1; i <= fileCount; i++) {
            String fileOffset = indexPrefix + "/offset.idx" + i;
            String fileIndex = indexPrefix + "/index.idx" + i;
            System.out.println("Load index from: " + fileOffset + "," + fileIndex);
            FileInputStream indexStream = new FileInputStream(fileIndex);
            FileInputStream offsetStream = new FileInputStream(fileOffset);
            Map<String, Integer> offsets = IndexIO.getTermOffsets(offsetStream);
            inputIndexs.add(indexStream);
            offsetss.add(offsets);
        }
    }

    @Override
    public PostingList get(String term) {
        if (this.cache.containsKey(term))
            return this.cache.get(term);
        try {
            PostingList result = new PostingList();
            int size = this.inputIndexs.size();
            for (int i = 0; i < size; i++) {
                Map<String, Integer> offsets = this.offsetss.get(i);
                FileInputStream input = this.inputIndexs.get(i);
                if (offsets.containsKey(term)) {
                    PostingList current = IndexIO.postingListReader(input, term, offsets, codeType);
                    List<DocPosting> list = current.getDocPostings();
                    int listSize = list.size();
                    for (int j = 0; j < listSize; j++)
                        result.addPosting(list.get(j));
                }
            }
            if (result.getDocPostings().size() == 0)
                return null;
            this.cache.put(term, result);
            if (cache.size() > 1000) {
                cache.clear();
            }
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean containsKey(String term) {
        for (Map<String, Integer> thisMap : this.offsetss) {
            if (thisMap.containsKey(term))
                return true;
        }
        return false;
    }
}
