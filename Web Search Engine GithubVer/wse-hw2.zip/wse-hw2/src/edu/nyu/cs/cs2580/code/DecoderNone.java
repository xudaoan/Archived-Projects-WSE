package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class DecoderNone implements Decoder{
    
    private Scanner scanner;
    
    public DecoderNone(InputStream input){
        scanner = new Scanner(input);        
    }

    @Override
    public int next() throws IOException {
        return scanner.nextInt();
    }

}
