package edu.nyu.cs.cs2580.index;

import edu.nyu.cs.cs2580.IndexerInvertedOccurrence;

import java.util.ArrayList;
import java.util.List;

public class DocPosting{
  @Override
  public String toString() {
    return "DocPosting{" +
            "docId=" + docId +
            ", occurrences=" + occurrences +

            '}';
  }

  Integer docId;
  List<Integer> occurrences=new ArrayList<Integer>();

  public DocPosting(int docId) {
    this.docId=docId;
  }

  public Integer getDocId() {
    return docId;
  }

  public void setDocId(Integer docId) {
    this.docId = docId;
  }

  public List<Integer> getOccurrences() {
    return occurrences;
  }
  public void addOccurrence(Integer pos){
    occurrences.add(pos);
  }
  public void setOccurrences(List<Integer> occurrences) {
    this.occurrences = occurrences;
  }
  private Integer cachedOccurIndex=0;
  public Integer numberOfOccurrence() {
    return occurrences.size();
  }

  //return the Occurence that is Greater than current pos, else return INFINITY
  public Integer afterOccurrence(Integer pos) {
    if(occurrences.isEmpty())
      return IndexerInvertedOccurrence.INFINITY;

    if (occurrences.get(occurrences.size()-1)<=pos)
      return IndexerInvertedOccurrence.INFINITY;

    if(occurrences.get(0)>pos)
    {cachedOccurIndex=0;
      return occurrences.get(0);
    }

    if(cachedOccurIndex>0&&occurrences.get(cachedOccurIndex-1)>pos)
      cachedOccurIndex=0;//start over, cache invalidate

    for(int i=cachedOccurIndex;i<occurrences.size();i++){
      if(occurrences.get(i)>pos){

        cachedOccurIndex=i;
        return occurrences.get(i);
      }
    }
    return IndexerInvertedOccurrence.INFINITY;
  }
}