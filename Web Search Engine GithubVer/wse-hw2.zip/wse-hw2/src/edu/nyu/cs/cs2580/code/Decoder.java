package edu.nyu.cs.cs2580.code;

import java.io.IOException;

public interface Decoder {

    public int next() throws IOException;
}
