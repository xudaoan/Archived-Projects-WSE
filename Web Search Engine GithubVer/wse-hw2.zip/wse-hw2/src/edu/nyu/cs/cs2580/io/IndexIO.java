package edu.nyu.cs.cs2580.io;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

import edu.nyu.cs.cs2580.code.*;
import edu.nyu.cs.cs2580.index.DocPosting;
import edu.nyu.cs.cs2580.index.PostingList;

public class IndexIO {

    /**
     * Create Decoder based on the input codeType
     * 
     * @param input
     *            The InputStream to be decoded
     * @param codeType
     *            Coding function chosen
     * @return
     */
    private static Decoder decoderSetter(InputStream input, CodeType codeType) {
        switch (codeType) {
        case ByteAligned:
            return new DecoderByteAligned(input);
        case ByteAlignedBuffered:
            return new DecoderByteAligned(input);
        case EliasDelta:
            return new DecoderEliasDelta(input);
        case EliasGamma:
            return new DecoderEliasDelta(input);
        case None:
            return new DecoderNone(input);
        }
        return null;
    }

    /**
     * Create Encoder based on the input codeType
     * 
     * @param input
     *            The OutputStream to be output To
     * @param codeType
     *            Coding function chosen
     * @return
     */
    private static Encoder encoderSetter(OutputStream output, CodeType codeType) {
        switch (codeType) {
        case ByteAligned:
            return new EncoderByteAligned(output);
        case ByteAlignedBuffered:
            return new EncoderByteAlignedBuffered(output);
        case EliasDelta:
            return new EncoderEliasDelta(output);
        case EliasGamma:
            return new EncoderEliasGamma(output);
        case None:
            return new EncoderNoneBuffered(output);
        }
        return null;
    }

    /**
     * Read the termOffset file and get the term-offset map
     * 
     * @param input
     * @return
     */
    public static Map<String, Integer> getTermOffsets(InputStream input) {
        Map<String, Integer> offsets = new HashMap<String, Integer>();
        Scanner scanner = new Scanner(input);

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] words = line.split("\\s+");
            offsets.put(words[0], Integer.parseInt(words[1]));
        }
        scanner.close();
        return offsets;
    }

    /**
     * Read the termOffset file and get the term-offset ArrayList
     * 
     * @param input
     * @return
     */
    private static ArrayList<TermOffsetPair> getTermOffsetsAsArray(InputStream input) {
        ArrayList<TermOffsetPair> offsets = new ArrayList<TermOffsetPair>();
        Scanner scanner = new Scanner(input);

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] words = line.split("\\s+");
            offsets.add(new TermOffsetPair(words[0], Integer.parseInt(words[1])));
        }
        scanner.close();
        return offsets;
    }

    /**
     * Read a document post from the decoder.
     * The decoder should have been set properly before the call.
     * 
     * @param decoder
     * @return
     * @throws IOException
     */
    private static DocPosting DocPostingReader(Decoder decoder) throws IOException {

        int docID = decoder.next();

        DocPosting posting = new DocPosting(docID);

        int occurrencesCount = decoder.next();
        for (int i = 0; i < occurrencesCount; i++) {
            posting.addOccurrence(decoder.next());
        }

        return posting;
    }

    /**
     * Read a posting list from a given decoder
     * 
     * @param decoder
     * @return
     * @throws IOException
     */
    private static PostingList postingListReader(Decoder decoder) throws IOException {
        PostingList postingList = new PostingList();
        int docCount = decoder.next();
        for (int i = 0; i < docCount; i++) {
            DocPosting posting = DocPostingReader(decoder);
            postingList.addPosting(posting);
        }
        return postingList;
    }

    /**
     * Read a posting list from a given file input stream and the strict offset
     * from the beginning of the file
     * 
     * @param input
     * @param offset
     * @return
     * @throws IOException
     */
    private static PostingList postingListReader(FileInputStream input, Integer offset,
            CodeType codeType) throws IOException {
        FileChannel channel = input.getChannel();
        channel.position(offset);

        Decoder decoder = decoderSetter(input, codeType);
        PostingList postingList;
        postingList = postingListReader(decoder);

        return postingList;
    }

    /**
     * Read a posting list from a given file input stream and the term
     * and the term-offset map
     * The method getTermOffsets should have been called before calling this.
     * 
     * @param input
     *            the index file InputStream
     * @param term
     *            the term
     * @param offsets
     *            The term-offset map
     * @return
     * @throws IOException
     */
    public static PostingList postingListReader(FileInputStream input, String term,
            Map<String, Integer> offsets, CodeType codType) throws IOException {
        if (offsets.containsKey(term))
            return postingListReader(input, offsets.get(term), codType);
        return null;
    }

    private static byte[] postingListByteArrayReader(FileInputStream input,
            ArrayList<TermOffsetPair> offsets, int termIndex) throws IOException {
        int startOffset = offsets.get(termIndex).offset;
        int readOffset;
        if (termIndex == offsets.size() - 1) {
            readOffset = input.available();
        } else {
            readOffset = offsets.get(termIndex + 1).offset - startOffset;
        }
        byte[] result = new byte[readOffset];
        input.read(result);
        return result;
    }

    /****************************************************************
     * **************************************************************
     * 
     * The Following is the Writers
     * 
     * **************************************************************
     * **************************************************************/

    /**
     * Write a document post using an encoder
     * 
     * @param posting
     * @param encoder
     * @throws IOException
     */
    private static void docPostingWriter(DocPosting posting, Encoder encoder) throws IOException {
        encoder.put(posting.getDocId());
        encoder.put(posting.getOccurrences().size());
        for (Integer occ : posting.getOccurrences()) {
            encoder.put(occ);
        }
    }

    /**
     * Write a postingList using an encoder
     * 
     * @param postingList
     * @param encoder
     * @throws IOException
     */
    private static void postingListWriter(PostingList postingList, Encoder encoder)
            throws IOException {
        List<DocPosting> postings = postingList.getPostings();
        int size = postings.size();
        encoder.put(size);
        for (int i = 0; i < size; i++) {
            docPostingWriter(postings.get(i), encoder);
        }
    }

    /**
     * Write a postingList using an FileOutputStream
     * 
     * @param postingList
     * @param output
     * @throws IOException
     */
    private static void postingListWriter(PostingList postingList, FileOutputStream output,
            CodeType codeType) throws IOException {
        Encoder encoder = encoderSetter(output, codeType);
        postingListWriter(postingList, encoder);
        encoder.flush();
    }

    /**
     * Write a line to the offset file
     * 
     * @param term
     * @param offset
     * @param offsetOutput
     * @throws IOException
     */
    private static void offsetWriter(String term, int offset, FileOutputStream offsetOutput)
            throws IOException {
        StringBuffer offsetLine = new StringBuffer();
        offsetLine.append(term);
        offsetLine.append(" ");
        offsetLine.append(offset);
        offsetLine.append("\n");
        byte[] byteArr = offsetLine.toString().getBytes();
        offsetOutput.write(byteArr);
    }

    /**
     * Write the indexes into file.
     * Do not assume write from the beginning of the file
     * Make sure the stream is at the correct position before use.
     * 
     * @param indexes
     *            the index storing the term - postinglist pair, should have
     *            been SORTED before this call
     * @param offsetOutput
     *            the FileStream that stores the offset of each term
     * @param indexOutput
     *            the FileStream that stores all the posting lists
     * @throws IOException
     */
    private static void indexWriter(ArrayList<TermPostingPair> indexes,
            FileOutputStream offsetOutput, FileOutputStream indexOutput, CodeType codeType)
            throws IOException {
        Integer currentOffset = (int) indexOutput.getChannel().position();
        int indexSize = indexes.size();
        for (int i = 0; i < indexSize; i++) {
            TermPostingPair term = indexes.get(i);
            offsetWriter(term.term, currentOffset, offsetOutput);
            postingListWriter(term.postingList, indexOutput, codeType);
            currentOffset = (int) indexOutput.getChannel().position();
        }
    }

    /**
     * Write the indexes into file.
     * Do not assume write from the beginning of the file
     * Make sure the stream is at the correct position before use.
     * 
     * @param indexes
     *            the index storing the term - postinglist pair
     * @param offsetOutput
     *            the FileStream that stores the offset of each term
     * @param indexOutput
     *            the FileStream that stores all the posting lists
     * @throws IOException
     */
    public static void indexWriter(Map<String, PostingList> indexes, FileOutputStream offsetOutput,
            FileOutputStream indexOuput, CodeType codeType) throws IOException {
        ArrayList<TermPostingPair> theList = new ArrayList<TermPostingPair>();
        theList.ensureCapacity(indexes.size());
        for (Map.Entry<String, PostingList> entry : indexes.entrySet()) {
            TermPostingPair tmp = new TermPostingPair(entry.getKey(), entry.getValue());
            theList.add(tmp);
        }
        Collections.sort(theList);
        indexWriter(theList, offsetOutput, indexOuput, codeType);
    }

    /****************************************************************
     **************************************************************** 
     * 
     * The Following is the Index Merge
     * 
     **************************************************************** 
     ****************************************************************/

    /**
     * Poll from the PriorityQueue, and put the next term into the queue
     * 
     * @param queue
     * @param inputIndexs
     * @param offsetss
     * @param codeType
     * @return
     * @throws IOException
     */
    private static TermPostinglistbytes priorityQueuePoll(
            PriorityQueue<TermPostinglistbytes> queue, ArrayList<FileInputStream> inputIndexs,
            ArrayList<ArrayList<TermOffsetPair>> offsetss, CodeType codeType) throws IOException {

        TermPostinglistbytes min = queue.poll();
        FileInputStream input = inputIndexs.get(min.fileIndex);
        ArrayList<TermOffsetPair> offsets = offsetss.get(min.fileIndex);
        int nextTermIndex = min.termIndex + 1;

        // There is no next term in that file
        if (nextTermIndex >= offsets.size()) {
            return min;
        }

        byte[] postingListAsByteArray = postingListByteArrayReader(input, offsets, nextTermIndex);
        TermPostinglistbytes tmp = new TermPostinglistbytes(offsets.get(nextTermIndex).term,
                postingListAsByteArray, min.fileIndex, nextTermIndex);

        queue.add(tmp);

        return min;
    }

    private static void Merge(ArrayList<FileInputStream> inputIndexs,
            ArrayList<ArrayList<TermOffsetPair>> offsetss, CodeType codeType,
            FileOutputStream offsetOutput, FileOutputStream indexOutput) throws IOException {

        int fileCount = inputIndexs.size();
        PriorityQueue<TermPostinglistbytes> queue = new PriorityQueue<TermPostinglistbytes>(
                fileCount);

        /*
         * Queue initialization.
         * Skip empty index files (offset files)
         */
        for (int i = 0; i < fileCount; i++) {

            ArrayList<TermOffsetPair> termOffsetList = offsetss.get(i);
            if (termOffsetList.isEmpty())
                continue;

            TermOffsetPair head = termOffsetList.get(0);
            byte[] postingListAsByteArray = postingListByteArrayReader(inputIndexs.get(i),
                    termOffsetList, 0);
            TermPostinglistbytes tmp = new TermPostinglistbytes(head.term, postingListAsByteArray,
                    i, 0);

            queue.add(tmp);

        }

        while (!queue.isEmpty()) {
            TermPostinglistbytes min = priorityQueuePoll(queue, inputIndexs, offsetss, codeType);
            if (!queue.isEmpty() && queue.peek().compareTo(min) == 0) {
                TreeMap<Integer, PostingList> postingListMap = new TreeMap<Integer, PostingList>();

                ByteArrayInputStream byteStream = new ByteArrayInputStream(min.input);
                Decoder decoder = decoderSetter(byteStream, codeType);
                PostingList thisPostingList = postingListReader(decoder);
                postingListMap.put(min.fileIndex, thisPostingList);

                while (queue.peek().compareTo(min) == 0) {
                    min = priorityQueuePoll(queue, inputIndexs, offsetss, codeType);
                    byteStream = new ByteArrayInputStream(min.input);
                    decoder = decoderSetter(byteStream, codeType);
                    thisPostingList = postingListReader(decoder);
                    postingListMap.put(min.fileIndex, thisPostingList);
                }

                PostingList postingList = new PostingList();

                for (Map.Entry<Integer, PostingList> entry : postingListMap.entrySet()) {
                    postingList.addAllPosting(entry.getValue());
                }

                int offset = (int) indexOutput.getChannel().position();
                String term = min.term;
                offsetWriter(term, offset, offsetOutput);
                postingListWriter(postingList, indexOutput, codeType);
                indexOutput.flush();

            } else {
                int offset = (int) indexOutput.getChannel().position();
                String term = min.term;
                offsetWriter(term, offset, offsetOutput);
                indexOutput.write(min.input);
                indexOutput.flush();
            }
        }

    }

    public static void Merge(String indexPrefix, int fileCount, CodeType codeType)
            throws IOException {
        ArrayList<FileInputStream> inputIndexs = new ArrayList<FileInputStream>(fileCount);
        ArrayList<ArrayList<TermOffsetPair>> offsetss = new ArrayList<ArrayList<TermOffsetPair>>(
                fileCount);
        for (int i = 1; i <= fileCount; i++) {
            String fileOffset = indexPrefix + "/offset.idx" + i;
            String fileIndex = indexPrefix + "/index.idx" + i;
            System.out.println("Load index from: " + fileOffset + "," + fileIndex);
            FileInputStream indexStream = new FileInputStream(fileIndex);
            FileInputStream offsetStream = new FileInputStream(fileOffset);
            inputIndexs.add(indexStream);
            offsetss.add(getTermOffsetsAsArray(offsetStream));
        }

        String outputFileOffset = indexPrefix + "/offset.idx";
        String outputFileIndex = indexPrefix + "/index.idx";
        FileOutputStream offsetOutput = new FileOutputStream(outputFileOffset);
        FileOutputStream indexOutput = new FileOutputStream(outputFileIndex);

        Merge(inputIndexs, offsetss, codeType, offsetOutput, indexOutput);
        offsetOutput.close();
        indexOutput.close();
    }

    /****************************************************************
     * **************************************************************
     * 
     * The Following is the Misc.
     * 
     * **************************************************************
     * **************************************************************/

    public static void writeFileNumber(String filename, int number) {
        try {
            FileOutputStream file = new FileOutputStream(filename);
            file.write(("" + number).getBytes());
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int readFileNumber(String filename) {
        try {
            FileInputStream file = new FileInputStream(filename);
            Scanner scanner = new Scanner(file);
            int it = scanner.nextInt();
            scanner.close();
            return it;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
