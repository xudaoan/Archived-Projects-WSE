package edu.nyu.cs.cs2580;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/11/13
 * Time: 2:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class HTMLPageParser {
  String content;
  Document document;
  String url;
  public HTMLPageParser(String content) {
    this.content = content;
  }

  /**
   * read HTML content directly from File
   * @param file
   */
  public HTMLPageParser(File file) throws IOException {
    document=Jsoup.parse(file, "UTF-8");
    url="http://en.wikipedia.org/wiki/"+file.getName();
//    System.out.println(document.body().text());

  }
  public String getRawBodyContent(){

    return document.body().text();
  }

  public List<String> getStemmedBodyWordsVector(){
    String rawBodyContent = getRawBodyContent();
    return getDowncaseWordsFromRawString(rawBodyContent);
  }

  public List<String> getStemmedTitleWordsVector(){
    String rawTitleContent = getRawTitleContent();
    return getDowncaseWordsFromRawString(rawTitleContent);
  }

  public List<String> getAllWords(){
    List<String> allWords=new ArrayList<String>();
    allWords.addAll(getStemmedTitleWordsVector());
    allWords.addAll(getStemmedBodyWordsVector());
    return allWords;
  }


  private List<String> getDowncaseWordsFromRawString(String rawBodyContent) {
    rawBodyContent.replaceAll("[\"\']"," ");
    Scanner s=new Scanner(rawBodyContent).useDelimiter("[^A-Za-z]");
    List<String> words=new ArrayList<String>();
    while(s.hasNext()){
      String word = s.next();
      word=WordStemmer.stem(word.toLowerCase());
      if (word.isEmpty())
        continue;
      words.add(word);
    }
    return words;
  }

  public String getRawTitleContent() {
    return document.title();
  }

  public String getURL() {
    return url;
  }
}
