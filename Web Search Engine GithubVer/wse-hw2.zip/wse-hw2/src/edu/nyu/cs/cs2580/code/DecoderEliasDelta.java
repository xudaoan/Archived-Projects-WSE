package edu.nyu.cs.cs2580.code;

import edu.nyu.cs.cs2580.io.BitInputStream;

import java.io.IOException;
import java.io.InputStream;

public class DecoderEliasDelta implements Decoder {
    private BitInputStream input;

    public DecoderEliasDelta(InputStream input) {
        this.input = new BitInputStream(input);
    }

    public int next() throws IOException {
        int nextBit = input.readBit();
        if (nextBit == -1)
            return -1;

        if (nextBit == 0)
            return 1;

        int dd = 0;
        while (nextBit == 1) {
            dd++;
            nextBit = input.readBit();
        }

        if (nextBit == -1)
            return -1;

        int dr = 0;
        int d = 1;
        for (int i = 0; i < dd; i++) {
            dr = (dr << 1) + input.readBit();
            d = d << 1;
        }
        d = d - 1 + dr;

        int result = 1;
        int r = 0;
        for (int i = 0; i < d; i++) {
            r = (r << 1) + input.readBit();
            result = result << 1;
        }
        result = result + r;
        return result;
    }

}
