package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.OutputStream;


public class EncoderByteAligned implements Encoder {

    private OutputStream output;

    public EncoderByteAligned(OutputStream output) {
        this.output = output;
    }
    
    @Override
    public void put(int value) throws IOException {
        if(value < 0)
            throw new RuntimeException("The value to be encoded by ByteAligned not positive");
        
        if(value == 0){
            output.write(0x80);
            return;
        }
        
        byte[] byteArr = new byte[5];
        int count = 0;
        while(value > 0){
            byteArr[count] = (byte)(value & 0x7f);
            count++;
            value = value >>> 7;
        }
        count --;
        byteArr[0] = (byte) (byteArr[0] | 0x80);
        while(count >= 0){
            output.write(byteArr[count]);
            count --;
        }
    }

    @Override
    public void closeStream() throws IOException {
        output.close();
    }

    @Override
    public void flush() {
        
    }
}
