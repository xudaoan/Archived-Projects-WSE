package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.OutputStream;

public interface Encoder {
    public void put(int value) throws IOException;

    public void closeStream() throws IOException;

    public void flush() throws IOException;
}
