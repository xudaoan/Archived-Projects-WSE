package edu.nyu.cs.cs2580.io;

/**
 * Storing the term in String <br>
 * the posting list of the term in byte array <br>
 * and which index file the posting list is get. <br>
 * 
 * @author Daoan XU
 * 
 */
public class TermPostinglistbytes implements Comparable<TermPostinglistbytes> {

    String term;
    byte[] input;
    int fileIndex;
    int termIndex;

    /**
     * 
     * @param term
     *            the term
     * @param input
     *            the posting list of the term in byte array
     * @param fileIndex
     *            from which index file is the posting list is
     *            got
     */
    public TermPostinglistbytes(String term, byte[] input, int fileIndex, int termIndex) {
        this.term = term;
        this.input = input;
        this.fileIndex = fileIndex;
        this.termIndex = termIndex;
    }

    @Override
    public int compareTo(TermPostinglistbytes o) {
        return this.term.compareTo(o.term);
    }

}
