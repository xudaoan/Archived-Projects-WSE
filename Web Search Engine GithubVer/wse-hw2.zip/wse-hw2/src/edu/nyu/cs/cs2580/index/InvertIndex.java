package edu.nyu.cs.cs2580.index;

public interface InvertIndex {
    
    public PostingList get(String term);
    
    public boolean containsKey(String term);
}