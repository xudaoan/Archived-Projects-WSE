package edu.nyu.cs.cs2580;

import edu.nyu.cs.cs2580.SearchEngine.Options;
import edu.nyu.cs.cs2580.io.DocumentInfoDAO;

import java.io.*;
import java.util.*;

public class IndexerInvertedDoconly extends Indexer implements Serializable {
  private static final long serialVersionUID = 1077123905740085030L;
  public static final int INFINITY = Integer.MAX_VALUE;
  public static final String FS = "|";

  private Map<String,List<Integer>> invertDoconlyIndex=new HashMap<String, List<Integer>>();

  // Stores all Document in memory.
  private Vector<Document> _documents = new Vector<Document>();

  public IndexerInvertedDoconly(Options options) {
    super(options);
    System.out.println("Using Indexer: " + this.getClass().getSimpleName());
  }

  @Override
  public void constructIndex() throws IOException {
    String corpusPrefix = _options._corpusPrefix;

    System.out.println("corpusPrefix is" + corpusPrefix);
    System.out.println("Indexing documents ...");

    String docInfoFile= _options._indexPrefix+"/docinfo.idx"; // for storing title, url
    DocumentInfoDAO documentInfoDAO=new DocumentInfoDAO(docInfoFile);

    File corpusDir = new File(corpusPrefix);
    int maxCount = 100;
    int count = maxCount;
    int ccount = 0;
    for (File corpusFile : corpusDir.listFiles()) {
      processDocument(corpusFile,documentInfoDAO);
      count--;
      ccount++;
      if(count == 0){
    	  System.out.println(ccount + " Documents have been processed");
    	  count = maxCount; 
      }

    }
    documentInfoDAO.close();

    persistIndex();
  }

  private void persistIndex() throws IOException {
    System.out.println(
            "Indexed " + Integer.toString(_numDocs) + " docs with " +
                    Long.toString(_totalTermFrequency) + " terms.");

    String indexFile = _options._indexPrefix + "/corpus.idx";


    System.out.println("Store index to: " + indexFile);

    PrintWriter docInfoWriter=new PrintWriter(new BufferedWriter(new FileWriter(indexFile,false)));
    for(String term:invertDoconlyIndex.keySet()){
    docInfoWriter.println(term+FS+invertDoconlyIndex.get(term).toString());
    }
    docInfoWriter.flush();
    docInfoWriter.close();
  }


  protected List<Integer>getPostingList(String term){
    return invertDoconlyIndex.get(term);
  }

  @Override
  public void loadIndex() throws IOException, ClassNotFoundException {
    String indexFile = _options._indexPrefix + "/corpus.idx";
    String docInfoFile= _options._indexPrefix+"/docinfo.idx";
    System.out.println("Load index from: " + indexFile);

    DocumentInfoDAO documentInfoDAO=new DocumentInfoDAO(docInfoFile);
    _documents=documentInfoDAO.readAllDocuments();
    for(Document doc:_documents){
      _totalTermFrequency+=doc.getWordCount();
    }
    _numDocs=_documents.size();
    BufferedReader indexReader=new BufferedReader(new FileReader(indexFile));
    String line;
    while((line=indexReader.readLine())!=null){

      if (line.equals(""))
        continue;
      String[] fields=line.split("\\"+FS);
      String term = fields[0];
      List<Integer> postingList=new ArrayList<Integer>();
      for(String i:fields[1].split("[\\[\\],]")){
          if (i.equals(""))
            continue;
         postingList.add(Integer.valueOf(i.trim()));
      }
      invertDoconlyIndex.put(term, postingList);
    }

    System.out.println(Integer.toString(_numDocs) + " documents loaded " +
            "with " + Long.toString(_totalTermFrequency) + " terms!");
  }

  @Override
  public Document getDoc(int docid) {
    return _documents.get(docid);
  }

  public void processDocument(File file, DocumentInfoDAO docInfoWriter) {
    //parse HTML
    HTMLPageParser parser;
    try {
      parser = new HTMLPageParser(file);


      if(parser.getRawTitleContent().equals("")){
        //System.out.println("Empty title, skipping "+file.getAbsolutePath());
        return;
      }
      List<String> titleWords = parser.getStemmedTitleWordsVector();
      List<String> bodyWords = parser.getStemmedBodyWordsVector();



      Document doc = new Document(_documents.size());
      String url = parser.getURL();

      doc.setTitle(parser.getRawTitleContent());
      doc.setUrl(url);


      _documents.add(doc);
      int docId=_documents.size()-1;
      ++_numDocs;

      Set<String> uniqueTerms = new HashSet<String>();
      uniqueTerms.addAll(titleWords);
      uniqueTerms.addAll(bodyWords);

      List<String> allWords=new ArrayList<String>();
      allWords.addAll(titleWords);
      allWords.addAll(bodyWords);
      _totalTermFrequency+=allWords.size();

      docInfoWriter.writeDocInfo(docId,parser.getRawTitleContent(),url,allWords);

      //append document to correspoding posting lists
      addToInvertIndex(uniqueTerms, docId);
    } catch (IOException e) {
      System.err.println("Can not parse file!!! " + file.getAbsolutePath());
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
  }


  //append to posting list accordinly
  private void addToInvertIndex(Set<String> uniqueWords, Integer docId) {
    for(String word:uniqueWords){
       addDocToPostingList(word,docId);
    }
  }

  //simplest one, only add docId to index
  private void addDocToPostingList(String term, Integer docId){
    if (!invertDoconlyIndex.containsKey(term))
      invertDoconlyIndex.put(term,new ArrayList<Integer>());
    List<Integer> postingList=invertDoconlyIndex.get(term);
    postingList.add(docId);
  }


  /**
   * In HW2, you should be using {@link DocumentIndexed}
   */
  @Override
  public Document nextDoc(Query query, int docid) {
    Vector<String> tokens=query.getTokens();
    boolean haveSameDocID=true;
    Integer previous=null;
    Integer maxDocID=-1;
    for(String token:tokens){
      Integer nextCandidate = next(token, docid);
      if (nextCandidate.equals(INFINITY))
        return null;
      if(previous!=null && !previous.equals(nextCandidate))
        haveSameDocID=false;

      if (nextCandidate>maxDocID)
        maxDocID=nextCandidate;

      previous=nextCandidate;
    }

    if(haveSameDocID && maxDocID.equals(INFINITY))
      return null;

    if(haveSameDocID){
      DocumentIndexed result= new DocumentIndexed(getDoc(maxDocID));
      for(String token:query.getTokens()){
        result.setTermCount(token,1);
      }
      return result;
    }

    return nextDoc(query, maxDocID - 1);

  }

  private HashMap<String,Integer> cachedIndex=new HashMap<String, Integer>();
  private Integer getCachedIndex(String term){
         if (!cachedIndex.containsKey(term)){
           cachedIndex.put(term,0);
         }
    return cachedIndex.get(term);
  }

  private void setCachedIndex(String term, Integer index){
    cachedIndex.put(term,index);
  }

  private Integer next(String term, int currentDocId) {
    List<Integer> postingList=invertDoconlyIndex.get(term);
    if (postingList==null)
      return INFINITY;
    int ct=getCachedIndex(term);


    if(postingList.get(postingList.size()-1)<=currentDocId)
      return INFINITY;

    if(postingList.get(0)>currentDocId)
    { setCachedIndex(term,0);
      return postingList.get(0);
    }

    if(ct>0 && postingList.get(ct-1)>currentDocId){
      ct=0;
    }

    while(postingList.get(ct)<=currentDocId){
      ct++;
    }
    setCachedIndex(term,ct);
    return postingList.get(ct);

  }

  /**
   * number of documents containing the term
   */
  @Override
  public int corpusDocFrequencyByTerm(String term) {
    if (!invertDoconlyIndex.containsKey(term))
      return 0;
    return invertDoconlyIndex.get(term).size();
  }

  @Override
  public int corpusTermFrequency(String term) {
    return invertDoconlyIndex.containsKey(term)? invertDoconlyIndex.get(term).size():0;
  }

  /**
   * documentTermFrequency is efficiently computed in the DocumentIndexed.getTermCount method
   *
   */
  @Deprecated
  public int documentTermFrequency(String term, String url) {
    SearchEngine.Check(false, "Not implemented!");
    return 0;
  }
}
