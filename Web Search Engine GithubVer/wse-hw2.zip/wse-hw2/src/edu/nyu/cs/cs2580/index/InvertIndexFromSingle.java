package edu.nyu.cs.cs2580.index;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.io.IndexIO;

public class InvertIndexFromSingle implements InvertIndex {
    FileInputStream inputIndex;
    Map<String, Integer> offsets;
    Map<String, PostingList> cache;
    CodeType codeType;

    public InvertIndexFromSingle(String indexPrefix, CodeType codeType)
            throws FileNotFoundException {
        this.cache = new HashMap<String, PostingList>();
        this.codeType = codeType;
        String fileOffset = indexPrefix + "/offset.idx";
        String fileIndex = indexPrefix + "/index.idx";
        System.out.println("Load index from: " + fileOffset + "," + fileIndex);
        inputIndex = new FileInputStream(fileIndex);
        FileInputStream offsetStream = new FileInputStream(fileOffset);
        offsets = IndexIO.getTermOffsets(offsetStream);
    }

    @Override
    public PostingList get(String term) {
        if (this.cache.containsKey(term))
            return this.cache.get(term);

        PostingList result = null;
        if (offsets.containsKey(term)) {
            try {
                result = IndexIO.postingListReader(this.inputIndex, term, offsets, codeType);
                cache.put(term, result);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    @Override
    public boolean containsKey(String term) {
        return this.offsets.containsKey(term);
    }
}
