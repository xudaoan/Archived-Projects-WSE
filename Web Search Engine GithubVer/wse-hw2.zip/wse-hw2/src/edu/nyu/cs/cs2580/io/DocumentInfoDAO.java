package edu.nyu.cs.cs2580.io;

import edu.nyu.cs.cs2580.Document;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/12/13
 * Time: 4:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentInfoDAO {
  public static final String FS = "|";
  private  PrintWriter docInfoWriter=null;

  private PrintWriter getWriter() throws IOException {
    if (docInfoWriter==null)
      docInfoWriter = new PrintWriter(new BufferedWriter(new FileWriter(filePath,false)));
  return docInfoWriter;
  }

  public DocumentInfoDAO(String filePath) throws IOException {
    this.filePath = filePath;
  }

  String filePath;

  public void writeDocInfo(Integer docId, String title, String url, List<String> allWords) throws IOException {
    HashMap<String,Integer> wordCounter=new HashMap<String, Integer>();
    double wordCount=allWords.size();
    getWriter().println(docId + FS + title + FS + url+FS+wordCount);
    getWriter().flush();
  };
  public void close() throws IOException {
        getWriter().close();
  }

  public Vector<Document> readAllDocuments() throws IOException {
    Vector<Document> result = new Vector<Document>();
    BufferedReader documentInfoReader=new BufferedReader(new FileReader(filePath));
    String line=null;
    while((line=documentInfoReader.readLine())!=null){

      if (line.equals(""))
        continue;
      String[] fields=line.split("\\"+FS);
      //System.out.println(line);
      Document doc=new Document(Integer.valueOf(fields[0]));
      doc.setTitle(fields[1]);
      doc.setUrl(fields[2]);
      doc.setWordCount(Double.valueOf(fields[3]));
      result.add(doc);
    }
    documentInfoReader.close();
    return result;

  }
}
