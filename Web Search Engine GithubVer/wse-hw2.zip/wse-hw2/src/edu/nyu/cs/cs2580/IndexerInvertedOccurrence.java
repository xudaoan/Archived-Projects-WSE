package edu.nyu.cs.cs2580;

import edu.nyu.cs.cs2580.SearchEngine.Options;
import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.index.DocPosting;
import edu.nyu.cs.cs2580.index.InvertIndex;
import edu.nyu.cs.cs2580.index.InvertIndexFromMulti;
import edu.nyu.cs.cs2580.index.InvertIndexFromSingle;
import edu.nyu.cs.cs2580.index.PostingList;
import edu.nyu.cs.cs2580.io.DocumentInfoDAO;
import edu.nyu.cs.cs2580.io.IndexIO;

import java.io.*;
import java.util.*;


public class IndexerInvertedOccurrence extends Indexer {
  public static final int INFINITY = Integer.MAX_VALUE;
  // Maps each term to their integer representation
//  private Map<String, Integer> _dictionary = new HashMap<String, Integer>();
  // All unique terms appeared in corpus. Offsets are integer representations.
//  private Vector<String> _terms = new Vector<String>();
  // Term frequency, key is the integer representation of the term and value is
  // the number of times the term appears in the corpus.
  InvertIndex invertOccurenceIndex;
  HashMap<String, PostingList> invertOccurenceIndexForWrite = new HashMap<String, PostingList>();

  int cMax = 1000;

  // Stores all Document in memory.
  private Vector<Document> _documents = new Vector<Document>();
  protected CodeType codeType;

  public IndexerInvertedOccurrence(Options options) {
    super(options);
    this.supportPhrase = true;
    System.out.println("Using Indexer: " + this.getClass().getSimpleName());
    codeType = CodeType.None;
  }

  @Override
  public void constructIndex() throws IOException {
    String corpusPrefix = _options._corpusPrefix;

    System.out.println("corpusPrefix is" + corpusPrefix);
    System.out.println("Indexing documents ...");

    String docInfoFile = _options._indexPrefix + "/docinfo.idx"; // for storing title, url
    DocumentInfoDAO documentInfoDAO = new DocumentInfoDAO(docInfoFile);

    File corpusDir = new File(corpusPrefix);
    int count = cMax;
    int round = 1;
    for (File corpusFile : corpusDir.listFiles()) {

        //System.out.println("Constructing index from: " + corpusFile.getAbsolutePath());

        processDocument(corpusFile, documentInfoDAO);
        count--;
        if (count == 0) {
            persistIndex(round);
            this.invertOccurenceIndexForWrite.clear();
            count = cMax;
            round++;
            System.out.println("Indexing more documents ...");
        }

    }
    persistIndex(round);
    documentInfoDAO.close();

    IndexIO.writeFileNumber(_options._indexPrefix + "/FileCount", round);
    System.out.println("Mearging");
    IndexIO.Merge(_options._indexPrefix, round, codeType);
  }



  private void persistIndex(int round) throws IOException {
      System.out.println("Indexed " + Integer.toString(_numDocs) + " docs with "
              + Long.toString(_totalTermFrequency) + " terms.");

      String indexFile = _options._indexPrefix + "/index.idx" + round;
      String offsetFile = _options._indexPrefix + "/offset.idx" + round;

      FileOutputStream offsetOutput = new FileOutputStream(offsetFile);
      FileOutputStream indexOuput = new FileOutputStream(indexFile);

      System.out.println("Store index to: " + indexFile + " and: " + offsetFile);
      IndexIO.indexWriter(this.invertOccurenceIndexForWrite, offsetOutput, indexOuput, codeType);
      offsetOutput.close();
      indexOuput.close();
      System.out.println("File Ready for Use");
  }


  @Override
  public void loadIndex() throws IOException, ClassNotFoundException {

    String docInfoFile = _options._indexPrefix + "/docinfo.idx";


    //load Documents
    DocumentInfoDAO documentInfoDAO = new DocumentInfoDAO(docInfoFile);
    _documents = documentInfoDAO.readAllDocuments();
    for (Document doc : _documents) {
      _totalTermFrequency += doc.getWordCount();
    }
    _numDocs = _documents.size();

    //load Index
    
    //int fileCount = IndexIO.readFileNumber(_options._indexPrefix + "/FileCount");
    this.invertOccurenceIndex = new InvertIndexFromSingle(_options._indexPrefix, codeType);

    System.out.println(Integer.toString(_numDocs) + " documents loaded " + "with "
            + Long.toString(_totalTermFrequency) + " terms!");
  }

  @Override
  public Document getDoc(int docid) {
    return _documents.get(docid);
  }

  public void processDocument(File file, DocumentInfoDAO docInfoWriter) {
      // parse HTML
      HTMLPageParser parser;
      try {
          parser = new HTMLPageParser(file);
          if (parser.getRawTitleContent().equals("")) {
              //System.out.println("Empty title, skipping " + file.getAbsolutePath());
              return;
          }
          List<String> titleWords = parser.getStemmedTitleWordsVector();
          List<String> bodyWords = parser.getStemmedBodyWordsVector();

          Document doc = new Document(_documents.size());
          String url = parser.getURL();

          doc.setTitle(parser.getRawTitleContent());
          doc.setUrl(url);

          _documents.add(doc);
          int docId = _documents.size() - 1;
          ++_numDocs;

          List<String> allWords = new ArrayList<String>();
          allWords.addAll(titleWords);
          allWords.addAll(bodyWords);
          _totalTermFrequency += allWords.size();

          docInfoWriter.writeDocInfo(docId, parser.getRawTitleContent(), url, allWords);

          // append document to correspoding posting lists
          addToInvertIndexForDocument(allWords, docId);
      } catch (IOException e) {
          System.err.println("Can not parse file!!! " + file.getAbsolutePath());
          e.printStackTrace(); // To change body of catch statement use File |
                               // Settings | File Templates.
      }
  }

  //append to posting list accordinly
  private void addToInvertIndexForDocument(List<String> allWords, Integer docId) {
      for (int i = 0; i < allWords.size(); i++) {
          String term = allWords.get(i);
          // addDocToPostingList(word,docId);
          if (!invertOccurenceIndexForWrite.containsKey(term))
              invertOccurenceIndexForWrite.put(term, new PostingList());

          PostingList postingList = invertOccurenceIndexForWrite.get(term);

          if (!postingList.hasPostingForDoc(docId))
              postingList.addPosting(new DocPosting(docId));

          postingList.getPostingByDocId(docId).addOccurrence(i);
      }
  }


  /**
   * In HW2, you should be using {@link DocumentIndexed}
   */
  @Override
  public Document nextDoc(Query query, int docid) {
    
    Integer nexID = nextDocId(query, docid);
    if (nexID.equals(INFINITY))
      return null;

    if (query.isPhraseQuery()) {//filter out docs that has the phrase
        while (!nexID.equals(INFINITY)) {//as long as there is a doc contains all words
          DocumentIndexed candidateDoc=new DocumentIndexed(getDoc(nexID));
          boolean containAllPhrases=true;
          for(List<String> phrase:query.phrases){  //check query
            int phraseCount=0;
            Integer pos=nextPhrase(phrase,nexID,-1);
             while(!pos.equals(INFINITY)){
               phraseCount++;
               pos=nextPhrase(phrase,nexID,pos);
             }
            if (phraseCount>0)
              candidateDoc.setTermCount(phrase.toString(),phraseCount);
            if (phraseCount==0){
              containAllPhrases=false;
              break;
            }
          }
          for (String term : query.getTokens()) {
            candidateDoc.setTermCount(term, invertOccurenceIndex.get(term).getPostingByDocId(nexID).numberOfOccurrence());//number of time a word occurs
          }

          if (containAllPhrases){
            return candidateDoc;
            //oh yeah
          }else{
            //continue to next doc
            nexID = nextDocId(query, nexID);
          }
        }
        return null;//no phrase found
        //body=phrase
      } else {
        DocumentIndexed result = new DocumentIndexed(getDoc(nexID));
        for (String term : query.getTokens()) {
          result.setTermCount(term, invertOccurenceIndex.get(term).getPostingByDocId(nexID).numberOfOccurrence());//number of time a word occurs
        }
        return result;
        //each word-> index.get(word).get(docid).size() can append vector
      }
  }

  public Integer nextDocId(Query query, int docid) {
    Vector<String> tokens = query.getTokens();
    boolean haveSameDocID = true;
    Integer previous = null;
    Integer maxDocID = -1;
    if (tokens.size() == 0)
      throw new RuntimeException("query contains no words, maybe not processed");
    for (String token : tokens) {
      Integer nextCandidate = next(token, docid);
      if (nextCandidate.equals(INFINITY))
        return INFINITY;
      if (previous != null && !previous.equals(nextCandidate))
        haveSameDocID = false;

      if (nextCandidate > maxDocID)
        maxDocID = nextCandidate;

      previous = nextCandidate;
    }

    if (haveSameDocID && maxDocID.equals(INFINITY))
      return INFINITY;

    if (haveSameDocID)
      return maxDocID;

    return nextDocId(query, maxDocID - 1);

  }

  private Integer next(String term, int currentDocId) {
    PostingList postingList = invertOccurenceIndex.get(term);
    if (postingList == null)
      return INFINITY;

    return postingList.greaterDocID(currentDocId);
  }

  private Integer next_pos(String term, Integer docid, Integer pos) {
    if (!invertOccurenceIndex.containsKey(term))
      return INFINITY;
    if (!invertOccurenceIndex.get(term).hasPostingForDoc(docid))
      return INFINITY;


    return invertOccurenceIndex.get(term).getPostingByDocId(docid).afterOccurrence(pos);
  }

  public Integer nextPhrase(List<String> phrase, Integer docId, Integer pos) {
   // Integer docidVerify = nextDocId(query, docId - 1);
//    if (!docidVerify.equals(docId))
//      return INFINITY;

    Vector<String> tokens = new Vector<String>(phrase);
    Integer firstPos = pos;
    Integer previousPos = pos;
    for (int i = 0; i < tokens.size(); i++) {


      String term = tokens.get(i);
      Integer nextPos = next_pos(term, docId, previousPos);

      if (i == 0) {
        firstPos = nextPos;//the pos of a phrase is the pos of the first word of the phrase
        if (firstPos.equals(INFINITY))
          return INFINITY;
      }

      if (i >= 1 && nextPos - previousPos != 1) {
        return nextPhrase(phrase, docId, firstPos);//not consecutive
      }

      if (nextPos.equals(INFINITY))
        return INFINITY;//any term pos is infinity then return infinity

      previousPos = nextPos;
    }

    return firstPos;
  }

  /**
   * number of documents containing the term
   *
   */
  @Override
  public int corpusDocFrequencyByTerm(String term) {
    if (!invertOccurenceIndex.containsKey(term))
      return 0;
    return invertOccurenceIndex.get(term).getPostings().size();
  }

  @Override
  public int corpusTermFrequency(String term) {
    if (!invertOccurenceIndex.containsKey(term))
      return 0;

    int freq = 0;
    for (DocPosting posting : invertOccurenceIndex.get(term).getPostings()) {
      freq += posting.numberOfOccurrence();
    }
    return freq;
  }

  /**
   * documentTermFrequency is efficiently computed in the DocumentIndexed.getTermCount method
   *
   */
  @Deprecated
  public int documentTermFrequency(String term, String url) {
    SearchEngine.Check(false, "Not implemented!");
    return 0;
  }

}
