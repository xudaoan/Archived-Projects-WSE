package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.OutputStream;


public class EncoderByteAlignedBuffered implements Encoder {

    private OutputStream output;
    private byte[] buffer;
    private int bufferSize;
    private final int maxSize = 100000;

    public EncoderByteAlignedBuffered(OutputStream output) {
        this.output = output;
        this.buffer = new byte[maxSize];
        this.bufferSize = 0;
    }
    
    private void write(byte b) throws IOException{
        this.buffer[bufferSize] = b;
        bufferSize++;
        if(this.bufferSize == maxSize){
            output.write(this.buffer);
            bufferSize = 0;
        }
    }    
    
    @Override
    public void put(int value) throws IOException {
        if(value < 0)
            throw new RuntimeException("The value to be encoded by ByteAligned not positive");
        
        if(value == 0){
            write((byte)0x80);
            return;
        }
        
        byte[] byteArr = new byte[5];
        int count = 0;
        while(value > 0){
            byteArr[count] = (byte)(value & 0x7f);
            count++;
            value = value >>> 7;
        }
        count --;
        byteArr[0] = (byte) (byteArr[0] | 0x80);
        while(count >= 0){
            write(byteArr[count]);
            count --;
        }
    }

    @Override
    public void closeStream() throws IOException {
        this.flush();
        output.close();
    }

    @Override
    public void flush() throws IOException {
        byte[] byteArr = new byte[this.bufferSize];
        for(int i =0;i<this.bufferSize;i++){
            byteArr[i] = this.buffer[i];
        }
        output.write(byteArr);      
        output.flush();        
    }
}
