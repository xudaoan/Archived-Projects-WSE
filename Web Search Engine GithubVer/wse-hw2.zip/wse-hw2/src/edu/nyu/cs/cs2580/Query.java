package edu.nyu.cs.cs2580;

import java.util.*;

/**
 * Representation of a user query.
 * 
 * In HW1: instructors provide this simple implementation.
 * 
 * In HW2: students must implement {@link QueryPhrase} to handle phrases.
 * 
 * @author congyu
 * @auhtor fdiaz
 */
public class Query {
  public String _query = null;
  public Vector<String> _tokens = new Vector<String>();
  public Vector<List<String>> phrases=new Vector<List<String>>();
  public Vector<String> getTokens() {
    return _tokens;
  }

  public Query(String query) {
    _query = query;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    Query query = (Query) o;

    if (_query != null ? !_query.equals(query._query) : query._query != null) return false;

    return true;
  }

  @Override
  public int hashCode() {
    return _query != null ? _query.hashCode() : 0;
  }

  public void processQuery() {
    if (_query == null) {
      return;
    }
    //
    String[] strs=_query.split("[\"]");
    for(int i=0;i<strs.length;i++){
      if (i%2==1){
        String phraseStr=strs[i];
        phrases.add(parsePhrase(phraseStr));
      }
    }
    String cleanQuery=_query.replaceAll("\""," ");
    Scanner s = new Scanner(cleanQuery);
    while (s.hasNext()) {
      _tokens.add(WordStemmer.stem(s.next()));
    }
    s.close();
  }

  //"new york" new "new york "
  private List<String> parsePhrase(String phraseStr) {
    List<String> phrase=new ArrayList<String>();

    for(String w:phraseStr.split(" ")){
      w=w.trim();
      w=WordStemmer.stem(w);
      if(!w.isEmpty())
        phrase.add(w);
    }
    return phrase;
  }

  public boolean isPhraseQuery() {
    return !phrases.isEmpty();
//    return _query.contains("\"");  //To change body of created methods use File | Settings | File Templates.
  }
}
