package edu.nyu.cs.cs2580;

import java.util.HashMap;


public class DocumentIndexed extends Document {
  private static final long serialVersionUID = 9184892508124423115L;
  private HashMap<String,Integer> termNumberMap=new HashMap<String, Integer>();
  public DocumentIndexed(Document d) {
    super(d.getDocId());
    this.setTitle(d.getTitle());
    this.setUrl(d.getUrl());
    this.setWordCount(d.getWordCount());
  }

  public void setTermCount(String term, Integer count){
    termNumberMap.put(term,count);
  }

  public Integer getTermCount(String term){
    if (!termNumberMap.containsKey(term))
      return 0;
    return termNumberMap.get(term);
  }
}
