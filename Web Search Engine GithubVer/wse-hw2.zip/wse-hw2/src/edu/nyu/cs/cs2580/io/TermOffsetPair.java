package edu.nyu.cs.cs2580.io;

public class TermOffsetPair {
    String term;
    int offset;
    public TermOffsetPair(String term, int offset) {
        this.term = term;
        this.offset = offset;
    }

}
