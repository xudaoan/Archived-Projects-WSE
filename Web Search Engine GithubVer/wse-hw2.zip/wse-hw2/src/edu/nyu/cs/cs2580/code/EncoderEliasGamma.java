package edu.nyu.cs.cs2580.code;

import edu.nyu.cs.cs2580.io.BitOutputStream;

import java.io.IOException;
import java.io.OutputStream;

public class EncoderEliasGamma implements Encoder{

    private BitOutputStream output;

    public EncoderEliasGamma(OutputStream output) {
        this.output = new BitOutputStream(output);
    }

    @Override
    public void put(int value) throws IOException {
        if (value < 1)
            throw new RuntimeException("The value to be encoded by EliasGamma not positive");

        if (value == 1) {
            output.writeBit(0);
            return;
        }

        int d = 1;
        while ((value >> d) > 1) {
            d++;
        }

        for (int i = 0; i < d; i++) {
            output.writeBit(1);
        }
        output.writeBit(0);
        for (int i = d - 1; i > -1; i--) {
            output.writeBit(value & (1 << i));
        }
    }

    @Override
    public void closeStream() throws IOException {
        output.close();
    }

    @Override
    public void flush() {
    }

}
