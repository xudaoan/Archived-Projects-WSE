package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.OutputStream;

public class EncoderNoneBuffered implements Encoder {
    
    private OutputStream output;
    private StringBuffer buffer;
    
    public EncoderNoneBuffered(OutputStream output){
        this.output = output;
        buffer = new StringBuffer();        
    }

    @Override
    public void put(int value) throws IOException {
        buffer.append(value);
        buffer.append(" ");
    }

    @Override
    public void closeStream() throws IOException {
        flush();
        output.close();
    }

    @Override
    public void flush() throws IOException {
        output.write(buffer.toString().getBytes());
        output.flush();
    }

}
