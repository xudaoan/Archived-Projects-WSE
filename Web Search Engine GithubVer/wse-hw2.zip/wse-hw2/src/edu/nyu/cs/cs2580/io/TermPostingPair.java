package edu.nyu.cs.cs2580.io;

import edu.nyu.cs.cs2580.index.PostingList;

public class TermPostingPair implements Comparable<TermPostingPair> {
    String term;
    PostingList postingList;

    TermPostingPair(String term, PostingList postingList) {
        this.term = term;
        this.postingList = postingList;
    }

    @Override
    public int compareTo(TermPostingPair o) {
        return term.compareTo(o.term);
    }
}
