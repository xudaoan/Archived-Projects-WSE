//package edu.nyu.cs.cs2580;
//
//import edu.nyu.cs.cs2580.SearchEngine.Options;
//import edu.nyu.cs.cs2580.index.*;
//import edu.nyu.cs.cs2580.io.DocumentInfoDAO;
//import edu.nyu.cs.cs2580.io.IndexIO;
//
//import java.io.*;
//import java.util.*;
//
//
//public class CopyOfIndexerInvertedCompressed extends Indexer {
//    private static final long serialVersionUID = 1077523905740085030L;
//    public static final int INFINITY = Integer.MAX_VALUE;
//    public static final String FS = "|";
//    // Maps each term to their integer representation
//    // private Map<String, Integer> _dictionary = new HashMap<String,
//    // Integer>();
//    // All unique terms appeared in corpus. Offsets are integer representations.
//    // private Vector<String> _terms = new Vector<String>();
//    // Term frequency, key is the integer representation of the term and value
//    // is
//    // the number of times the term appears in the corpus.
//    InvertIndex invertOccurenceIndex;
//    HashMap<String, PostingList> invertOccurenceIndexForWrite = new HashMap<String, PostingList>();
//
//    // Stores all Document in memory.
//    private Vector<Document> _documents = new Vector<Document>();
//
//    public CopyOfIndexerInvertedCompressed(Options options) {
//        super(options);
//        System.out.println("Using Indexer: " + this.getClass().getSimpleName());
//    }
//
//    @Override
//    public void constructIndex() throws IOException {
//        String corpusPrefix = _options._corpusPrefix;
//
//        System.out.println("corpusPrefix is" + corpusPrefix);
//        System.out.println("Indexing documents ...");
//
//        String docInfoFile = _options._indexPrefix + "/docinfo.idx"; // for
//                                                                     // storing
//                                                                     // title,
//                                                                     // url
//        DocumentInfoDAO documentInfoDAO = new DocumentInfoDAO(docInfoFile);
//
//        File corpusDir = new File(corpusPrefix);
//        int cMax = 1000;
//        int count = cMax;
//        int round = 1;
//        for (File corpusFile : corpusDir.listFiles()) {
//
//            //System.out.println("Constructing index from: " + corpusFile.getAbsolutePath());
//
//            processDocument(corpusFile, documentInfoDAO);
//            count--;
//            if (count == 0) {
//                persistIndex(round);
//                this.invertOccurenceIndexForWrite.clear();
//                count = cMax;
//                round++;
//            }
//
//        }
//        persistIndex(round);
//        documentInfoDAO.close();
//
//        IndexIO.writeFileNumber(_options._indexPrefix + "/FileCount", round);
//    }
//
//    private void persistIndex(int round) throws IOException {
//        System.out.println("Indexed " + Integer.toString(_numDocs) + " docs with "
//                + Long.toString(_totalTermFrequency) + " terms.");
//
//        String indexFile = _options._indexPrefix + "/index.idx" + round;
//        String offsetFile = _options._indexPrefix + "/offset.idx" + round;
//
//        FileOutputStream offsetOutput = new FileOutputStream(offsetFile);
//        FileOutputStream indexOuput = new FileOutputStream(indexFile);
//
//        System.out.println("Store index to: " + indexFile + " and: " + offsetFile);
//        IndexIO.indexWriter(this.invertOccurenceIndexForWrite, offsetOutput, indexOuput);
//    }
//
//    protected PostingList getPostingList(String term) {
//        return invertOccurenceIndex.get(term);
//    }
//
//    @Override
//    public void loadIndex() throws IOException, ClassNotFoundException {
//        String docInfoFile = _options._indexPrefix + "/docinfo.idx";
//
//        // load Documents
//        BufferedReader documentInfoReader = new BufferedReader(new FileReader(docInfoFile));
//        String line = null;
//        while ((line = documentInfoReader.readLine()) != null) {
//
//            if (line.equals(""))
//                continue;
//            String[] fields = line.split("\\" + FS);
//            //System.out.println(line);
//            Document doc = new Document(Integer.valueOf(fields[0]));
//            doc.setTitle(fields[1]);
//            doc.setUrl(fields[2]);
//            _documents.add(doc);
//        }
//        documentInfoReader.close();
//
//        // load Index
//        int fileCount = IndexIO.readFileNumber(_options._indexPrefix + "/FileCount");
//        this.invertOccurenceIndex = new InvertIndex(_options._indexPrefix, fileCount);
//
//        System.out.println(Integer.toString(_numDocs) + " documents loaded " + "with "
//                + Long.toString(_totalTermFrequency) + " terms!");
//    }
//
//    @Override
//    public Document getDoc(int docid) {
//        return _documents.get(docid);
//    }
//
//    public void processDocument(File file, DocumentInfoDAO docInfoWriter) {
//        // parse HTML
//        HTMLPageParser parser = null;
//        try {
//            parser = new HTMLPageParser(file);
//            if (parser.getRawTitleContent().equals("")) {
//                //System.out.println("Empty title, skipping " + file.getAbsolutePath());
//                return;
//            }
//            List<String> titleWords = parser.getStemmedTitleWordsVector();
//            List<String> bodyWords = parser.getStemmedBodyWordsVector();
//
//            Document doc = new Document(_documents.size());
//            String url = parser.getURL();
//
//            doc.setTitle(parser.getRawTitleContent());
//            doc.setUrl(url);
//
//            _documents.add(doc);
//            int docId = _documents.size() - 1;
//            ++_numDocs;
//
//            List<String> allWords = new ArrayList<String>();
//            allWords.addAll(titleWords);
//            allWords.addAll(bodyWords);
//            _totalTermFrequency += allWords.size();
//
//            docInfoWriter.writeDocInfo(docId, parser.getRawTitleContent(), url, allWords);
//
//            // append document to correspoding posting lists
//            addToInvertIndexForDocument(allWords, docId);
//        } catch (IOException e) {
//            System.err.println("Can not parse file!!! " + file.getAbsolutePath());
//            e.printStackTrace(); // To change body of catch statement use File |
//                                 // Settings | File Templates.
//        }
//    }
//
//    // append to posting list accordinly
//    private void addToInvertIndexForDocument(List<String> allWords, Integer docId) {
//        for (int i = 0; i < allWords.size(); i++) {
//            String term = allWords.get(i);
//            // addDocToPostingList(word,docId);
//            if (!invertOccurenceIndexForWrite.containsKey(term))
//                invertOccurenceIndexForWrite.put(term, new PostingList());
//
//            PostingList postingList = invertOccurenceIndexForWrite.get(term);
//
//            if (!postingList.hasPostingForDoc(docId))
//                postingList.addPosting(new DocPosting(docId));
//
//            postingList.getPostingByDocId(docId).addOccurrence(i);
//        }
//    }
//
//    /**
//     * In HW2, you should be using {@link DocumentIndexed}
//     * nextDoc for both conjunctive retrieval and phrase retrieval
//     */
//    @Override
//    public Document nextDoc(Query query, int docid) {
//        Integer nexID = nextDocId(query, docid);
//        if (nexID.equals(INFINITY))
//            return null;
//
//        if (query.isPhraseQuery()) {
//            Integer pos = nextPhrase(query, nexID, -1);
//            String term = query._query;// "aaaa"
//            Integer number = 0;
//            while (!pos.equals(INFINITY)) {
//                number++;
//                pos = nextPhrase(query, nexID, pos);
//            }
//            if (number.equals(0)) {
//                return null;
//            } else {
//                DocumentIndexed result = new DocumentIndexed(getDoc(nexID));
//                result.setTermCount(term, number);
//                return result;
//            }
//            // body=phrase
//        } else {
//            DocumentIndexed result = new DocumentIndexed(getDoc(nexID));
//            for (String term : query.getTokens()) {
//                result.setTermCount(term, invertOccurenceIndex.get(term).getPostingByDocId(nexID)
//                        .numberOfOccurrence());// number of time a word occurs
//            }
//            return result;
//            // each word-> index.get(word).get(docid).size() can append vector
//        }
//
//    }
//
//    public Integer nextDocId(Query query, int docid) {
//        Vector<String> tokens = query.getTokens();
//        List<Integer> nextDocs = new ArrayList<Integer>();
//        boolean haveSameDocID = true;
//        Integer previous = null;
//        Integer maxDocID = -1;
//        if (tokens.size() == 0)
//            throw new RuntimeException("query contains no words, maybe not processed");
//        for (String token : tokens) {
//            Integer nextCandidate = next(token, docid);
//            if (nextCandidate.equals(INFINITY))
//                return INFINITY;
//            nextDocs.add(nextCandidate);
//            if (previous != null && previous != nextCandidate)
//                haveSameDocID = false;
//
//            if (nextCandidate > maxDocID)
//                maxDocID = nextCandidate;
//
//            previous = nextCandidate;
//        }
//
//        if (haveSameDocID && maxDocID.equals(INFINITY))
//            return INFINITY;
//
//        if (haveSameDocID)
//            return maxDocID;
//
//        return nextDocId(query, maxDocID - 1);
//
//    }
//
//    private HashMap<String, Integer> cachedIndex = new HashMap<String, Integer>();
//
//    private Integer getCachedIndex(String term) {
//        if (!cachedIndex.containsKey(term)) {
//            cachedIndex.put(term, 0);
//        }
//        return cachedIndex.get(term);
//    }
//
//    private void setCachedIndex(String term, Integer index) {
//        cachedIndex.put(term, index);
//    }
//
//    private Integer next(String term, int currentDocId) {
//        PostingList postingList = invertOccurenceIndex.get(term);
//        if (postingList == null)
//            return INFINITY;
//
//        return postingList.greaterDocID(currentDocId);
//    }
//
//    private Integer next_pos(String term, Integer docid, Integer pos) {
//        if (!invertOccurenceIndex.containsKey(term))
//            return INFINITY;
//        if (!invertOccurenceIndex.get(term).hasPostingForDoc(docid))
//            return INFINITY;
//
//        return invertOccurenceIndex.get(term).getPostingByDocId(docid).afterOccurrence(pos);
//    }
//
//    public Integer nextPhrase(Query query, Integer docId, Integer pos) {
//        Integer docidVerify = nextDocId(query, docId - 1);
//        if (!docidVerify.equals(docId))
//            return INFINITY;
//
//        Vector<String> tokens = query.getTokens();
//        Integer firstPos = pos;
//        Integer maxPos = pos;
//        Integer previousPos = pos;
//        boolean isConsecutive = true;
//        for (int i = 0; i < tokens.size(); i++) {
//
//            String term = tokens.get(i);
//            Integer nextPos = next_pos(term, docId, previousPos);
//
//            if (i == 0) {
//                firstPos = nextPos;// the pos of a phrase is the pos of the
//                                   // first word of the phrase
//                if (firstPos.equals(INFINITY))
//                    return INFINITY;
//            }
//
//            if (i >= 1 && nextPos - previousPos != 1) {
//                return nextPhrase(query, docId, firstPos);// not consecutive
//            }
//
//            if (nextPos.equals(INFINITY))
//                return INFINITY;// any term pos is infinity then return infinity
//
//            previousPos = nextPos;
//        }
//
//        return firstPos;
//    }
//
//    /**
//     * number of documents containing the term
//     * 
//     * @param term
//     * @return
//     */
//    @Override
//    public int corpusDocFrequencyByTerm(String term) {
//        if (!invertOccurenceIndex.containsKey(term))
//            return 0;
//        return invertOccurenceIndex.get(term).getPostings().size();
//    }
//
//    @Override
//    public int corpusTermFrequency(String term) {
//        if (!invertOccurenceIndex.containsKey(term))
//            return 0;
//
//        int freq = 0;
//        for (DocPosting posting : invertOccurenceIndex.get(term).getPostings()) {
//            freq += posting.numberOfOccurrence();
//        }
//        return freq;
//    }
//
//    @Override
//    public int documentTermFrequency(String term, String url) {
//        SearchEngine.Check(false, "Not implemented!");
//        return 0;
//    }
//
//}
