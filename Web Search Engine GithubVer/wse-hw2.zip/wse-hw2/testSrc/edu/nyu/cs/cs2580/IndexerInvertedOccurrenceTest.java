package edu.nyu.cs.cs2580;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/12/13
 * Time: 11:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class IndexerInvertedOccurrenceTest {
  @Test
  public void testProcessDocument() throws Exception {
    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.constructIndex();

    i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.loadIndex();
//     i.processDocument(new File("data/wiki/Copyright"));
//     i.processDocument(new File("data/wiki/Web_browser"));


//    Assert.assertEquals(1, i.corpusDocFrequencyByTerm("copyright"));
//    Assert.assertEquals(1, i.corpusDocFrequencyByTerm("chrome"));
//    Assert.assertEquals(2,i.corpusDocFrequencyByTerm("and"));
    Assert.assertEquals(4,i.corpusTermFrequency(WordStemmer.stem("criminal")));
    Assert.assertEquals(3,i.corpusTermFrequency(WordStemmer.stem("google")));

    System.out.println(i.invertOccurenceIndex.get("chrome"));
    System.out.println(i.invertOccurenceIndex.get("and"));
    HTMLPageParser parser=new HTMLPageParser(new File("data/wiki/Copyright"));
  }

  @Test
  public void testLoadIndex() throws Exception{
    IndexerInvertedOccurrence old=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    old.constructIndex();
    String chromeList="PostingList{postings=[DocPosting{docId=1, occurrences=[270, 670, 675, 717, 1791, 1804, 2168, 2281]}]}";
    String googleList="PostingList{postings=[DocPosting{docId=0, occurrences=[6098, 6502]}, DocPosting{docId=1, occurrences=[2335]}]}";
    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.loadIndex();

    System.out.println(chromeList);
    System.out.println(googleList);
    Assert.assertEquals(chromeList,i.invertOccurenceIndex.get("chrome").toString());
    Assert.assertEquals(googleList,i.invertOccurenceIndex.get(WordStemmer.stem("google")).toString());
  }

  @Test
  public void testSearchSingleWord() throws Exception{
    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.constructIndex();

    i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.loadIndex();
    Query q=new Query("criminal");
    q.processQuery();
    Assert.assertEquals("http://en.wikipedia.org/wiki/Copyright",i.nextDoc(q,-1).getUrl());
//    System.out.println(i.nextDoc(q,-1));
    Query query=new Query("and");
    query.processQuery();
    Assert.assertEquals(0,i.nextDoc(query,-1).getDocId());
    Assert.assertEquals(1,i.nextDoc(query,0).getDocId());
  }

  @Test
  public void testMultiWords() throws Exception{
    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.constructIndex();

    i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.loadIndex();

    Query q=new Query("and chrome");
    q.processQuery();
    Assert.assertEquals("http://en.wikipedia.org/wiki/Web_browser",i.nextDoc(q,-1).getUrl());
    Assert.assertNull(i.nextDoc(q,1));
    Assert.assertNull(i.nextDoc(q,100));

    q=new Query("and fuck");
    q.processQuery();
    Assert.assertNull(i.nextDoc(q,-1));
  }


 // @Test
  public void testRealMultiWords() throws Exception{
//    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
//    i.constructIndex();

    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("conf/engine.conf"));
    i.loadIndex();

    Query q=new Query("hezel and");
    q.processQuery();
    System.out.println(i.nextDoc(q,-1));
//    Assert.assertEquals("http://en.wikipedia.org/wiki/Web_browser",i.nextDoc(q,-1).getUrl());
//    Assert.assertNull(i.nextDoc(q,1));
//    Assert.assertNull(i.nextDoc(q,100));
//
//    q=new Query("and fuck");
//    q.processQuery();
//    Assert.assertNull(i.nextDoc(q,-1));
  }


  @Test
  public void testRealPhrase() throws Exception{

    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("conf/engine.conf"));
    i.loadIndex();

    Query q=new Query("\"New York\"");
    q.processQuery();
    System.out.println(i.nextDoc(q,-1));
  }

  @Test
  public void testString(){
    String a="united states.html";
    System.out.println(a.replaceAll(".html$",""));
    System.out.println(a.hashCode());
  }
  @Test
  public void testPhrase() throws Exception{
    IndexerInvertedOccurrence i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.constructIndex();
    i=new IndexerInvertedOccurrence(new SearchEngine.Options("fixture/engine.conf"));
    i.loadIndex();

    Query q=new Query("\"and chrome\"");
    q.processQuery();

    Assert.assertNull(i.nextDoc(q,-1));
    Assert.assertEquals("http://en.wikipedia.org/wiki/Copyright",i.nextDoc(getQuery("\"a form of\""),-1).getUrl());
    Assert.assertNull(i.nextDoc(getQuery("\"a form of\""),0));
    DocumentIndexed d= (DocumentIndexed)i.nextDoc(getQuery("\"do not\""),-1);

    Assert.assertNotNull(d);
    Assert.assertEquals(new Integer(2),d.getTermCount("\"do not\""));
  }

  private Query getQuery(String q){
    Query query=new Query(q);
    query.processQuery();
    return query;
  }
}
