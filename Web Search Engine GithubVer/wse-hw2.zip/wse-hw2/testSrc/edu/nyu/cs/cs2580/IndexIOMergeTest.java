package edu.nyu.cs.cs2580;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class IndexIOMergeTest {

    @Test
    public void test() throws IOException {
        IndexerInvertedCompressed old=new IndexerInvertedCompressed(new SearchEngine.Options("conf/engine.conf"));
        old.constructIndex();
    }

}
