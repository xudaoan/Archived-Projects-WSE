package edu.nyu.cs.cs2580.io;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.junit.Test;

public class OutputTest {

    @Test
    public void test() {
        String FileLocation = "OutuputTest.txt";
        int [] arr = new int[]{1,1,0,1,0,0,0,1,1,0,1,0,1,0,1,1,1,0};

        FileOutputStream pOUTPUT;
        BitOutputStream bt;

        try {
            pOUTPUT = new FileOutputStream(FileLocation);
            bt = new BitOutputStream(pOUTPUT);
            for(int i = 0; i < arr.length ; i ++){
                bt.writeBit(arr[i]);
            }
            bt.close();
            
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }
        
        FileInputStream pINPUT;

        try {
            pINPUT = new FileInputStream(FileLocation);
            int it = pINPUT.read();
            while(it != -1){
                System.out.print(it + " ");
                it = pINPUT.read();
            }
            
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }
    }
}
