package edu.nyu.cs.cs2580;

import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/13/13
 * Time: 7:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class QueryTest {
  @Test
  public void testGetTokens() throws Exception {
//      Query query=new Query("New World \"New York\"\"New World\" Amazon Corp");
//      Query query=new Query("\"new york\" new \"new york \"");
      Query query=new Query("\"new york \"");
    query.processQuery();
    System.out.println(query.phrases);
    System.out.println(query.getTokens());
  }
}
