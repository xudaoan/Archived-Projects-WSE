package edu.nyu.cs.cs2580;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.TreeSet;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/11/13
 * Time: 3:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class IndexerInvertedDoconlyTest {
  @Before
  public void setUp() throws Exception {

  }

  @Test
  public void testProcessDocument() throws Exception {
    IndexerInvertedDoconly i=new IndexerInvertedDoconly(new SearchEngine.Options("fixture/engine.conf"));
    i.constructIndex();
//     i.processDocument(new File("data/wiki/Copyright"));
//     i.processDocument(new File("data/wiki/Web_browser"));
     Assert.assertEquals(1, i.corpusDocFrequencyByTerm("copyright"));
     Assert.assertEquals(1, i.corpusDocFrequencyByTerm("chrome"));
     Assert.assertEquals(2,i.corpusDocFrequencyByTerm("and"));
     Assert.assertEquals(1,i.corpusTermFrequency(WordStemmer.stem("criminal")));
    System.out.println(i.getPostingList("google"));

    Assert.assertEquals(2,i.corpusTermFrequency(WordStemmer.stem("google")));

    System.out.println(i.getPostingList("chrome"));
    System.out.println(i.getPostingList("and"));
  }

  @Test
  public void testLoadIndex() throws Exception {
    IndexerInvertedDoconly old=new IndexerInvertedDoconly(new SearchEngine.Options("fixture/engine.conf"));
    old.constructIndex();

    IndexerInvertedDoconly i=new IndexerInvertedDoconly(new SearchEngine.Options("fixture/engine.conf"));
    i.loadIndex();

    Assert.assertEquals(1, i.corpusDocFrequencyByTerm("copyright"));
    Assert.assertEquals(1, i.corpusDocFrequencyByTerm("chrome"));
    Assert.assertEquals(2,i.corpusDocFrequencyByTerm("and"));
    //as teacher said
    Assert.assertEquals(1,i.corpusTermFrequency(WordStemmer.stem("criminal")));

    System.out.println(i.getPostingList("chrome"));
    System.out.println(i.getPostingList("and"));
  }

  @Test
  public void testNext() throws Exception {
    IndexerInvertedDoconly old=new IndexerInvertedDoconly(new SearchEngine.Options("fixture/engine.conf"));
    old.constructIndex();

    IndexerInvertedDoconly i= new IndexerInvertedDoconly(new SearchEngine.Options("fixture/engine.conf"));
    i.loadIndex();
    Query query=new Query("and");
    query.processQuery();
    Assert.assertEquals(0,i.nextDoc(query,-1).getDocId());
    Assert.assertEquals(1, i.nextDoc(query, 0).getDocId());

  }

  //@Test
  public void testHeavyLoadAllData() throws Exception {
    IndexerInvertedDoconly i= new IndexerInvertedDoconly(new SearchEngine.Options("conf/engine.conf"));
    i.loadIndex();
    Query query=new Query("hezel and and");
    query.processQuery();
    Assert.assertEquals(3238,i.nextDoc(query,-1).getDocId());
    Assert.assertEquals(1, i.nextDoc(query, 0).getDocId());

  }

  @Test
  public void testMultiWords() throws Exception{
    IndexerInvertedDoconly i=new IndexerInvertedDoconly(new SearchEngine.Options("fixture/engine.conf"));
    i.constructIndex();
    Query q=new Query("and chrome");
    q.processQuery();
    Assert.assertEquals("http://en.wikipedia.org/wiki/Web_browser",i.nextDoc(q,-1).getUrl());
    Assert.assertNull(i.nextDoc(q,1));
    Assert.assertNull(i.nextDoc(q,100));

    q=new Query("and fuck");
    q.processQuery();
    Assert.assertNull(i.nextDoc(q,-1));
  }

  @Test
  public void testSplit(){
    TreeSet<Integer> a= new TreeSet<Integer>();
    a.add(1);
    a.add(2);
    a.add(3);
    System.out.println(Arrays.toString(a.toString().split("[\\[\\]]")));
  }
}
