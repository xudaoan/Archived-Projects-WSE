package edu.nyu.cs.cs2580;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.code.Decoder;
import edu.nyu.cs.cs2580.code.DecoderByteAligned;
import edu.nyu.cs.cs2580.index.PostingList;
import edu.nyu.cs.cs2580.io.IndexIO;
import edu.nyu.cs.cs2580.io.TermPostingPair;
import edu.nyu.cs.cs2580.code.DecoderByteAligned;


public class IndexIOTest {
    
    @Test
    public void test() throws IOException{
        IndexerInvertedOccurrence old=new IndexerInvertedOccurrence(new SearchEngine.Options("conf/engine.conf"));
        old.constructIndex();
        FileOutputStream offsetOutput;
        FileOutputStream indexOuput;
        String FileLocation1 = "offset.out";
        String FileLocation2 = "index.out";
        offsetOutput = new FileOutputStream(FileLocation1);
        indexOuput = new FileOutputStream(FileLocation2);
        offsetOutput.getChannel().position(0);
        indexOuput.getChannel().position(0);
        

        System.out.println("Writing Index into File");
        
        IndexIO.indexWriter(old.invertOccurenceIndexForWrite, offsetOutput, indexOuput, CodeType.None);
        offsetOutput.close();
        indexOuput.close();

        FileInputStream offsetInput;
        FileInputStream indexInput;
        offsetInput = new FileInputStream(FileLocation1);
        indexInput = new FileInputStream(FileLocation2);
        
        Map<String, Integer> offsets = IndexIO.getTermOffsets(offsetInput);
        
        System.out.println("Validation Starts");
        
        boolean correct = true;
        for(Map.Entry<String, PostingList> entry : old.invertOccurenceIndexForWrite.entrySet()){
            String term = entry.getKey();
            PostingList postlist = IndexIO.postingListReader(indexInput, term, offsets,CodeType.None);
            if(postlist.toString().equals(entry.getValue().toString())){
//                System.out.println("Yeah!");
//                System.out.println(entry.getKey());
//                System.out.println(entry.getValue());
//                System.out.println(postlist);
//                System.out.println("++++++++++++++++++++");
                continue;
            }
            correct = false;
            System.out.println(">>>>>>>>>>>>>>FAIL<<<<<<<<<<<<<<");
            System.out.println(entry.getKey());
            System.out.println(entry.getValue());
            System.out.println(postlist);
            break;
        }
        
        Assert.assertTrue(correct);
    }
    
    @Test
    public void presidentTest() throws IOException{
        String term = "president";
        int offset = 36603;

        String FileLocation2 = "index.out";
        FileInputStream indexInput;
        indexInput = new FileInputStream(FileLocation2);
        indexInput.getChannel().position(offset);
        Decoder decoder = new DecoderByteAligned(indexInput);
        for(int i= 0 ; i< 10;i++){
            System.out.print(decoder.next() + " ");
        }
    }

}
