package edu.nyu.cs.cs2580;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.io.IndexIO;

public class MergeTest {
}
