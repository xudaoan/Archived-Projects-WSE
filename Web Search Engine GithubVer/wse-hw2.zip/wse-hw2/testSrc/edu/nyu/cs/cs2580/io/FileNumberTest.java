package edu.nyu.cs.cs2580.io;

import static org.junit.Assert.*;

import org.junit.Test;

public class FileNumberTest {

    @Test
    public void test() {
        String filename = "Number";
        IndexIO.writeFileNumber(filename, 111);
        System.out.println(IndexIO.readFileNumber(filename));
    }

}
