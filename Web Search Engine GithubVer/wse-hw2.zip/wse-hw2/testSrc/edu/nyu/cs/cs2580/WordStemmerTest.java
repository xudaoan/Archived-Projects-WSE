package edu.nyu.cs.cs2580;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/12/13
 * Time: 11:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class WordStemmerTest {
  @Test
  public void testStem() throws Exception {
//    Assert.assertEquals("happy",WordStemmer.stem("Happier"));
    Assert.assertEquals("crimin",WordStemmer.stem("criminal"));
  }
}
