package edu.nyu.cs.cs2580.io;

import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.code.NumberDecoder;
import edu.nyu.cs.cs2580.indexer.ds.PostingList;
import edu.nyu.cs.cs2580.indexer.ds.PostingListDecoder;
import edu.nyu.cs.cs2580.indexer.ds.PostingListEncoder;

import java.io.*;
import java.util.*;

public class IndexIO {


  /**
   * Read the termOffset file and get the term-offset ArrayList
   *
   * @param input
   * @return
   */
  private static ArrayList<TermOffsetPair> getTermOffsetsAsArray(InputStream input) {
    ArrayList<TermOffsetPair> offsets = new ArrayList<TermOffsetPair>();
    Scanner scanner = new Scanner(input);

    while (scanner.hasNextLine()) {
      String line = scanner.nextLine();
      String[] words = line.split("\\s+");
      offsets.add(new TermOffsetPair(words[0], Integer.parseInt(words[1])));
    }
    scanner.close();
    return offsets;
  }


  private static byte[] postingListByteArrayReader(FileInputStream input,
                                                   ArrayList<TermOffsetPair> offsets, int termIndex) throws IOException {
    int startOffset = offsets.get(termIndex).offset;
    int readOffset;
    if (termIndex == offsets.size() - 1) {
      readOffset = input.available();
    } else {
      readOffset = offsets.get(termIndex + 1).offset - startOffset;
    }
    byte[] result = new byte[readOffset];
    input.read(result);
    return result;
  }


  /**
   * Write a line to the offset file
   *
   * @param term
   * @param offset
   * @param offsetOutput
   * @throws IOException
   */
  private static void writeOffset(String term, int offset, FileOutputStream offsetOutput)
          throws IOException {
    StringBuffer offsetLine = new StringBuffer();
    offsetLine.append(term);
    offsetLine.append(" ");
    offsetLine.append(offset);
    offsetLine.append("\n");
    byte[] byteArr = offsetLine.toString().getBytes();
    offsetOutput.write(byteArr);
  }

  /**
   * Write the indexes into file.
   * Do not assume write from the beginning of the file
   * Make sure the stream is at the correct position before use.
   *
   * @param indexes      the index storing the term - postinglist pair, should have
   *                     been SORTED before this call
   * @param offsetOutput the FileStream that stores the offset of each term
   * @param indexOutput  the FileStream that stores all the posting lists
   * @throws IOException
   */
  private static void writeIndex(ArrayList<TermPostingPair> indexes,
                                 FileOutputStream offsetOutput, FileOutputStream indexOutput, CodeType codeType)
          throws IOException {
    Integer currentOffset = (int) indexOutput.getChannel().position();
    int indexSize = indexes.size();

    PostingListEncoder postingListEncoder = new PostingListEncoder(indexOutput, codeType);
    for (int i = 0; i < indexSize; i++) {
      TermPostingPair term = indexes.get(i);
//      System.out.println(term.term+" offset is "+currentOffset);
      writeOffset(term.term, currentOffset, offsetOutput);
//            writePostingList(term.postingList, indexOutput, codeType);
//      System.out.println("writing index, code type is "+codeType.name());
//      System.out.println("postinglist size is "+term.postingList.getPostings().size());
      postingListEncoder.encodeAndWritePostingList(term.postingList);
      currentOffset = (int) indexOutput.getChannel().position();

    }
  }

  /**
   * Write the indexes into file.
   * Do not assume write from the beginning of the file
   * Make sure the stream is at the correct position before use.
   *
   * @param indexes      the index storing the term - postinglist pair
   * @param offsetOutput the FileStream that stores the offset of each term
   * @param indexOutput  the FileStream that stores all the posting lists
   * @throws IOException
   */
  public static void writeIndex(Map<String, PostingList> indexes, FileOutputStream offsetOutput,
                                FileOutputStream indexOutput, CodeType codeType) throws IOException {
    ArrayList<TermPostingPair> theList = new ArrayList<TermPostingPair>();
    theList.ensureCapacity(indexes.size());
    for (Map.Entry<String, PostingList> entry : indexes.entrySet()) {
      TermPostingPair tmp = new TermPostingPair(entry.getKey(), entry.getValue());
      theList.add(tmp);
    }
    Collections.sort(theList);
    writeIndex(theList, offsetOutput, indexOutput, codeType);
  }

  /****************************************************************
   ****************************************************************
   *
   * The Following is the Index Merge
   *
   ****************************************************************
   ****************************************************************/

  /**
   * Poll from the PriorityQueue, and put the next term into the queue
   *
   * @param queue
   * @param inputIndexs
   * @param offsetss
   * @param codeType
   * @return
   * @throws IOException
   */
  private static TermPostingListBytes priorityQueuePoll(
          PriorityQueue<TermPostingListBytes> queue, ArrayList<FileInputStream> inputIndexs,
          ArrayList<ArrayList<TermOffsetPair>> offsetss, CodeType codeType) throws IOException {

    TermPostingListBytes min = queue.poll();
    FileInputStream input = inputIndexs.get(min.fileIndex);
    ArrayList<TermOffsetPair> offsets = offsetss.get(min.fileIndex);
    int nextTermIndex = min.termIndex + 1;

    // There is no next term in that file
    if (nextTermIndex >= offsets.size()) {
      return min;
    }

    byte[] postingListAsByteArray = postingListByteArrayReader(input, offsets, nextTermIndex);
    TermPostingListBytes tmp = new TermPostingListBytes(offsets.get(nextTermIndex).term,
            postingListAsByteArray, min.fileIndex, nextTermIndex);

    queue.add(tmp);

    return min;
  }

  private static void Merge(ArrayList<FileInputStream> inputIndexs,
                            ArrayList<ArrayList<TermOffsetPair>> offsetss, CodeType codeType,
                            FileOutputStream offsetOutput, FileOutputStream indexOutput) throws IOException {

    int fileCount = inputIndexs.size();
    PriorityQueue<TermPostingListBytes> queue = new PriorityQueue<TermPostingListBytes>(
            fileCount);

        /*
         * Queue initialization.
         * Skip empty index files (offset files)
         */
    for (int i = 0; i < fileCount; i++) {

      ArrayList<TermOffsetPair> termOffsetList = offsetss.get(i);
      if (termOffsetList.isEmpty())
        continue;

      TermOffsetPair head = termOffsetList.get(0);
      byte[] postingListAsByteArray = postingListByteArrayReader(inputIndexs.get(i),
              termOffsetList, 0);
      TermPostingListBytes tmp = new TermPostingListBytes(head.term, postingListAsByteArray,
              i, 0);

      queue.add(tmp);

    }

    int iteration=0;

    while (!queue.isEmpty()) {
      TermPostingListBytes min = priorityQueuePoll(queue, inputIndexs, offsetss, codeType);
      //TODO: bug??? missing final file for each batch
      if (!queue.isEmpty() && queue.peek().compareTo(min) == 0) {
        TreeMap<Integer, PostingList> postingListMap = new TreeMap<Integer, PostingList>();

        PostingList thisPostingList = readPostingListFromBytes(min.input, codeType);
        postingListMap.put(min.fileIndex, thisPostingList);

        while (queue.peek().compareTo(min) == 0) {
          min = priorityQueuePoll(queue, inputIndexs, offsetss, codeType);
          thisPostingList = readPostingListFromBytes(min.input, codeType);
          postingListMap.put(min.fileIndex, thisPostingList);
        }

        PostingList postingList = new PostingList();

        for (Map.Entry<Integer, PostingList> entry : postingListMap.entrySet()) {
          postingList.addAllPosting(entry.getValue());
        }

        int offset = (int) indexOutput.getChannel().position();
        String term = min.term;
        writeOffset(term, offset, offsetOutput);
        PostingListEncoder postingListEncoder = new PostingListEncoder(indexOutput, codeType);
        postingListEncoder.encodeAndWritePostingList(postingList);
        indexOutput.flush();

      } else {
        //only one file contains currentTerm
        int offset = (int) indexOutput.getChannel().position();
        String term = min.term;
        writeOffset(term, offset, offsetOutput);
        indexOutput.write(min.input);
        indexOutput.flush();
      }
    }

  }

  private static PostingList readPostingListFromBytes(byte[] input, CodeType codeType) throws IOException {
    ByteArrayInputStream byteStream = new ByteArrayInputStream(input);
    return new PostingListDecoder(NumberDecoder.getDecoderByType(byteStream, codeType)).decodePostingList();
  }

  public static void Merge(String indexPrefix, int fileCount, CodeType codeType)
          throws IOException {
    ArrayList<FileInputStream> inputIndexs = new ArrayList<FileInputStream>(fileCount);
    ArrayList<ArrayList<TermOffsetPair>> offsetss = new ArrayList<ArrayList<TermOffsetPair>>(
            fileCount);
    for (int i = 1; i <= fileCount; i++) {
      String fileOffset = indexPrefix + "/offset.idx" + i;
      String fileIndex = indexPrefix + "/index.idx" + i;
      System.out.println("Load index from: " + fileOffset + "," + fileIndex);
      FileInputStream indexStream = new FileInputStream(fileIndex);
      FileInputStream offsetStream = new FileInputStream(fileOffset);
      inputIndexs.add(indexStream);
      offsetss.add(getTermOffsetsAsArray(offsetStream));
    }

    String outputFileOffset = indexPrefix + "/offset.idx";
    String outputFileIndex = indexPrefix + "/index.idx";
    FileOutputStream offsetOutput = new FileOutputStream(outputFileOffset);
    FileOutputStream indexOutput = new FileOutputStream(outputFileIndex);

    Merge(inputIndexs, offsetss, codeType, offsetOutput, indexOutput);
    offsetOutput.close();
    indexOutput.close();
  }

  /**
   * *************************************************************
   * **************************************************************
   * <p/>
   * The Following is the Misc.
   * <p/>
   * **************************************************************
   * *************************************************************
   */

  public static void writeFileNumber(String filename, int number) {
    try {
      FileOutputStream file = new FileOutputStream(filename);
      file.write(("" + number).getBytes());
      file.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static int readFileNumber(String filename) {
    try {
      FileInputStream file = new FileInputStream(filename);
      Scanner scanner = new Scanner(file);
      int it = scanner.nextInt();
      scanner.close();
      return it;
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    return -1;
  }
}
