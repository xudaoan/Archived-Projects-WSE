package edu.nyu.cs.cs2580.indexer.ds;

import edu.nyu.cs.cs2580.indexer.IndexerInvertedOccurrence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @CS2580: Implement this class for HW2.
 */

public class PostingList{
  @Override
  public String toString() {
    return "PostingList{" +
            "postings=" + postings +

            '}';
  }


  public List<DocPosting> getPostings() {
    return postings;
  }

  private List<DocPosting> postings=new ArrayList<DocPosting>();
  Map<Integer,Integer> postingDocIdIndex=new HashMap<Integer, Integer>();//<docId, indexOfPosting>

  public List<DocPosting> getDocPostings(){
      return this.postings;
  }
  /**
   *
   * @param p
   */
  public void addPosting(DocPosting p){
    if (postingDocIdIndex.containsKey(p.getDocId()))
      throw new RuntimeException("posting for doc "+p.getDocId()+" is already exist, can not override");
    synchronized(this) {
      postings.add(p);
      postingDocIdIndex.put(p.getDocId(),postings.size()-1);
    }
  }
  
  public void addAllPosting(PostingList in){
      List<DocPosting> inList = in.getDocPostings();
      int size = inList.size();
      for(int i = 0; i < size;i++){
          this.addPosting(inList.get(i));
      }
  }

  public boolean hasPostingForDoc(Integer docId){
    return postingDocIdIndex.containsKey(docId);
  }
  public DocPosting getPostingByDocId(Integer docId){
    return postings.get(postingDocIdIndex.get(docId));
  }

  private int ct=0;
  private DocPosting getLastPosting() {
    if (postings.isEmpty())
      return null;
    return postings.get(postings.size()-1);
  }

  private DocPosting getFirstPosting() {
    return postings.get(0);
  }

  public Integer greaterDocID(int currentDocId) {
    if(getLastPosting().getDocId()<=currentDocId)
      return IndexerInvertedOccurrence.INFINITY;

    if(getFirstPosting().getDocId()>currentDocId)
    {
      ct=0;
      return getFirstPosting().getDocId();
    }

    if(ct>0 && postings.get(ct-1).getDocId()>currentDocId){
      ct=0;
    }

    while(postings.get(ct).getDocId()<=currentDocId){
      ct++;
    }
    return postings.get(ct).getDocId();
  }
}