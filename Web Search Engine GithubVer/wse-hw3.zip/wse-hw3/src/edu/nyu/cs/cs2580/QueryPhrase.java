package edu.nyu.cs.cs2580;

import edu.nyu.cs.cs2580.html.WordStemmer;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @CS2580: implement this class for HW2 to handle phrase. If the raw query is
 * ["new york city"], the presence of the phrase "new york city" must be
 * recorded here and be used in indexing and ranking.
 */
public class QueryPhrase extends Query {

  public QueryPhrase(String query) {
    super(query);
  }

  @Override
  public void processQuery() {
    if (_query == null) {
      return;
    }
    //
    String[] strs=_query.split("[\"]");
    for(int i=0;i<strs.length;i++){
      if (i%2==1){
        String phraseStr=strs[i];
        phrases.add(parsePhrase(phraseStr));
      }
    }
    String cleanQuery=_query.replaceAll("\""," ");
    Scanner s = new Scanner(cleanQuery);
    while (s.hasNext()) {
      _tokens.add(WordStemmer.stem(s.next()));
    }
    s.close();
  }

  //"new york" new "new york "
  private List<String> parsePhrase(String phraseStr) {
    List<String> phrase=new ArrayList<String>();

    for(String w:phraseStr.split(" ")){
      w=w.trim();
      w=WordStemmer.stem(w);
      if(!w.isEmpty())
        phrase.add(w);
    }
    return phrase;
  }

  public boolean isPhraseQuery() {
    return !phrases.isEmpty();
//    return _query.contains("\"");  //To change body of created methods use File | Settings | File Templates.
  }
}
