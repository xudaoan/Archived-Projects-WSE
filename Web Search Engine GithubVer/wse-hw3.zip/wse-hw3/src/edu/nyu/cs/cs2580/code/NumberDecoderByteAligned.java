package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.InputStream;

public class NumberDecoderByteAligned extends NumberDecoder {
    private InputStream input;

    public NumberDecoderByteAligned(InputStream input) {
        this.input = input;
    }

    @Override
    public int next() throws IOException {
        int nextByte = input.read();
        
        if(nextByte == -1){
            return -1;
        }
        
        if (nextByte > 0x7f) {
            return nextByte & 0x7f;
        }
        int result = 0;
        while (nextByte < 0x80) {
            result = (result << 7) + nextByte;
            nextByte = input.read();

        }
        result = (result << 7) + (nextByte & 0x7f);
        return result;
    }
}
