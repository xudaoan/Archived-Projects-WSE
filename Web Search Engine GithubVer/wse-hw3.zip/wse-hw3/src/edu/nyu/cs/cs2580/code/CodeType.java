package edu.nyu.cs.cs2580.code;

public enum CodeType {
    ByteAligned,ByteAlignedBuffered,EliasDelta,EliasGamma,None
}
