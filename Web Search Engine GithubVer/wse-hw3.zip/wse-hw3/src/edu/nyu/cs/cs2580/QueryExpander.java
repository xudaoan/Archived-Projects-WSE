package edu.nyu.cs.cs2580;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.nyu.cs.cs2580.html.HTMLPageParser;

public class QueryExpander {

    private List<ScoredDocument> documents;
    private String prefix;
    private int termCount;
    private String query;

    /**
     * 
     * @param query
     *            Query Literal
     * @param prefix
     *            folder to put the files
     * @param termCount
     *            number of terms, m
     * @param documents
     *            documents list
     */
    QueryExpander(String query, String prefix, int termCount, List<ScoredDocument> documents) {
        this.query = query;
        this.prefix = prefix;
        this.documents = documents;
        this.termCount = termCount;
    }

    private Map.Entry<String, Integer> extractMax(Map<String, Integer> map) {
        Map.Entry<String, Integer> result = new AbstractMap.SimpleEntry<String, Integer>(null,
                Integer.MIN_VALUE);

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (result.getValue() < entry.getValue())
                result = entry;
        }
        map.remove(result.getKey());
        return result;
    }

    private Map<String, Double> queryExpand() throws IOException {

        HashMap<String, Integer> wordCount = new HashMap<String, Integer>();

        for (ScoredDocument document : documents) {
            File file = new File(prefix + "/" + document.getName());
            HTMLPageParser parser = new HTMLPageParser(file);
            for (String term : parser.getStemmedTitleWordsVector()) {
                if (wordCount.containsKey(term))
                    wordCount.put(term, wordCount.get(term) + 1);
                else
                    wordCount.put(term, 1);
            }
            for (String term : parser.getStemmedBodyWordsVector()) {
                if (wordCount.containsKey(term))
                    wordCount.put(term, wordCount.get(term) + 1);
                else
                    wordCount.put(term, 1);
            }
        }

        Map<String, Integer> topM = new HashMap<String, Integer>();
        int topMCount = 0;
        for (int i = 0; i < termCount;) {
            Map.Entry<String, Integer> max = extractMax(wordCount);
            if (StopwordsChecker.isStopword(max.getKey())) {
                continue;
            }
            topM.put(max.getKey(), max.getValue());
            topMCount = topMCount + max.getValue();
            i++;
        }

        Map<String, Double> result = new HashMap<String, Double>();
        for (Map.Entry<String, Integer> entry : topM.entrySet()) {
            result.put(entry.getKey(), (double) entry.getValue() / topMCount);
        }

        return result;
    }

    public String Expand() throws IOException {
        StringBuffer sb = new StringBuffer();
        Map<String, Double> result = this.queryExpand();
        for (Map.Entry<String, Double> entry : result.entrySet()) {
            sb.append(entry.getKey());
            sb.append("\t");
            sb.append(entry.getValue());
            sb.append("\n");
        }
        return sb.toString();
    }
}
