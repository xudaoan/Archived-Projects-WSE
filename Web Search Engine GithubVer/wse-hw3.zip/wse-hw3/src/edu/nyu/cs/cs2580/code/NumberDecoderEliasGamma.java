package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.InputStream;

import edu.nyu.cs.cs2580.io.BitInputStream;

public class NumberDecoderEliasGamma extends NumberDecoder {
    private BitInputStream input;

    public NumberDecoderEliasGamma(InputStream input) {
        this.input = new BitInputStream(input);
    }

    @Override
    public int next() throws IOException {
        int nextBit = input.readBit();
        if (nextBit == -1)
            return -1;

        if (nextBit == 0)
            return 1;

        int d = 0;
        while (nextBit == 1) {
            d++;
            nextBit = input.readBit();
        }
        
        if(nextBit == -1)
            return -1;

        int result = 1;
        int r = 0;
        for (int i = 0; i < d; i++) {
            r = (r << 1) + input.readBit();
            result = result << 1;
        }
        result = result + r;
        return result;
    }
}
