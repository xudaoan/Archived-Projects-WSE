package edu.nyu.cs.cs2580;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/5/13
 * Time: 6:48 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DocumentsCollection extends Iterable<Document>{
  int size();

  void add(Document doc);

  Document getByDocId(int docid);
}
