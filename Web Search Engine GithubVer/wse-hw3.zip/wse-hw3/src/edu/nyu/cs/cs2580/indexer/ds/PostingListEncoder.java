package edu.nyu.cs.cs2580.indexer.ds;

import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.code.NumberEncoder;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/7/13
 * Time: 9:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class PostingListEncoder {
  private final FileOutputStream indexOutput;
  private final NumberEncoder numberEncoder;

  public PostingListEncoder(FileOutputStream indexOutput, CodeType codeType) {
    this.indexOutput=indexOutput;
    this.numberEncoder=NumberEncoder.getEncoderByType(indexOutput,codeType);
  }

  public void encodeAndWritePostingList(PostingList postingList) throws IOException {
    List<DocPosting> postings = postingList.getPostings();
    int size = postings.size();
    numberEncoder.put(size);
    for (int i = 0; i < size; i++) {
      writePosting(postings.get(i));
    }
    numberEncoder.flush();
  }


  /****************************************************************
   * **************************************************************
   *
   * The Following is the Writers
   *
   * **************************************************************
   * **************************************************************/

  /**
   * Write a document post using an numberEncoder
   *
   * @param posting
   * @throws java.io.IOException
   */
  private  void writePosting(DocPosting posting) throws IOException {
    numberEncoder.put(posting.getDocId());
    numberEncoder.put(posting.getOccurrences().size());
    for (Integer occ : posting.getOccurrences()) {
      numberEncoder.put(occ);
    }
  }


}
