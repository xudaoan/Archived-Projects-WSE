package edu.nyu.cs.cs2580.indexer.ds;

import edu.nyu.cs.cs2580.code.NumberDecoder;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/7/13
 * Time: 9:06 PM
 * Decode a PostingList from stream directly, no need to do random access
 */
public class PostingListDecoder {

  private final NumberDecoder numNumberDecoder;

  public PostingListDecoder(NumberDecoder numberDecoder) {
         this.numNumberDecoder = numberDecoder;
  }


  /**
   * Read a posting list from a given decoder
   * @return
   * @throws java.io.IOException
   */
  public  PostingList decodePostingList() throws IOException {
    PostingList postingList = new PostingList();
    int docCount = numNumberDecoder.next();
    for (int i = 0; i < docCount; i++) {
      DocPosting posting = readPosting();
      postingList.addPosting(posting);
    }
    return postingList;
  }

  /**
   * Read a document post from the decoder.
   * The decoder should have been set properly before the call.
   *
   * @return
   * @throws IOException
   */
  private  DocPosting readPosting() throws IOException {

    int docID = numNumberDecoder.next();

    DocPosting posting = new DocPosting(docID);

    int occurrencesCount = numNumberDecoder.next();
    for (int i = 0; i < occurrencesCount; i++) {
      posting.addOccurrence(numNumberDecoder.next());
    }

    return posting;
  }
}
