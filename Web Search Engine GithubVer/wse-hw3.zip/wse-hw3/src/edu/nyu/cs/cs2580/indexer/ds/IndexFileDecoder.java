package edu.nyu.cs.cs2580.indexer.ds;

import edu.nyu.cs.cs2580.code.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/7/13
 * Time: 8:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class IndexFileDecoder {
  private final CodeType codeType;
    FileInputStream indexFileInputStream;


  public IndexFileDecoder(CodeType codeType, FileInputStream indexFileInputStream) {
    this.codeType=codeType;
    this.indexFileInputStream=indexFileInputStream;
  }

  /**
   * Read a posting list from a given file input stream and the term
   * and the term-offset map
   * The method getTermOffsets should have been called before calling this.
   * @param term
   *            the term
   * @param termOffsetTable
   *            The term-offset map
   * @return
   * @throws IOException
   */
  public  PostingList readPostingListByTerm(String term,
                                            TermOffsetTable termOffsetTable) throws IOException {
    if (termOffsetTable.containsKey(term)){
      int offset=termOffsetTable.get(term);
      FileChannel channel = indexFileInputStream.getChannel();
      channel.position(offset);
      PostingList postingList = new PostingListDecoder(NumberDecoder.getDecoderByType(indexFileInputStream,codeType)).decodePostingList();
      return postingList;
    }
    return null;
  }


}