package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.InputStream;

public abstract class NumberDecoder {

    public abstract int next() throws IOException;

  /**
   * Create NumberDecoder based on the input codeType
   *
   * @param input
   *            The InputStream to be decoded
   * @param codeType
   *            Coding function chosen
   * @return
   */
  public static NumberDecoder getDecoderByType(InputStream input, CodeType codeType) {
    switch (codeType) {
      case ByteAligned:
        return new NumberDecoderByteAligned(input);
      case ByteAlignedBuffered:
        return new NumberDecoderByteAligned(input);
      case EliasDelta:
        return new NumberDecoderEliasDelta(input);
      case EliasGamma:
        return new NumberDecoderEliasDelta(input);
      case None:
        return new NumberDecoderNone(input);
    }
    return null;
  }
}
