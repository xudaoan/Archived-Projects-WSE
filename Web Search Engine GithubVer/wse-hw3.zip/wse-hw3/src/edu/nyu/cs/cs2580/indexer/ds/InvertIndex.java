package edu.nyu.cs.cs2580.indexer.ds;

public interface InvertIndex {
    
    public PostingList get(String term);
    
    public boolean containsKey(String term);
}