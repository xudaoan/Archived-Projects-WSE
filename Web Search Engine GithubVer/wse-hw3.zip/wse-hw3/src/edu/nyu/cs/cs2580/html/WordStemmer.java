package edu.nyu.cs.cs2580.html;

import org.tartarus.snowball.SnowballStemmer;
import org.tartarus.snowball.ext.porterStemmer;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/12/13
 * Time: 11:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class WordStemmer {
  private static SnowballStemmer stemmer = new porterStemmer();
  static public String stem(String word) {
    stemmer.setCurrent(word.toLowerCase());
    stemmer.stem();
    return stemmer.getCurrent();
  }
}
