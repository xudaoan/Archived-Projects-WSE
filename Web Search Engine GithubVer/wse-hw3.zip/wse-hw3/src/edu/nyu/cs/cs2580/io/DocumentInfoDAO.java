package edu.nyu.cs.cs2580.io;

import edu.nyu.cs.cs2580.*;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/12/13
 * Time: 4:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentInfoDAO {
  public static final String FS = "|";
  private  PrintWriter docInfoWriter=null;
  private static HashMap<String, Double> pageRankeMap;

  private static HashMap<String, Integer> numviewMap;

  static{
    try {
      pageRankeMap= (HashMap<String, Double>) new CorpusAnalyzerPagerank(SearchEngine.OPTIONS).load();
      numviewMap =(HashMap<String,Integer>)new LogMinerNumviews(SearchEngine.OPTIONS).load();
    } catch (IOException e) {
      System.out.println("Fatal: can not load pagerank and numviews");
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
  }
  private PrintWriter getWriter() throws IOException {
    if (docInfoWriter==null)
      docInfoWriter = new PrintWriter(new BufferedWriter(new FileWriter(filePath,false)));
  return docInfoWriter;
  }

  public DocumentInfoDAO(String filePath) throws IOException {
    this.filePath = filePath;
  }

  String filePath;
  public String getUrlName(String url){
    String[] sections=url.split("/");
    String docName=sections[sections.length-1];
    return docName;
  }
  public void writeDocInfo(Integer docId, String title, String url, List<String> allWords) throws IOException {
    HashMap<String,Integer> wordCounter=new HashMap<String, Integer>();
    double wordCount=allWords.size();
    String docName=getUrlName(url);
    Double pagerank=pageRankeMap.containsKey(docName)?pageRankeMap.get(docName):0.0;
    Integer numview=numviewMap.containsKey(docName)?numviewMap.get(docName):0;
    getWriter().println(docId + FS + title + FS + url+FS+wordCount+FS+pagerank+FS+numview);
    getWriter().flush();
  };
  public void close() throws IOException {
        getWriter().close();
  }

  public DocumentsCollection readAllDocuments() throws IOException {
    DocumentsCollection result = new DocumentsCollectionInMemory();
    BufferedReader documentInfoReader=new BufferedReader(new FileReader(filePath));
    String line=null;
    while((line=documentInfoReader.readLine())!=null){

      if (line.equals(""))
        continue;
      String[] fields=line.split("\\"+FS);
      //System.out.println(line);
      Document doc=new Document(Integer.valueOf(fields[0]));
      doc.setTitle(fields[1]);
      doc.setUrl(fields[2]);
      doc.setWordCount(Double.valueOf(fields[3]));
      doc.setPageRank(Float.valueOf(fields[4]));
      doc.setNumViews(Integer.valueOf(fields[5]));
      result.add(doc);
    }
    documentInfoReader.close();
    return result;

  }
}
