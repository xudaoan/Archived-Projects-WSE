package edu.nyu.cs.cs2580;

import edu.nyu.cs.cs2580.SearchEngine.Options;
import edu.nyu.cs.cs2580.html.HTMLPageParser;

import java.io.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * @CS2580: Implement this class for HW3.
 */
public class CorpusAnalyzerPagerank extends CorpusAnalyzer {
  HashMap<String, Integer> outLinkCounts = new HashMap<String, Integer>();
  HashMap<String, List<String>> inLinks = new HashMap<String, List<String>>();
  HashMap<String, Double> pageRanks = new HashMap<String, Double>();
  Double lambda = 0.9;
  int iterations = 2;

  public int getIterations() {
    return iterations;
  }

  public void setIterations(int iterations) {
    this.iterations = iterations;
  }

  public Double getLambda() {
    return lambda;
  }

  public void setLambda(Double lambda) {
    this.lambda = lambda;
  }


  public boolean addInlink(String from, String to) {
    if (!outLinkCounts.containsKey(to))
      return false;//target is not in our corpus

    List<String> inlinkDocIds = inLinks.get(to);
    inlinkDocIds.add(from);
    return true;
  }

  public CorpusAnalyzerPagerank(Options options) {
    super(options);
  }

  /**
   * This function processes the corpus as specified inside  _options
   * and extracts the "internal" graph structure from the pages inside the
   * corpus. Internal means we only store links between two pages that are both
   * inside the corpus.
   * <p/>
   * Note that you will not be implementing a real crawler. Instead, the corpus
   * you are processing can be simply read from the disk. All you need to do is
   * reading the files one by one, parsing them, extracting the links for them,
   * and computing the graph composed of all and only links that connect two
   * pages that are both in the corpus.
   * <p/>
   * Note that you will need to design the data structure for storing the
   * resulting graph, which will be used by the compute function. Since
   * the graph may be large, it may be necessary to store partial graphs to
   * disk before producing the final graph.
   *
   * @throws IOException
   */
  @Override
  public void prepare() throws IOException {
    System.out.println("Preparing " + this.getClass().getName());
    String corpusPrefix = _options._corpusPrefix;
    File corpusDir = new File(corpusPrefix);

    initMaps(corpusDir);

    for (File corpusFile : corpusDir.listFiles()) {
      if (isEmptyPage(corpusFile))
        continue;
      extractlinks(corpusFile);
    }
  }


  private void extractlinks(File corpusFile) throws IOException {
    String docName = corpusFile.getName();
    int outlinkCount = 0;
    HeuristicLinkExtractor linkExtractor = new HeuristicLinkExtractor(corpusFile);
    String linkTarget;

    while ((linkTarget = linkExtractor.getNextInCorpusLinkTarget()) != null) {
      if (addInlink(docName, linkTarget))
        outlinkCount++;
    }
    outLinkCounts.put(docName, outlinkCount);
  }


  private boolean isEmptyPage(File file) throws IOException {
    HTMLPageParser parser = new HTMLPageParser(file);
    return parser.getRawTitleContent().equals("");
  }

  private void initMaps(File corpusDir) throws IOException {
    for (File corpusFile : corpusDir.listFiles()) {
      String url = corpusFile.getName();
      if (isEmptyPage(corpusFile)) {
        System.out.println("Empty title, skipping " + corpusFile.getAbsolutePath());
        continue;
      }
      outLinkCounts.put(url, 0);
      inLinks.put(url, new LinkedList<String>());
      pageRanks.put(url, 0.0);
    }
  }


  /**
   * This function computes the PageRank based on the internal graph generated
   * by the prepare function, and stores the PageRank to be used for
   * ranking.
   * <p/>
   * Note that you will have to store the computed PageRank with each document
   * the same way you do the indexing for HW2. I.e., the PageRank information
   * becomes part of the index and can be used for ranking in serve mode. Thus,
   * you should store the whatever is needed inside the same directory as
   * specified by _indexPrefix inside
   *
   * @throws IOException
   */
  @Override
  public void compute() throws IOException {
    System.out.println("Computing using " + this.getClass().getName());
    double score = 1.0 / outLinkCounts.size(); //initial score is 1/N
    for (String docName : pageRanks.keySet()) {
      pageRanks.put(docName, score);
    }

    for (int i = 0; i < iterations; i++) {
      HashMap<String, Double> newPageRank = new HashMap<String, Double>();
      for (String docName : pageRanks.keySet()) {
        newPageRank.put(docName, computeUpdatedRank(docName));
      }
      this.pageRanks = newPageRank;
    }
    persistPageRank();
  }

  private void persistPageRank() throws IOException {
    String filePath = defaultPageRankPath();
    System.out.println("persisting page rank to " + filePath);
    //TODO: we can use hashcode as key to save space

    FileOutputStream fileOut = new FileOutputStream(filePath);
    ObjectOutputStream out = new ObjectOutputStream(fileOut);
    out.writeObject(pageRanks);
    out.close();
  }



  private String defaultPageRankPath() {
    return _options._indexPrefix + "/corpus_pageRank.idx";
  }

  private Double computeUpdatedRank(String docName) {
    Double score;
    double n = Double.valueOf(pageRanks.size());
    score = (1.0 - lambda) / n;
    List<String> incomingLinks = getInLinkedDocsForDoc(docName);
    for (String incomingDocName : incomingLinks) {
      score += lambda * pageRanks.get(incomingDocName) / getOuterLinkCountForDoc(incomingDocName);
    }
    return score;
  }

  /**
   * During indexing mode, this function loads the PageRank values computed
   * during mining mode to be used by the indexer.
   *
   * @throws IOException
   */
  @Override
  public Object load() throws IOException {
    System.out.println("Loading using " + this.getClass().getName());
    String filePath = defaultPageRankPath();
    return loadFromPath(filePath);
  }

  public Object loadFromPath(String filePath) throws IOException {
    System.out.println("Loading numview data from "+filePath);
    FileInputStream fileIn =
            new FileInputStream(filePath);
    ObjectInputStream in = new ObjectInputStream(fileIn);
    try {
      HashMap<String, Double> result = (HashMap<String, Double>) in.readObject();
      return result;
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } finally {
      in.close();
      fileIn.close();
    }

    return null;
  }

  public int numberOfDocs() {
    return outLinkCounts.size();  //To change body of created methods use File | Settings | File Templates.
  }

  public int getOuterLinkCountForDoc(String name) {
    return outLinkCounts.get(name);
  }

  public List<String> getInLinkedDocsForDoc(String docName) {
    return inLinks.get(docName);

  }

  public Double getRankForDoc(String docName) {
    return pageRanks.get(docName);
  }
}
