package edu.nyu.cs.cs2580;

import edu.nyu.cs.cs2580.SearchEngine.Options;
import edu.nyu.cs.cs2580.html.HTMLPageParser;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;

/**
 * @CS2580: Implement this class for HW3.
 */
public class LogMinerNumviews extends LogMiner {

  HashSet<String> corpusDocs = new HashSet<String>();
  public HashMap<String, Integer> fileNumviewMap = new HashMap<String, Integer>();

  public LogMinerNumviews(Options options) {
    super(options);
  }

  /**
   * This function processes the logs within the log directory as specified by
   * the _options. The logs are obtained from Wikipedia dumps and have
   * the following format per line: [language]<space>[article]<space>[#views].
   * Those view information are to be extracted for documents in our corpus and
   * stored somewhere to be used during indexing.
   * <p/>
   * Note that the log contains view information for all articles in Wikipedia
   * and it is necessary to locate the information about articles within our
   * corpus.
   *
   * @throws IOException
   */
  @Override
  public void compute() throws IOException {
    System.out.println("Computing using " + this.getClass().getName());
    String logDirPath = _options._logPrefix;
    File logDir = new File(logDirPath);

    System.out.println("Checking corpus");
    initNumViewMap();
    System.out.println("Processing logs in " + logDir.getAbsolutePath());
    for (File logFile : logDir.listFiles()) {
      processLogFile(logFile);
    }
    persistNumviewData();
    return;
  }

  private void persistNumviewData() throws IOException {
    String filePath = defaultNumViewPath();

    System.out.println("Persisting numview data to " + filePath);
    FileOutputStream fileOut =
            new FileOutputStream(filePath);
    ObjectOutputStream out =
            new ObjectOutputStream(fileOut);
    out.writeObject(fileNumviewMap);
    out.close();
    //To change body of created methods use File | Settings | File Templates.
  }

  private String defaultNumViewPath() {
    return _options._indexPrefix + "/corpus_numview.idx";
  }

  private void initNumViewMap() {
    for (File file : new File(_options._corpusPrefix).listFiles()) {
      fileNumviewMap.put(file.getName(), 0);
    }
    System.out.println("total " + fileNumviewMap.size() + " docs");
  }

  private void processLogFile(File logFile) throws IOException {

    BufferedReader bufferedreader = new BufferedReader(new FileReader(logFile));
    String line;

    while ((line = bufferedreader.readLine()) != null) {
      try {
        String[] fields = line.split(" ");
        String name = fields[1];
        Integer num = Integer.valueOf(fields[2]);

        if (!fileNumviewMap.containsKey(name))
          continue;//current log path can not be found in corpus

        fileNumviewMap.put(name, fileNumviewMap.get(name) + num);
      }
      catch (Exception e){
    	  System.out.print("Invalid Log Format, Cannot Parse: ");
    	  System.out.println(line);
    	  
      }
    }
    bufferedreader.close();
  }

  /**
   * During indexing mode, this function loads the NumViews values computed
   * during mining mode to be used by the indexer.
   *
   * @throws IOException
   */
  @Override
  public Object load() throws IOException {
    String filePath = defaultNumViewPath();

    System.out.println("Loading using " + this.getClass().getName());
    return loadFromPath(filePath);
  }

  public Object loadFromPath(String filePath) throws IOException {
    System.out.println("Loading numview data from " + filePath);

    FileInputStream fileIn =
            new FileInputStream(filePath);
    ObjectInputStream in = new ObjectInputStream(fileIn);
    try {
      HashMap<String, Integer> r = (HashMap<String, Integer>) in.readObject();
      return r;
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } finally {
      in.close();
      fileIn.close();
    }
    return null;
  }
}
