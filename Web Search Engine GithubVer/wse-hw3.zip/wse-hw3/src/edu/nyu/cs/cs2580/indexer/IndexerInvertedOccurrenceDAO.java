package edu.nyu.cs.cs2580.indexer;

import edu.nyu.cs.cs2580.*;
import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.html.HTMLPageParser;
import edu.nyu.cs.cs2580.indexer.ds.DocPosting;
import edu.nyu.cs.cs2580.indexer.ds.InvertIndexInDisk;
import edu.nyu.cs.cs2580.indexer.ds.PostingList;
import edu.nyu.cs.cs2580.io.DocumentInfoDAO;
import edu.nyu.cs.cs2580.io.IndexIO;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/5/13
 * Time: 6:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class IndexerInvertedOccurrenceDAO {

  private DocumentsCollection _documents = new DocumentsCollectionInMemory();
  private Integer _numDocs=0;
  public HashMap<String, PostingList> invertOccurenceIndexForWrite = new HashMap<String, PostingList>();
  protected CodeType codeType=CodeType.None;


  protected SearchEngine.Options _options;
  int DOC_COUNT_EACH_ROUND = 1000;

  protected long _totalTermFrequency = 0;

  public IndexerInvertedOccurrenceDAO(SearchEngine.Options options,CodeType codeType) {
    this._options=options;
    this.codeType=codeType;
  }

  public void processDocument(File file, DocumentInfoDAO docInfoWriter) {
    // parse HTML
    HTMLPageParser parser;
    try {
      parser = new HTMLPageParser(file);
      if (parser.getRawTitleContent().equals("")) {
        //System.out.println("Empty title, skipping " + file.getAbsolutePath());
        return;
      }
      List<String> titleWords = parser.getStemmedTitleWordsVector();
      List<String> bodyWords = parser.getStemmedBodyWordsVector();

      Document doc = new Document(_documents.size());
      String url = parser.getURL();

      doc.setTitle(parser.getRawTitleContent());
      doc.setUrl(url);

      _documents.add(doc);
      int docId = _documents.size() - 1;
      ++_numDocs;

      List<String> allWords = new ArrayList<String>();
      allWords.addAll(titleWords);
      allWords.addAll(bodyWords);
      _totalTermFrequency += allWords.size();

      docInfoWriter.writeDocInfo(docId, parser.getRawTitleContent(), url, allWords);

      // append document to correspoding posting lists
      addToInvertIndexForDocument(allWords, docId);
    } catch (IOException e) {
      System.err.println("Can not parse file!!! " + file.getAbsolutePath());
      e.printStackTrace(); // To change body of catch statement use File |
      // Settings | File Templates.
    }
  }

  //append to posting list accordinly
  private void addToInvertIndexForDocument(List<String> allWords, Integer docId) {
    for (int i = 0; i < allWords.size(); i++) {
      String term = allWords.get(i);
      // addDocToPostingList(word,docId);
      if (!invertOccurenceIndexForWrite.containsKey(term))
        invertOccurenceIndexForWrite.put(term, new PostingList());

      PostingList postingList = invertOccurenceIndexForWrite.get(term);

      if (!postingList.hasPostingForDoc(docId))
        postingList.addPosting(new DocPosting(docId));

      postingList.getPostingByDocId(docId).addOccurrence(i);
    }
  }
  public void constructIndexFromCorpus() throws IOException {
    String corpusPrefix = _options._corpusPrefix;

    System.out.println("corpusPrefix is" + corpusPrefix);
    System.out.println("Indexing documents ...");

    String docInfoFile = _options._indexPrefix + "/docinfo.idx"; // for storing title, url
    DocumentInfoDAO documentInfoDAO = new DocumentInfoDAO(docInfoFile);

    File corpusDir = new File(corpusPrefix);
    int remainingDocCount = DOC_COUNT_EACH_ROUND;
    int round = 1;

    for (File corpusFile : corpusDir.listFiles()) {

//      System.out.println("Constructing index from: " + corpusFile.getAbsolutePath());

      processDocument(corpusFile, documentInfoDAO);
      remainingDocCount--;
      if (remainingDocCount == 0) {
        persistIndexForCurrentBatch(round);
        this.invertOccurenceIndexForWrite.clear();
        remainingDocCount = DOC_COUNT_EACH_ROUND;
        round++;
        System.out.println("Indexing more documents ...");
      }

    }
    persistIndexForCurrentBatch(round);
    documentInfoDAO.close();

    IndexIO.writeFileNumber(_options._indexPrefix + "/FileCount", round);
    System.out.println("Mearging");
    IndexIO.Merge(_options._indexPrefix, round, codeType);
  }

  private void persistIndexForCurrentBatch(int round) throws IOException {
    System.out.println("Indexed " + Integer.toString(_numDocs) + " docs with "
            + Long.toString(_totalTermFrequency) + " terms.");

    String indexFile = _options._indexPrefix + "/index.idx" + round;
    String offsetFile = _options._indexPrefix + "/offset.idx" + round;

    FileOutputStream offsetOutput = new FileOutputStream(offsetFile);
    FileOutputStream indexOuput = new FileOutputStream(indexFile);

    System.out.println("Store index to: " + indexFile + " and: " + offsetFile);
    IndexIO.writeIndex(this.invertOccurenceIndexForWrite, offsetOutput, indexOuput, codeType);
    offsetOutput.close();
    indexOuput.close();
    System.out.println("File Ready for Use");
  }


  public void loadIndex(IndexerInvertedOccurrence returnedIndexer) throws IOException {

    String docInfoFile = _options._indexPrefix + "/docinfo.idx";


    //load Documents
    DocumentInfoDAO documentInfoDAO = new DocumentInfoDAO(docInfoFile);
    returnedIndexer._documents = documentInfoDAO.readAllDocuments();
    for (Document doc : returnedIndexer._documents) {
      returnedIndexer._totalTermFrequency += doc.getWordCount();
    }
    returnedIndexer._numDocs = returnedIndexer._documents.size();

    //load Index

    //int fileCount = IndexIO.readFileNumber(_options._indexPrefix + "/FileCount");
    returnedIndexer.invertOccurenceIndex = new InvertIndexInDisk(_options._indexPrefix, codeType);

    System.out.println(Integer.toString(returnedIndexer._numDocs) + " documents loaded " + "with "
            + Long.toString(returnedIndexer._totalTermFrequency) + " terms!");
  }
}
