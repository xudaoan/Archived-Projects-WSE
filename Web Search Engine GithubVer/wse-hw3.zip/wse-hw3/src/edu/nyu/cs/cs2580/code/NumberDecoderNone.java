package edu.nyu.cs.cs2580.code;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class NumberDecoderNone extends NumberDecoder {
    
    private Scanner scanner;
    private InputStream stream;
    public NumberDecoderNone(InputStream input){
        stream=input;
        scanner = new Scanner(input);

    }

    @Override
    public int next() throws IOException {

        return scanner.nextInt();
    }

}
