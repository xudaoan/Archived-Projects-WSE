package edu.nyu.cs.cs2580.code;

import java.io.IOException;
import java.io.OutputStream;

public abstract class NumberEncoder {
    public abstract void put(int value) throws IOException;

    public abstract void closeStream() throws IOException;

    public abstract void flush() throws IOException;

  /**
   * Create NumberEncoder based on the output codeType
   *
   * @param output
   *            The OutputStream to be output To
   * @param codeType
   *            Coding function chosen
   * @return
   */
  public static NumberEncoder getEncoderByType(OutputStream output, CodeType codeType) {
    switch (codeType) {
      case ByteAligned:
        return new NumberEncoderByteAligned(output);
      case ByteAlignedBuffered:
        return new NumberEncoderByteAlignedBuffered(output);
      case EliasDelta:
        return new NumberEncoderEliasDelta(output);
      case EliasGamma:
        return new NumberEncoderEliasGamma(output);
      case None:
        return new NumberEncoderNoneBuffered(output);
    }
    return null;
  }
}
