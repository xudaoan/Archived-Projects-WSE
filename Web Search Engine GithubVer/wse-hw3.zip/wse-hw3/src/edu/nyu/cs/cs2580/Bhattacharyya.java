package edu.nyu.cs.cs2580;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Bhattacharyya {

	class Query {
		String query;
		Map<String, Double> expandedQuery;
	}

	private ArrayList<Query> queries;

	public Bhattacharyya() {
		this.queries = new ArrayList<Query>();
	}

	public double querySimilarity(Map<String, Double> q1, Map<String, Double> q2) {
		Set<String> terms = new HashSet<String>();
		terms.addAll(q1.keySet());
		terms.addAll(q2.keySet());

		double result = 0.0;
		for (String term : terms) {
			double p1 = q1.containsKey(term) ? q1.get(term) : 0;
			double p2 = q2.containsKey(term) ? q2.get(term) : 0;
			result = result + Math.sqrt(p1 * p2);
		}
		return result;
	}

	public String querySimilarity() {
		int qSize = queries.size();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < qSize; i++) {
			// for (int j = i + 1; j < qSize; j++) {
			for (int j = 0; j < qSize; j++) {
				if (j == i)
					continue;
				Query q1 = queries.get(i);
				Query q2 = queries.get(j);
				sb.append(q1.query);
				sb.append("\t");
				sb.append(q2.query);
				sb.append("\t");
				sb.append(querySimilarity(q1.expandedQuery, q2.expandedQuery));
				sb.append("\n");
			}
		}
		return sb.toString();
	}

	public void intiQueirs(List<String> files, List<String> queries)
			throws FileNotFoundException {
		int size = files.size();
		for (int i = 0; i < size; i++) {
			Query query = new Query();
			query.query = queries.get(i);
			query.expandedQuery = new HashMap<String, Double>();

			Scanner scanner = new Scanner(new File(files.get(i)));
			while (scanner.hasNext()) {
				String term = scanner.next();
				;
				double percentage = scanner.nextDouble();
				query.expandedQuery.put(term, percentage);
			}
			scanner.close();

			this.queries.add(query);
		}
	}

	public static void main(String[] args) throws IOException {
		String inFile;
		String outFile;

		if (args.length != 2) {
			System.out.println("Error: Incorrect argument number");
			System.exit(1);
		}

		inFile = args[0];
		outFile = args[1];

		Scanner scanner = new Scanner(new File(inFile));
		scanner.useDelimiter("\n");

		List<String> queries = new ArrayList<String>();
		List<String> files = new ArrayList<String>();
		while (scanner.hasNext()) {
			String line = scanner.next();
			String[] lineSplit = line.split(":");
			queries.add(lineSplit[0]);
			files.add(lineSplit[1]);
		}

		Bhattacharyya it = new Bhattacharyya();
		it.intiQueirs(files, queries);
		FileOutputStream output = new FileOutputStream(outFile);
		String outString = it.querySimilarity();
		output.write(outString.getBytes());
		output.close();

	}

}
