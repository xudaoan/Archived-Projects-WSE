package edu.nyu.cs.cs2580.io;

import java.io.IOException;
import java.io.OutputStream;

public class BitOutputStream {

    private OutputStream output;
    private int currentByte = 0;
    private int shiftCount = 0;

    public BitOutputStream(OutputStream output) {
        this.output = output;
        this.currentByte = 0;
        this.shiftCount = 0;
    }

    /**
     * 
     * @param bit
     *            0 or not zero, treated as 1 if it is not zero
     * @throws IOException
     */
    public void writeBit(int bit) throws IOException {
        shiftCount++;
        currentByte = (currentByte << 1) + (bit == 0 ? 0 : 1);
        if (shiftCount > 7) {
            writeByte(currentByte);
            shiftCount = 0;
            currentByte = 0;
        }
    }

    public void writeByte(int theByte) throws IOException {
        output.write(theByte);
    }

    public void flush() throws IOException {
        output.flush();
    }

    public void close() throws IOException {
        if (shiftCount > 0) {
            //writeByte(currentByte << (8 - shiftCount));
            for(int i = 0; i < 8-shiftCount ; i++){
                currentByte = (currentByte<< 1) + 1;
            }
            writeByte(currentByte);
        }
        output.close();
    }
}
