package edu.nyu.cs.cs2580;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/9/13
 * Time: 4:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class Spearman {

  public static void main(String[] args) throws Exception{
//    String rankFilePath="data/index/corpus_pageRank.idx";
    String rankFilePath=args[0];
    String numviewsFilePath=args[1];
//    String numviewsFilePath="data/index/corpus_numview";

    CorpusAnalyzerPagerank pageRankAnalyzer = new CorpusAnalyzerPagerank(new SearchEngine.Options("conf/engine.conf"));
    pageRankAnalyzer.setLambda(1.0);
    Map<String,Double> sortedRankMap=  sorted((HashMap<String, Double>) pageRankAnalyzer.loadFromPath(rankFilePath));

    HashMap<String, Integer> numviewMap = (HashMap<String, Integer>) new LogMinerNumviews(new SearchEngine.Options("conf/engine.conf")).loadFromPath(numviewsFilePath);
    //numview should have all docs in corpus
    for(String docName:sortedRankMap.keySet()){
      if (!numviewMap.containsKey(docName))
        numviewMap.put(docName,0);
    }

    Map<String,Integer> sortedNumviewMap= sorted(numviewMap);

    HashMap<String,Integer> rankPositionMap=new HashMap<String, Integer>();
    HashMap<String,Integer> numviewPositionMap=new HashMap<String, Integer>();

    for(Map.Entry<String,Double> entry:sortedRankMap.entrySet()){
      System.out.println(entry.getKey()+"|"+entry.getValue());
    }

    for(Map.Entry<String,Integer> entry:sortedNumviewMap.entrySet()){
      System.out.println(entry.getKey()+"|"+entry.getValue());
    }

    int pos=0;
    for(String docName: sortedRankMap.keySet()){
        rankPositionMap.put(docName, pos++);
    }


    pos=0;
    for(String docName: sortedNumviewMap.keySet()){
      numviewPositionMap.put(docName, pos++);
    }
//
    // most significant result has the biggest rank
//    System.out.println(rankPositionMap.get("Liverpool_F.C._2005–06_UEFA_Champions_League_qualification"));

    double result=0.0;
    for(String docName: rankPositionMap.keySet()){
        int posInPageRank=rankPositionMap.get(docName);
        int posInNumview=numviewPositionMap.containsKey(docName)?numviewPositionMap.get(docName):0;
      System.out.println(docName+" | "+posInPageRank+" | "+posInNumview);
         result+=   6.0*Math.pow(posInPageRank-posInNumview,2.0);
    }
    double n= rankPositionMap.size();
    result=1-result/(n*(Math.pow(n,2)-1));
    System.out.println("result:"+result);




  }

  private static Map sorted(Map unsortMap) {

    List list = new LinkedList(unsortMap.entrySet());

    // sort list based on comparator
    // sort by value first and then sort by key
    Collections.sort(list, new Comparator() {
      public int compare(Object o1, Object o2) {

        if(((Comparable) ((Map.Entry) (o1)).getValue())
                .compareTo(((Map.Entry) (o2)).getValue())==0){
          return ((Comparable) ((Map.Entry) (o1)).getKey())
                  .compareTo(((Map.Entry) (o2)).getKey());
        }

        //decreasing order
        return ((Comparable) ((Map.Entry) (o2)).getValue())
                .compareTo(((Map.Entry) (o1)).getValue());
      }
    });

    //put sorted list into map again
    //LinkedHashMap make sure order in which keys were inserted
    Map sortedMap = new LinkedHashMap();
    for (Iterator it = list.iterator(); it.hasNext();) {
      Map.Entry entry = (Map.Entry) it.next();
      sortedMap.put(entry.getKey(), entry.getValue());
    }
    return sortedMap;
  }
}
