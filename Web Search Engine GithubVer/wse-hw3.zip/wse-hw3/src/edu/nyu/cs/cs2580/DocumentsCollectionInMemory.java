package edu.nyu.cs.cs2580;

import java.util.Iterator;
import java.util.Vector;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/5/13
 * Time: 6:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentsCollectionInMemory implements DocumentsCollection {
  Vector<Document> docs=new Vector<Document>();

  @Override
  public int size() {
    return docs.size();  //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public void add(Document doc) {
    docs.add(doc);
    //To change body of implemented methods use File | Settings | File Templates.
  }

  //TODO: docid may not be index
  @Override
  public Document getByDocId(int docid) {
    return docs.get(docid);  //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public Iterator<Document> iterator() {
    return docs.iterator();  //To change body of implemented methods use File | Settings | File Templates.
  }
}
