package edu.nyu.cs.cs2580.indexer.ds;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

import edu.nyu.cs.cs2580.code.*;

/**
 * InverIndex which is stored in files, use random access to access a postingList
 */
public class InvertIndexInDisk implements InvertIndex {
    FileInputStream indexStream;
    TermOffsetTable termOffsetTable;
    Map<String, PostingList> cache;
    CodeType codeType;

    IndexFileDecoder indexFileDecoder;
    public InvertIndexInDisk(String indexPrefix, CodeType codeType)
            throws FileNotFoundException {
        this.cache = new HashMap<String, PostingList>();
        this.codeType = codeType;
        String fileOffset = indexPrefix + "/offset.idx";
        String fileIndex = indexPrefix + "/index.idx";
        System.out.println("Load index from: " + fileOffset + "," + fileIndex);
        indexStream = new FileInputStream(fileIndex);
        FileInputStream offsetStream = new FileInputStream(fileOffset);
        termOffsetTable = TermOffsetTable.load(offsetStream);
        indexFileDecoder =new IndexFileDecoder(codeType,indexStream);
    }

    @Override
    public PostingList get(String term) {
        if (this.cache.containsKey(term))
            return this.cache.get(term);

        PostingList result = null;
        if (termOffsetTable.containsKey(term)) {
            try {
                result = indexFileDecoder.readPostingListByTerm(term, termOffsetTable);
                cache.put(term, result);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return result;
    }












  @Override
    public boolean containsKey(String term) {
        return this.termOffsetTable.containsKey(term);
    }
}
