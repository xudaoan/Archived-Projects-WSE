package edu.nyu.cs.cs2580.indexer;

import edu.nyu.cs.cs2580.SearchEngine.Options;
import edu.nyu.cs.cs2580.code.CodeType;


public class IndexerInvertedCompressed extends IndexerInvertedOccurrence {

  public IndexerInvertedCompressed(Options options) {
    super(options);
    codeType = CodeType.ByteAlignedBuffered;
  }
}