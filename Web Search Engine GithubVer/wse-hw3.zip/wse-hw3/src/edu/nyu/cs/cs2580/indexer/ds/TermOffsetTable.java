package edu.nyu.cs.cs2580.indexer.ds;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/5/13
 * Time: 6:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class TermOffsetTable {
  /**
   * Read the termOffset file and get the term-offset map
   *
   * @param input
   * @return
   */

  Map<String, Integer> offsets = new HashMap<String, Integer>();

  public static TermOffsetTable load(InputStream input) {

    Scanner scanner = new Scanner(input);
    TermOffsetTable table=new TermOffsetTable();
    while (scanner.hasNextLine()) {
      String line = scanner.nextLine();
      String[] words = line.split("\\s+");
      table.offsets.put(words[0], Integer.parseInt(words[1]));
    }
    scanner.close();
    return table;
  }

  public boolean containsKey(String term) {
    return offsets.containsKey(term);  //To change body of created methods use File | Settings | File Templates.
  }

  public Integer get(String term) {
    return offsets.get(term);
  }
}
