package edu.nyu.cs.cs2580;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import edu.nyu.cs.cs2580.html.WordStemmer;

public class StopwordsChecker {
    
    public static Set<String> words;
    private static WordStemmer stemmer = new WordStemmer();
    
    static {
        String FILENAME = "stopwords.tsv";
        words = new HashSet<String>();
        try {
            Scanner scanner = new Scanner(new File(FILENAME));
            while(scanner.hasNext()){
                words.add(stemmer.stem(scanner.next()));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    public static void put(String s){
        words.add(stemmer.stem(s));
    }
    
    public static boolean isStopword(String s){
        return words.contains(stemmer.stem(s));
    }

}
