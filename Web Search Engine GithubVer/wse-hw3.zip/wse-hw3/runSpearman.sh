java -Xmx512m -cp jars/jsoup-1.7.2.jar:src edu.nyu.cs.cs2580.Spearman data/index/corpus_pageRank.idx data/index/corpus_numview.idx
./fix_permission.sh
