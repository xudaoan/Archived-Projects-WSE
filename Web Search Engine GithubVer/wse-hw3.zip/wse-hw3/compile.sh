./clean.sh
javac -cp jars/jsoup-1.7.2.jar:src src/edu/nyu/cs/cs2580/*.java
./fix_permission.sh
