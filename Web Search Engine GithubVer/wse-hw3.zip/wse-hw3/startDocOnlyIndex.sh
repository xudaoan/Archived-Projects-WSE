java -Xmx512m -cp jars/jsoup-1.7.2.jar:src edu.nyu.cs.cs2580.SearchEngine --mode=index --port=25811 --options=conf/docOnlyEngine.conf
./fix_permission.sh
