HW3 From Group11

Compile
=======
./clean.sh
./compile.sh
Run Programm
============
./startMining.sh
./startIndex.sh
./startServer.sh

Open http://localhost:25811/home

Answer To Q2: Computing Document Qualities
==========================================

Run Program
-----------
./startMining.sh generates `$INDEX_PREFIX/corpus_numview.idx` and `$INDEX_PREVIX/corpus_pageRank.idx` each stores numviews information and pagerank score for each document
./startIndex.sh will startIndexing, and it will load Index from the two files metioned above for loading pagerank and numviews information
DocumentIndoDAO.writeDocInfo fetches the pagerank and numviews for each document

./startServer.sh will start the server. Visit http://localhost:25811/home will show you a webpage where you can type in key words:
*Notice* we made the /home page for grader to easyily type in the keywords
- Single Word Query
	Amazon
	
- Multi-words conjunctive query:
	New York City

- Phrase Query
	"New York City"

- Phrase and words mixed query
	"to be or not to be" Prime

PageRank Parameters Setting
---------------------------
We use a heuristic approach to optimize PageRank Parameters: The documents has a higher PageRank should a have a bigger number of views.
Therefore we use *Spearman Score* as a indicator of the performance

    tail Q2/spearman0.1_1.log shows score when lambda=0.1, iterations=1;
    tail Q2/spearman0.1_2.log shows score when lambda=0.1, iterations=2;
    tail Q2/spearman0.9_1.log shows score when lambda=0.9, iterations=1;
    tail Q2/spearman0.9_2.log shows score when lambda=0.9, iterations=2;
	
For best result, we choose lambda=0.9, iterations=2;

Check Results with NumViews and PageRank
---------------------------------
The result Looks like:
418Alexa Internet - Wikipedia, the free encyclopedia0.09353158436138373|167|5.0114753E-4
418 is the DocId, 0.09353.. is the Comprehensive Score, 167 is the num of views, 5.0113753E-4 is the pageRank

Comprehensive Score is calulated use a linear combination of query likelihood, number of views and PageRank.

Answer To Q3: Comparing PageRank and Number 
===========================================

./runSpearman.sh will output documents each order by PageRank and Number of Views. Last line of the output shows the Spearman score: 0.4498960149995843

A copy of the result is located in folder Q3/

Answer To Q4: Pseudo-Relevance Feedback
=======================================

Before running the scripts, BE SURE to cd in to Q4 folder, by running cd Q4
And BE SURE that the file queries.tsv have been put into the Q4 folder.

There are 4 scripts you can choose to run for this question
    
    The first one is likely the one you want to execute.
    ./Q4_Comprehensive_10_5.sh    # This one use comprehensive ranker, prf using first 10 documents and top 5 terms
    ./Q4_Comprehensive_20_10.sh   # This one use comprehensive ranker, prf using first 20 documents and top 10 terms
    ./Q4_Favorite_20_10.sh        # This one use comprehensive ranker, prf using first 20 documents and top 10 terms
    ./Q4_Favorite_10_5.sh         # This one use comprehensive ranker, prf using first 10 documents and top 5 terms

The output file will be generated as the document required.
Q4.1 will generates prf-*.tsv and prf.tsv
Q4.2 will generates qsim.tsv



