package edu.nyu.cs.cs2580;

import edu.nyu.cs.cs2580.html.HTMLPageParser;
import edu.nyu.cs.cs2580.html.WordStemmer;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 3/11/13
 * Time: 2:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class HTMLPageParserTest {
  HTMLPageParser p;
  @Before
  public void setUp() throws IOException {
    String url="data/wiki/Copyright";
    File f=new File(url);
    p=new HTMLPageParser(f);
  }

  @Test
  public void testReadRawContent(){

    String rawBodyContent = p.getRawBodyContent();
    System.out.println(p.getAllWords());

    assertTrue(rawBodyContent.contains("Copyright does not cover ideas and information themselves"));
    assertFalse(rawBodyContent.contains("Copyright - Wikipedia, the free encyclopedia"));
  }

  @Test
  public void testNoSingleChar() throws Exception{


    String url="data/wiki/Federated_States_of_Micronesia";
    File f=new File(url);
    p=new HTMLPageParser(f);
    System.out.println(p.getAllWords());
  }

  @Test
  public void testReadRawTitle() throws IOException{
   String rawTitle=p.getRawTitleContent();
    assertTrue(rawTitle.contains("Copyright - Wikipedia, the free encyclopedia"));
  }

  @Test
  public void testReadWordsFromBody(){
    List<String> words= p.getStemmedBodyWordsVector();
    System.out.println(words);
    assertEquals(4,numOfOccurence(words, WordStemmer.stem("criminal")));
    assertEquals(12,numOfOccurence(words, WordStemmer.stem("enforcement")));
    assertEquals(6,numOfOccurence(words, WordStemmer.stem("history")));
  }

  @Test
  public void testReadWordsFromTitle(){
    List<String> words= p.getStemmedTitleWordsVector();
    System.out.println(words);
    assertEquals(0,numOfOccurence(words,"criminal"));
    assertEquals(0,numOfOccurence(words,"enforcement"));
    assertEquals(0,numOfOccurence(words,"history"));
    assertEquals(1,numOfOccurence(words,"copyright"));
    assertEquals(1,numOfOccurence(words,"wikipedia"));
    assertEquals(1,numOfOccurence(words,"the"));
    assertEquals(1,numOfOccurence(words,"free"));
    assertEquals(1,numOfOccurence(words,"encyclopedia"));
  }

  @Test
  public void testGetNormalizedNameFromUrl() throws UnsupportedEncodingException {
    assertEquals("\"Awesome\"",HTMLPageParser.getNormalizedNameFromUrl("%22Awesome%22"));
    assertEquals("\"Awesome\"",HTMLPageParser.getNormalizedNameFromUrl("%22Awesome%22"));
    assertEquals("I_Am..._World_Tour_(album)",HTMLPageParser.getNormalizedNameFromUrl("I_Am..._World_Tour_(album).html"));
    assertEquals("...Very_'Eavy_...Very_'Umble",HTMLPageParser.getNormalizedNameFromUrl("...Very_%27Eavy_...Very_%27Umble"));
    assertEquals("International_Standard_Book_Number",HTMLPageParser.getNormalizedNameFromUrl("Aldgate_East//wiki/International_Standard_Book_Number"));
  }

  @Test
  public void testGetURL(){
    assertEquals("http://en.wikipedia.org/wiki/Copyright",p.getURL());
  }

  private int numOfOccurence(List<String> data, String searchWord){
    int i=0;
    for(String word:data){
      if (word.equals(searchWord))
        i++;
    }
    return i;
  }
}
