package edu.nyu.cs.cs2580.code;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.junit.Test;

public class EliasGamma {

    @Test
    public void test() {
        String FileLocation = "ByteAlligned.txt";
        int [] arr = new int[]{1,2,3,4,5,11,22,33,44,55,66,77,88};

        FileOutputStream pOUTPUT;
        FileInputStream pINPUT;

        try {
            pOUTPUT = new FileOutputStream(FileLocation);
            NumberEncoder ec = new NumberEncoderEliasGamma(pOUTPUT);
            for(int i = 0 ; i < arr.length ; i++){
                ec.put(arr[i]);
            }            
            ec.closeStream();
            
            pINPUT = new FileInputStream(FileLocation);
            NumberDecoder dc = new NumberDecoderEliasGamma(pINPUT);
            int it = dc.next();
            while(it != -1){
                System.out.print(it + " ");
                it =  dc.next();
            }
            pINPUT.close();  
            
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }
    }

}
