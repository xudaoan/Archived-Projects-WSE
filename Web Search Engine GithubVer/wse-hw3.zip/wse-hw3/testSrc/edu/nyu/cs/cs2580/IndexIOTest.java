package edu.nyu.cs.cs2580;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import edu.nyu.cs.cs2580.indexer.IndexerInvertedOccurrenceDAO;
import edu.nyu.cs.cs2580.indexer.ds.IndexFileDecoder;
import edu.nyu.cs.cs2580.indexer.ds.PostingListDecoder;
import edu.nyu.cs.cs2580.indexer.ds.TermOffsetTable;
import org.junit.Assert;
import org.junit.Test;

import edu.nyu.cs.cs2580.code.CodeType;
import edu.nyu.cs.cs2580.indexer.ds.PostingList;
import edu.nyu.cs.cs2580.io.IndexIO;


public class IndexIOTest {
    
    @Test
    public void test() throws IOException{
        IndexerInvertedOccurrenceDAO old=new IndexerInvertedOccurrenceDAO(new SearchEngine.Options("conf/engine.conf"),CodeType.None);
        old.constructIndexFromCorpus();
        FileOutputStream offsetOutput;
        FileOutputStream indexOuput;
        String FileLocation1 = "offset.out";
        String FileLocation2 = "index.out";
        offsetOutput = new FileOutputStream(FileLocation1);
        indexOuput = new FileOutputStream(FileLocation2);
        offsetOutput.getChannel().position(0);
        indexOuput.getChannel().position(0);
        

        System.out.println("Writing Index into File");
        
        IndexIO.writeIndex(old.invertOccurenceIndexForWrite, offsetOutput, indexOuput, CodeType.None);
        offsetOutput.close();
        indexOuput.close();

        FileInputStream offsetInput;
        FileInputStream indexInput;
        offsetInput = new FileInputStream(FileLocation1);
        indexInput = new FileInputStream(FileLocation2);
        
        TermOffsetTable termOffsetTable = TermOffsetTable.load(offsetInput);
        
        System.out.println("Validation Starts");
        
        boolean correct = true;
        for(Map.Entry<String, PostingList> entry : old.invertOccurenceIndexForWrite.entrySet()){
            String term = entry.getKey();
          IndexFileDecoder d=new IndexFileDecoder(CodeType.None,indexInput);
          PostingList postlist = d.readPostingListByTerm(term,termOffsetTable);
            if(postlist.toString().equals(entry.getValue().toString())){
//                System.out.println("Yeah!");
//                System.out.println(entry.getKey());
//                System.out.println(entry.getValue());
//                System.out.println(postlist);
//                System.out.println("++++++++++++++++++++");
                continue;
            }
            correct = false;
            System.out.println(">>>>>>>>>>>>>>FAIL<<<<<<<<<<<<<<");
            System.out.println(entry.getKey());
            System.out.println(entry.getValue());
            System.out.println(postlist);
            break;
        }
        
        Assert.assertTrue(correct);
    }
    
//    @Test
//    public void presidentTest() throws IOException{
//        String term = "president";
//        int offset = 3894320;
//
//        String FileLocation2 = "index.out";
//        FileInputStream indexInput;
//        indexInput = new FileInputStream(FileLocation2);
//        indexInput.getChannel().position(offset);
//        NumberDecoder decoder = new NumberDecoderByteAligned(indexInput);
//        for(int i= 0 ; i< 10;i++){
//            System.out.print(decoder.next() + " ");
//        }
//    }

}
