package edu.nyu.cs.cs2580;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/9/13
 * Time: 12:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class CorpusAnalyzerPagerankTest {
  SearchEngine.Options options;
  @Before
  public void setUp() throws Exception {
   options= new SearchEngine.Options("fixture/engine.conf");

  }

  @Test
  public void tmp(){
    ArrayList<Integer> arr=new ArrayList(Collections.nCopies(5, null));
    arr.set(3,3);
  }
  @Test
  public void testLoadDocIdMap() throws Exception {
     CorpusAnalyzerPagerank pagerankAnalyzer=new CorpusAnalyzerPagerank(options);
     pagerankAnalyzer.prepare();
     Assert.assertEquals(2, pagerankAnalyzer.numberOfDocs());
//     Assert.assertEquals(pagerankAnalyzer.getDocId("Copyright"),0);
//     Assert.assertEquals(pagerankAnalyzer.getDocId("Web_browser"),1);

    // only page in corpus counts
    Assert.assertEquals(0, pagerankAnalyzer.getOuterLinkCountForDoc("Copyright"));
    Assert.assertEquals(1, pagerankAnalyzer.getOuterLinkCountForDoc("Web_browser"));

    Assert.assertEquals("[Web_browser]",pagerankAnalyzer.getInLinkedDocsForDoc("Copyright").toString());
    Assert.assertEquals("[]", pagerankAnalyzer.getInLinkedDocsForDoc("Web_browser").toString());
  }

  @Test
  public void testRankCompute() throws Exception{
    CorpusAnalyzerPagerank pagerankAnalyzer=new CorpusAnalyzerPagerank(options);
    pagerankAnalyzer.setLambda(0.1);
    pagerankAnalyzer.prepare();
    pagerankAnalyzer.compute();
    System.out.println(pagerankAnalyzer.getRankForDoc("Copyright"));
    System.out.println(pagerankAnalyzer.getRankForDoc("Web_browser"));
  }

  @Test
  public void testPersistAndLoad() throws Exception{
    CorpusAnalyzerPagerank pagerankAnalyzer=new CorpusAnalyzerPagerank(options);
    pagerankAnalyzer.prepare();
    pagerankAnalyzer.compute();

    System.out.println(pagerankAnalyzer.getRankForDoc("Copyright"));
    System.out.println(pagerankAnalyzer.getRankForDoc("Web_browser"));

    HashMap<String, Double> loadedRanks= (HashMap<String,Double>) new CorpusAnalyzerPagerank(options).load();
    System.out.println(loadedRanks);


  }


  @Test
  public void testWikiPageRank() throws IOException {
    SearchEngine.Options o= new SearchEngine.Options("conf/engine.conf");

    CorpusAnalyzerPagerank pagerankAnalyzer=new CorpusAnalyzerPagerank(o);
//    pagerankAnalyzer.setLambda(0.9);
//    pagerankAnalyzer.setIterations(2);
    pagerankAnalyzer.prepare();
    pagerankAnalyzer.compute();

    System.out.println("loading");


    HashMap<String, Double> loadedRanks= (HashMap<String,Double>) new CorpusAnalyzerPagerank(o).load();
    Map<String, String> sortedMap = sortByComparator(loadedRanks);
    System.out.println(sortedMap);



  }

  private static Map sortByComparator(Map unsortMap) {

    List list = new LinkedList(unsortMap.entrySet());

    // sort list based on comparator
    Collections.sort(list, new Comparator() {
      public int compare(Object o1, Object o2) {
        return ((Comparable) ((Map.Entry) (o1)).getValue())
                .compareTo(((Map.Entry) (o2)).getValue());
      }
    });

    //put sorted list into map again
    //LinkedHashMap make sure order in which keys were inserted
    Map sortedMap = new LinkedHashMap();
    for (Iterator it = list.iterator(); it.hasNext();) {
      Map.Entry entry = (Map.Entry) it.next();
      sortedMap.put(entry.getKey(), entry.getValue());
    }
    return sortedMap;
  }

}
