package edu.nyu.cs.cs2580.io;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.junit.Test;

public class InputTest {

    @Test
    public void test() {
        String FileLocation = "ByteAlligned.txt";

        FileInputStream pINPUT;
        BitInputStream bt;

        try {
            pINPUT = new FileInputStream(FileLocation);
            bt = new BitInputStream(pINPUT);
            int it = bt.readBit();
            int count = 0;
            while(it != -1){
                System.out.print(it);
                it = bt.readBit();
                count ++;
                if(count == 8)
                {
                    System.out.println();
                    count = 0;
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }
    }

}
