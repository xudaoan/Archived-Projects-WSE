package edu.nyu.cs.cs2580;

import org.junit.Test;

import java.util.HashMap;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 4/9/13
 * Time: 3:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class LogMinerNumviewsTest {
  @Test
  public void testCompute() throws Exception {
     LogMinerNumviews minner= (LogMinerNumviews) LogMiner.Factory.getLogMinerByOption(new SearchEngine.Options("conf/engine.conf"));
    minner.compute();
    System.out.println(minner.fileNumviewMap);

  }

  @Test
  public void testPersistAndLoad() throws Exception{
    LogMinerNumviews minner= (LogMinerNumviews) LogMiner.Factory.getLogMinerByOption(new SearchEngine.Options("conf/engine.conf"));
    minner.compute();
    HashMap<String,Integer> numviewMap= (HashMap<String, Integer>) ((LogMinerNumviews) LogMiner.Factory.getLogMinerByOption(new SearchEngine.Options("conf/engine.conf"))).load();
    System.out.println(numviewMap);
  }
}
