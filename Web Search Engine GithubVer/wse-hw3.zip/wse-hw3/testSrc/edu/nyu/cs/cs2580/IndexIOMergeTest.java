package edu.nyu.cs.cs2580;

import java.io.IOException;

import edu.nyu.cs.cs2580.indexer.IndexerInvertedCompressed;
import org.junit.Test;

public class IndexIOMergeTest {

    @Test
    public void test() throws IOException {
        IndexerInvertedCompressed old=new IndexerInvertedCompressed(new SearchEngine.Options("conf/engine.conf"));
        old.constructIndex();
    }

}
