package edu.nyu.cs.cs2580.io;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import edu.nyu.cs.cs2580.code.CodeType;

public class MergeTest {

    @Test
    public void test() throws IOException {
        IndexIO.Merge("data/indexOccur", 6, CodeType.None);
//        IndexIO.Merge("data/indexCompress", 1, CodeType.ByteAlignedBuffered);
    }

}
