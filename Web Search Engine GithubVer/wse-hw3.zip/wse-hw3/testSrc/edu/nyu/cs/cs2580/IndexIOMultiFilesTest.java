//package edu.nyu.cs.cs2580;
//
//import static org.junit.Assert.*;
//
//import java.io.IOException;
//import java.util.Map;
//
//import org.junit.Assert;
//import org.junit.Test;
//
//import edu.nyu.cs.cs2580.index.ds.PostingList;
//import edu.nyu.cs.cs2580.io.IndexIO;
//
//public class IndexIOMultiFilesTest {
//
//    @Test
//    public void test() throws IOException, ClassNotFoundException {
//        CopyOfIndexerInvertedCompressedOld old=new CopyOfIndexerInvertedCompressedOld(new SearchEngine.Options("conf/engine.conf"));
//        old.constructIndex();
//
//        IndexerInvertedCompressed i = new IndexerInvertedCompressed(new SearchEngine.Options("conf/engine.conf"));
//        i.loadIndex();
//
//        boolean correct = true;
//        int count = 0;
//        for(Map.Entry<String, PostingList> entry : old.invertOccurenceIndexForWrite.entrySet()){
//            String term = entry.getKey();
//            i.getPostingList(term);
//            PostingList postlist = i.getPostingList(term);
//            if(postlist.toString().equals(entry.getValue().toString())){
//                System.out.println(count ++);
////              System.out.println("Yeah!");
////              System.out.println(entry.getKey());
////              System.out.println(entry.getValue());
////              System.out.println(postlist);
////              System.out.println("++++++++++++++++++++");
//                continue;
//            }
//            correct = false;
//            System.out.println(">>>>>>>>>>>>>>FAIL<<<<<<<<<<<<<<");
//            System.out.println(entry.getKey());
//            System.out.println(entry.getValue());
//            System.out.println(postlist);
//            break;
//        }
//
//        Assert.assertTrue(correct);
//    }
//
//}
