find . -name "*.class" -exec rm -rf {} \; 2>/dev/null
