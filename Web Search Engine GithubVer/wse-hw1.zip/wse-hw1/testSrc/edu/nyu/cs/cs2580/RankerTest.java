package edu.nyu.cs.cs2580;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: tsdeng
 * Date: 2/22/13
 * Time: 2:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class RankerTest {

    @Test
    public void testCosineRanker() throws Exception {
        Ranker r = new Ranker("data/corpus.tsv");
        r.setSignalType(Ranker.SignalType.COSINE);
        ScoredDocument d = r.runquery("google", 0);
        Assert.assertEquals(0.0, 0.0, 0.00001);

        d = r.runquery("google", 639);
        Assert.assertTrue(d.get_score() > 0.001);
    }

    @Test
    public void testQueryLikelyhoodRanker() {
        Ranker r = new Ranker("data/corpus.tsv");
        r.setSignalType(Ranker.SignalType.QUERYLIKELYHOOD);
        ScoredDocument documentWithoutGoogle = r.runquery("google", 0);
        ScoredDocument documentWithGoogle = r.runquery("google", 639);
        System.out.println(documentWithGoogle.get_score());
        ;
        System.out.println(documentWithoutGoogle.get_score());
        ;
        Assert.assertTrue(documentWithGoogle.get_score() > documentWithoutGoogle.get_score());
    }

    @Test
    public void testPhraseRanker() {
        Ranker r = new Ranker("data/corpus.tsv");
        r.setSignalType(Ranker.SignalType.PHRASE);
//        ScoredDocument documentWithoutGoogle=r.runquery("google", 0);
        ScoredDocument documentWithGoogle = r.runquery("google", 433);
        Assert.assertEquals(111, documentWithGoogle.get_score(), 0.0);
        Assert.assertEquals(1.0, r.runquery("google", 454).get_score(), 0.0);
        Assert.assertEquals(0.0, r.runquery("google", 400).get_score(), 0.0);

        Document d = new Document(1, "my test document\tbeautiful cat loves another beautiful cat\t0");
        Assert.assertEquals(2.0, r.generatePhraseScore("beautiful cat", d), 0.0);
        Assert.assertEquals(3.0, r.generatePhraseScore("another beautiful cat", d), 0.0);

        System.out.println(d.get_body_vector());
//        Assert.assertTrue(documentWithGoogle.get_score()>documentWithoutGoogle.get_score());

    }

    @Test
    public void testNumviewsRanker() {
        Ranker r = new Ranker("data/corpus.tsv");
        r.setSignalType(Ranker.SignalType.NUMVIEWS);
        Assert.assertEquals(201, r.runquery("google", 653).get_score(), 0.0);
        Assert.assertEquals(15, r.runquery("google", 654).get_score(), 0.0);
        Assert.assertEquals(0.0, r.runquery("google", 0).get_score(), 0.0);
    }

    @Test
    public void testLinearModel() {
        Ranker r = new Ranker("data/corpus.tsv");
        r.setSignalType(Ranker.SignalType.LINEAR);
        ScoredDocument documentWithoutGoogle = r.runquery("google", 0);
        ScoredDocument documentWithGoogle = r.runquery("google", 639);
        Assert.assertTrue(documentWithGoogle.get_score() > documentWithoutGoogle.get_score());

        //becomes NumViewsRanker
        r.setLinearWeight(0.0, 0.0, 0.0, 1.0);
        Assert.assertEquals(201, r.runquery("google", 653).get_score(), 0.0);
        Assert.assertEquals(15, r.runquery("google", 654).get_score(), 0.0);
        Assert.assertEquals(0.0, r.runquery("google", 0).get_score(), 0.0);

        //becomes PhraseRanker
        r.setLinearWeight(0.0, 0.0, 1.0, 0.0);
        Assert.assertEquals(1.0, r.runquery("google", 454).get_score(), 0.0);
        Assert.assertEquals(0.0, r.runquery("google", 400).get_score(), 0.0);

        //becomes QL Ranker
        r.setLinearWeight(0.0, 1.0, 0.0, 0.0);
        Assert.assertEquals(Math.pow(2, -6.955055818590769), r.runquery("google", 639).get_score(), 0.0);
        Assert.assertEquals(Math.pow(2, -7.247731642282813), r.runquery("google", 0).get_score(), 0.0);


    }

}
