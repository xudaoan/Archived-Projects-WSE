# mvn -q exec:java -Dexec.mainClass="edu.nyu.cs.cs2580.Evaluator" -Dexec.args="data/qrels.tsv"
java -cp src edu.nyu.cs.cs2580.Evaluator data/qrels.tsv
