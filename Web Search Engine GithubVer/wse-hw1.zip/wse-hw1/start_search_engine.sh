touch results/hw1.4-log.tsv
./fix_permission.sh
java -cp src edu.nyu.cs.cs2580.SearchEngine 25811 data/corpus.tsv
