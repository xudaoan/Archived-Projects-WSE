./clean.sh
javac src/edu/nyu/cs/cs2580/*.java
./fix_permission.sh
