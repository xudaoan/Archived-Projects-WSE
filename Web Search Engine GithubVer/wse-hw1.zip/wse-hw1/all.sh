#mvn -q clean compile
result_dir="results"
#clean
rm `ls $result_dir/*.tsv| grep -v log`
while read line; do
  escaped=$(echo $line | sed -e 's/ /%20/g')
  echo "querying " $escaped
  ./query.sh $escaped cosine | ./eval.sh >> $result_dir/hw1.3-vsm.tsv
  ./query.sh $escaped QL | ./eval.sh >> $result_dir/hw1.3-ql.tsv
  ./query.sh $escaped phrase | ./eval.sh >> $result_dir/hw1.3-phrase.tsv
  ./query.sh $escaped numviews | ./eval.sh >> $result_dir/hw1.3-numviews.tsv
  ./query.sh $escaped linear | ./eval.sh >> $result_dir/hw1.3-linear.tsv

  ./query.sh $escaped cosine >> $result_dir/hw1.1-vsm.tsv
  ./query.sh $escaped QL >> $result_dir/hw1.1-ql.tsv
  ./query.sh $escaped phrase >> $result_dir/hw1.1-phrase.tsv
  ./query.sh $escaped numviews >> $result_dir/hw1.1-numviews.tsv
  ./query.sh $escaped linear >> $result_dir/hw1.2-linear.tsv
done < data/queries.tsv

./fix_permission.sh
