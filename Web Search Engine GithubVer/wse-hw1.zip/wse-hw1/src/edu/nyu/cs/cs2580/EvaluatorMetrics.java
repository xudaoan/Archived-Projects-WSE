package edu.nyu.cs.cs2580;

import java.util.*;

public class EvaluatorMetrics {
  public static int doubleCompare(double a, double b) {
    double tolerance = 0.000000001;
    if (a > b - tolerance && a < b + tolerance)
      return 0;

    return Double.compare(a, b);
  }

  private static TreeMap<Double, Double> recallPrecisionMap(Map<Integer, PrecisionRecallPair> rankStats) {
    TreeMap<Double, Double> rpMap = new TreeMap<Double, Double>();
    int size = rankStats.size();
    double previousRecall = -1.0;
    for (int i = 1; i < size + 1; i++) {
      Double recall = rankStats.get(i).recall;
      Double newPrecision = rankStats.get(i).precision;
      if (recall.compareTo(previousRecall) == 0)
        continue;
      rpMap.put(recall, newPrecision);
      previousRecall = recall;
    }
    return rpMap;
  }

  public static TreeMap<Double, Double> interpolatedRecallPrecisionMap(Map<Integer, PrecisionRecallPair> rankStats) {
    TreeMap<Double, Double> rpMap = recallPrecisionMap(rankStats);
    Double max = 0.0;
    Map.Entry<Double, Double> current = rpMap.lastEntry();
    TreeMap<Double, Double> newRPMap = new TreeMap<Double, Double>();

    while (current != null) {
      if (current.getValue() < max) {
        newRPMap.put(current.getKey(), max);
      } else {
        max = current.getValue();
        newRPMap.put(current.getKey(), current.getValue());
      }
      current = rpMap.lowerEntry(current.getKey());
    }
    return newRPMap;
  }

  public static double getInterpolatedPrecision(double recall, TreeMap<Double, Double> rpMap) {
    if (rpMap.containsKey(recall))
      return rpMap.get(recall).doubleValue();

    Map.Entry<Double, Double> tmp = rpMap.lowerEntry(recall);
    if (tmp != null && doubleCompare(recall, tmp.getKey()) == 0)
      return tmp.getValue();

    tmp = rpMap.higherEntry(recall);
    if (tmp == null)
      return rpMap.lastEntry().getValue();

    return tmp.getValue();
  }

  public static double averagePrecision(Map<Integer, PrecisionRecallPair> rankStats) {
    double count = 0.0;
    double sum = 0.0;
    for (Map.Entry<Integer, PrecisionRecallPair> thisEntry : rankStats.entrySet()) {
      if (thisEntry.getValue().gain > 2.0) {
        count += 1.0;
        sum += thisEntry.getValue().getPrecision();
      }
    }
    if (count == 0.0)
      return 0.0;
    return sum / count;
  }

  public static double fMearsure(double alpha, int index, Map<Integer, PrecisionRecallPair> rankStats) {
    if (Double.compare(alpha, 0.0) < 0 || Double.compare(alpha, 1.0) > 0)
      throw new ArithmeticException("Invalid alpha value");
    double recall = rankStats.get(index).recall;
    double precision = rankStats.get(index).precision;
    double denomitor = alpha * recall + (1.0 - alpha) * precision;
    if (denomitor == 0)
      return 0.0;
    return recall * precision / denomitor;
  }

  public static double reciprocalRank(Map<Integer, PrecisionRecallPair> rankStats) {
    int size = rankStats.size();
    for (int i = 1; i < size + 1; i++)
      if (rankStats.get(i).gain > 2.0)
        return 1.0 / (double) i;
    return 0.0;
  }

  private static double dcg(int K, Map<Integer, PrecisionRecallPair> rankStats) {
    double sum = rankStats.get(1).gain;
    for (int i = 2; i < K + 1; i++)
      sum = sum + rankStats.get(i).gain / (Math.log((double) i) / Math.log(2.0));
    return sum;
  }

  private static double idcg(int K, Map<Integer, PrecisionRecallPair> rankStats) {
    LinkedList<PrecisionRecallPair> best = new LinkedList<PrecisionRecallPair>(rankStats.values());
    Collections.sort(best, new Comparator<PrecisionRecallPair>() {
      public int compare(PrecisionRecallPair o1, PrecisionRecallPair o2) {
        return Double.compare(o2.gain, o1.gain);
      }
    });

    double sum = best.remove().gain;
    for (int i = 2; i < K + 1; i++)
      sum = sum + best.remove().gain / (Math.log((double) i) / Math.log(2.0));
    return sum;
  }

  public static double ndcg(int K, Map<Integer, PrecisionRecallPair> rankStats) {
    double idcgScore = idcg(K, rankStats);
    if(idcgScore==0.0)
      return 0.0;
    return dcg(K, rankStats) / idcgScore;
  }

}
