package edu.nyu.cs.cs2580;

class PrecisionRecallPair {
  double precision;
  double recall;
  double gain;

  PrecisionRecallPair(double precision, double recall, double gain) {
    this.precision = precision;
    this.recall = recall;
    this.gain = gain;
  }

  public double getGain() {
    return gain;
  }

  public void setGain(double gain) {
    this.gain = gain;
  }

  public double getPrecision() {
    return precision;
  }

  public void setPrecision(double precision) {
    this.precision = precision;
  }

  public double getRecall() {
    return recall;
  }

  public void setRecall(double recall) {
    this.recall = recall;
  }

}

