package edu.nyu.cs.cs2580;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

class Evaluator {

  public static void main(String[] args) throws IOException {
    HashMap<String, HashMap<Integer, Double>> relevance_judgments = new HashMap<String, HashMap<Integer, Double>>();
    if (args.length < 1) {
      System.out.println("need to provide relevance_judgments");
      return;
    }
    String p = args[0];
    // first read the relevance judgments into the HashMap
    readRelevanceJudgments(p, relevance_judgments);
    // now evaluate the results from stdin
    evaluateStdin(relevance_judgments);
  }

  public static void readRelevanceJudgments(String p, HashMap<String, HashMap<Integer, Double>> relevance_judgments) {
    try {
      BufferedReader reader = new BufferedReader(new FileReader(p));
      try {
        String line = null;
        while ((line = reader.readLine()) != null) {
          // parse the query,did,relevance line
          Scanner s = new Scanner(line).useDelimiter("\t");
          String query = s.next();
          int did = Integer.parseInt(s.next());
          String grade = s.next();
          double rel = 0.0;

          if (grade.equals("Perfect"))
            rel = 10.0;
          else if (grade.equals("Excellent"))
            rel = 7.0;
          else if (grade.equals("Good"))
            rel = 5.0;
          else if (grade.equals("Fair"))
            rel = 1.0;
          else if (grade.equals("Bad"))
            rel = 0.0;

          if (relevance_judgments.containsKey(query) == false) {
            HashMap<Integer, Double> qr = new HashMap<Integer, Double>();
            relevance_judgments.put(query, qr);
          }
          HashMap<Integer, Double> qr = relevance_judgments.get(query);
          qr.put(did, rel);
        }
      } finally {
        reader.close();
      }
    } catch (IOException ioe) {
      System.err.println("Oops " + ioe.getMessage());
    }
  }


  public static void evaluateStdin(HashMap<String, HashMap<Integer, Double>> relevance_judgments) {
    // only consider one query per call
    try {
      BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

      String line = null;
      double RR = 0.0;// relevant result
      Integer currentRank = 1;
      double N = 0.0;

      // for calculating precision
      HashMap<Integer, Integer> relDocNumber = new HashMap<Integer, Integer>();
      String query = null;// query should always be the same
      HashMap<Integer, PrecisionRecallPair> rankStats = new HashMap<Integer, PrecisionRecallPair>();
      while ((line = reader.readLine()) != null) {
        Scanner s = new Scanner(line).useDelimiter("\t");
        query = s.next();
        int did = Integer.parseInt(s.next());
        String title = s.next();
        double relevanceFromSearchEngine = Double.parseDouble(s.next());
        double totalNumberOfRelDocs = getNumberOfRelDocs(relevance_judgments, query);
        if (relevance_judgments.containsKey(query) == false) {
          throw new IOException("query not found");
        }
        HashMap<Integer, Double> relevanceGold = relevance_judgments.get(query);
        Integer currentRelCount = currentRank == 1 ? 0 : relDocNumber.get(currentRank - 1);

        double gain = 0.0;
        if (relevanceGold.containsKey(did) != false) {
          gain = relevanceGold.get(did);

          // doc in the current rank is relevant then increase relevant count
          if (isRelevant(relevanceGold.get(did))) {
            currentRelCount++;
          }
        }
        relDocNumber.put(currentRank, currentRelCount);
        double currentPrecision = currentRelCount / (double) currentRank;
        double currentRecall = currentRelCount / totalNumberOfRelDocs;
        if (totalNumberOfRelDocs == 0.0)
          currentRecall = 0.0;
        rankStats.put(currentRank, new PrecisionRecallPair(currentPrecision, currentRecall, gain));

        N++;
        currentRank++;
      }
      logStatistics(query, rankStats);
    } catch (Exception e) {
      e.printStackTrace();
      System.err.println("Error:" + e.getMessage());
    }
  }

  /**
   * if the relevance value is greater than 2 then return true
   * Perfect=10
   * Excellent=7
   * Good=4
   *
   * @param relNumber
   * @return
   */
  private static boolean isRelevant(Double relNumber) {
    if (relNumber == null)
      return false;
    if (relNumber > 2.0)
      return true;
    return false;
  }

  /**
   * print Statistics to stdout
   *
   * @param query
   * @param rankStats
   */
  private static void logStatistics(String query, HashMap<Integer, PrecisionRecallPair> rankStats) {
    String tab = "\t";

    String logLine = query;
    List<Double> metrics = new ArrayList<Double>();
    metrics.addAll(getClassicPrecisionAndRecall(rankStats));
    metrics.addAll(getFMeasure(rankStats));
    metrics.addAll(getInterpolatedPrecision(rankStats));
    metrics.add(getAveragePrecision(rankStats));
    metrics.addAll(getNDCG(rankStats));
    metrics.add(EvaluatorMetrics.reciprocalRank(rankStats));

    for (Double m : metrics) {
      logLine = logLine + tab + m;
    }

    System.out.println(logLine);


  }

  /**
   * given a query, return the number of documents that are relevant.
   * relevant document has a rel count that is greater than 2
   *
   * @param relevanceJudgments
   * @param query
   * @return
   */
  private static double getNumberOfRelDocs(HashMap<String, HashMap<Integer, Double>> relevanceJudgments, String query) {
    HashMap<Integer, Double> docJudgement = relevanceJudgments.get(query);
    double number = 0.0;
    for (Integer did : docJudgement.keySet()) {
      if (isRelevant(docJudgement.get(did)))
        number++;
    }
    return number;
  }

  /**
   * interpolated precision at 0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0
   *
   * @param rankStats
   * @return
   */
  private static List<Double> getInterpolatedPrecision(HashMap<Integer, PrecisionRecallPair> rankStats) {
    List<Double> result = new ArrayList<Double>();
    double[] recallPoints = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};
    TreeMap<Double, Double> interpolatedRPMap = EvaluatorMetrics.interpolatedRecallPrecisionMap(rankStats);
    for (double recallPoint : recallPoints) {
      double thevalue = EvaluatorMetrics.getInterpolatedPrecision(recallPoint, interpolatedRPMap);
      result.add(thevalue);
    }
    return result;
  }

  private static double getAveragePrecision(HashMap<Integer, PrecisionRecallPair> rankStats) {
    double thevalue = EvaluatorMetrics.averagePrecision(rankStats);
    return thevalue;
  }

  private static List<Double> getFMeasure(HashMap<Integer, PrecisionRecallPair> rankStats) {
    List<Double> result = new ArrayList<Double>();
    int[] ranks = {1, 5, 10};
    for (int rank : ranks) {
      double thevalue = EvaluatorMetrics.fMearsure(0.5, rank, rankStats);
      result.add(thevalue);
    }
    return result;
  }

  private static List<Double> getNDCG(HashMap<Integer, PrecisionRecallPair> rankStats) {
    List<Double> result = new ArrayList<Double>();
    int[] ranks = {1, 5, 10};
    for (int rank : ranks) {
      double thevalue = EvaluatorMetrics.ndcg(rank, rankStats);
      result.add(thevalue);
    }
    return result;
  }

  private static List<Double> getClassicPrecisionAndRecall(HashMap<Integer, PrecisionRecallPair> rankStats) {
    List<Double> result = new ArrayList<Double>();
    // print precision at 1,5,10
    int[] ranks = {1, 5, 10};
    for (int rank : ranks) {
      result.add(rankStats.get(rank).getPrecision());
    }
    for (int rank : ranks) {
      result.add(rankStats.get(rank).getRecall());
    }
    return result;
  }

}