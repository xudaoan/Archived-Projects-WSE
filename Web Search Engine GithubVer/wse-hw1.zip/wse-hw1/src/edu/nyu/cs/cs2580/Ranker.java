package edu.nyu.cs.cs2580;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Vector;

class Ranker {
  public enum SignalType {
    COSINE, QUERYLIKELYHOOD, PHRASE, NUMVIEWS, LINEAR, NAIVE
  }

  SignalType signalType = SignalType.NAIVE;//default to NAIVE

  public Index _index;
  double weightOfCosine = 0.25;
  double weightOfQL = 0.25 * 15.0;
  double weightOfPhrase = 0.25 * 0.015;
  double weightOfNumviews = 0.25 * 0.00001;
  double JMSmoothingLambda = 0.5;

  //small value(0.1) work well for short queries, bigger value work well for longer quries
  public void setJMSmoothingLambda(double JMSmoothingLambda) {
    this.JMSmoothingLambda = JMSmoothingLambda;
  }

  public Index getIndex() {
    return _index;
  }

  public void setLinearWeight(double weightOfCosine, double weightOfQL, double weightOfPhrase, double weightOfNumviews) {
    if (weightOfCosine + weightOfQL + weightOfPhrase + weightOfNumviews != 1.0)
      throw new RuntimeException("weights do not sum to 1");
    this.weightOfCosine = weightOfCosine;
    this.weightOfQL = weightOfQL;
    this.weightOfPhrase = weightOfPhrase;
    this.weightOfNumviews = weightOfNumviews;
  }


  public Ranker(String index_source) {
    _index = new Index(index_source);
  }


  private double log2(double x) {
    return Math.log(x) / Math.log(2);
  }

  private double getInverseDocumentFrequency(String word) {
    double d_k = _index.documentFrequency(word);//number of documents containing the word
    double n = _index.numDocs();//totol number of docs
    return 1 + log2(n / d_k);//use the formular in class -> Homework 1 FAQ
  }

  private double dotProduct(Counter<String> weightedDocumentVector, Counter<String> weightedQueryVector) {
    //only compute for intersection
    //iterate through shorter list-> query
    double result = 0.0;
    for (String word : weightedQueryVector.keySet()) {
      result += weightedDocumentVector.getCount(word) * weightedQueryVector.getCount(word);
    }
    return result;
  }

  public Vector<ScoredDocument> runquery(String query) {
    Vector<ScoredDocument> retrieval_results = new Vector<ScoredDocument>();
    for (int i = 0; i < _index.numDocs(); ++i) {
      retrieval_results.add(runquery(query, i));
    }
    return retrieval_results;
  }


  public ScoredDocument runquery(String query, int did) {
    Document d = _index.getDoc(did);

    double score = 0.0;
    switch (this.signalType) {
      case COSINE:
        score = generateCosineScore(query, d);
        break;
      case QUERYLIKELYHOOD:
        score = generateQueryLikelyhoodScore(query, d);
        break;
      case PHRASE:
        score = generatePhraseScore(query, d);
        break;
      case NUMVIEWS:
        score = generateNumviewsScore(query, d);
        break;
      case LINEAR:
        score = generateLinearScore(query, d);
        break;
      case NAIVE:
        score = generateNaiveScore(query, d);
    }


    return new ScoredDocument(did, d.get_title_string(), score);
  }

  private double generateLinearScore(String query, Document d) {


    double cosineScore = generateCosineScore(query, d);
    double qlScore = generateQueryLikelyhoodScore(query, d);
    double phraseScore = generatePhraseScore(query, d);
    double numviewsScore = generateNumviewsScore(query, d);
//    System.out.println("cos:" + cosineScore + " ql:" + qlScore + " phrase:" + phraseScore + " numviews:" + numviewsScore);
    return cosineScore * weightOfCosine
            + qlScore * weightOfQL
            + phraseScore * weightOfPhrase
            + numviewsScore * weightOfNumviews;


  }

  private double generateNumviewsScore(String query, Document d) {
    return d.get_numviews();  //To change body of created methods use File | Settings | File Templates.
  }

  //count number of bigrams occur both in query and document
  double generatePhraseScore(String query, Document d) {
    Vector<String> queryVector = getQueryVector(query);
    HashSet<String> bigramsInQuery = getBigrams(queryVector);

    double score = 0.0;
    Vector<String> bodyVector = d.get_body_vector();
    Vector<String> titleVector = d.get_title_vector();
    Vector<String> contentVector = new Vector<String>();
    contentVector.addAll(bodyVector);
    contentVector.addAll(titleVector);
    //bigrams may contain only one word, then only use unigram matching
    if (queryVector.size() == 1) {
//      for (int i = 0; i < contentVector.size(); i++) {
//        if (bigramsInQuery.contains(contentVector.get(i)))
//          score++;
//      }
//      return score;
      return 0.0;
    }

    //bigram in body
    for (int i = 0; i < bodyVector.size() - 1; i++) {
      String currentBigram = bodyVector.get(i) + "_" + bodyVector.get(i + 1);
      if (bigramsInQuery.contains(currentBigram))
        score++;
    }

    //bigram in title
    for (int i = 0; i < titleVector.size() - 1; i++) {
      String currentBigram = titleVector.get(i) + "_" + titleVector.get(i + 1);
      if (bigramsInQuery.contains(currentBigram))
        score++;
    }

    return score;  //To change body of created methods use File | Settings | File Templates.
  }

  private Vector<String> getQueryVector(String query) {
    Scanner s = new Scanner(query);
    Vector<String> queryVector = new Vector<String>();
    while (s.hasNext()) {
      String term = s.next();
      queryVector.add(term);
    }
    return queryVector;
  }

  private HashSet<String> getBigrams(Vector<String> queryVector) {
    HashSet<String> bigrams = new HashSet<String>();


    if (queryVector.size() == 0)
      throw new RuntimeException("query vector is empty");

    if (queryVector.size() == 1) {
      bigrams.add(queryVector.firstElement());
      return bigrams;
    }

    for (int i = 0; i < queryVector.size() - 1; i++) {
      bigrams.add(queryVector.get(i) + "_" + queryVector.get(i + 1));
    }


    return bigrams;  //To change body of created methods use File | Settings | File Templates.
  }

  //queryLikelyHood is a negative number, but the final result is a summation over all scores, so doesn't matter
  private double generateQueryLikelyhoodScore(String query, Document d) {
    // Build query vector
    Scanner s = new Scanner(query);
    Vector<String> queryVector = new Vector<String>();
    while (s.hasNext()) {
      String term = s.next();
      queryVector.add(term);
    }

    // Get the document vector. For hw1, you don't have to worry about the
    // details of how index works.
    Vector<String> contentVector = new Vector<String>();
    contentVector.addAll(d.get_body_vector());
    contentVector.addAll(d.get_title_vector());

    Counter<String> documentWordCounter = new Counter<String>();
    for (String bodyWord : contentVector) {
      documentWordCounter.incrementCount(bodyWord, 1.0);
    }

    double lambda = JMSmoothingLambda;

    double score = 0.0;
    for (String queryWord : queryVector) {
      //calculate word frequency in a document which is fqi,D/|D|, |D| is the number of words in document
      double likeliHoodInDocument = documentWordCounter.getCount(queryWord) / documentWordCounter.totalCount();
      //calculate word frequency in the collection which is Cqi/|C|
      double likeliHoodInCollection = ((double) _index.termFrequency(queryWord)) / ((double) _index.termFrequency());
      score += Math.log((1 - lambda) * likeliHoodInDocument + lambda * likeliHoodInCollection);

    }

    return Math.pow(2, score);  //To change body of created methods use File | Settings | File Templates.
  }

  private double generateCosineScore(String query, Document d) {


    // Build query vector
    Scanner s = new Scanner(query);
    Vector<String> queryVector = new Vector<String>();
    while (s.hasNext()) {
      String term = s.next();
      queryVector.add(term);
    }
    // Get the document vector. For hw1, you don't have to worry about the
    // details of how index works.
    Vector<String> contentVector = new Vector<String>();
    contentVector.addAll(d.get_body_vector());
    contentVector.addAll(d.get_title_vector());

    //1. weighted document vector for document
    Counter<String> documentBodyTermFrequency = new Counter<String>();
    Counter<String> weightedDocumentVector = new Counter<String>();

    for (String word : contentVector) {
      documentBodyTermFrequency.incrementCount(word, 1.0);
    }//not plus one for term frequency

    for (String word : documentBodyTermFrequency.keySet()) {
      double v = documentBodyTermFrequency.getCount(word) * getInverseDocumentFrequency(word);
      weightedDocumentVector.setCount(word, v);
    }

    weightedDocumentVector.normalizeByLength();

    //2. weighted document vector for query
    Counter<String> queryBodyTermFrequency = new Counter<String>();
    Counter<String> weightedQueryVector = new Counter<String>();

    for (String word : queryVector) {
      queryBodyTermFrequency.incrementCount(word, 1.0);
    }

    for (String word : queryBodyTermFrequency.keySet()) {
      double v = queryBodyTermFrequency.getCount(word) * getInverseDocumentFrequency(word);
      weightedQueryVector.setCount(word, v);
    }
    weightedQueryVector.normalizeByLength();

    double score = dotProduct(weightedDocumentVector, weightedQueryVector);
    return score;
  }

  private double generateNaiveScore(String query, Document document) {
    // Build query vector
    Scanner s = new Scanner(query);
    Vector<String> qv = new Vector<String>();
    while (s.hasNext()) {
      String term = s.next();
      qv.add(term);
    }

    // Get the document vector. For hw1, you don't have to worry about the
    // details of how index works.

    Vector<String> dv = document.get_title_vector();

    // Score the document. Here we have provided a very simple ranking model,
    // where a document is scored 1.0 if it gets hit by at least one query term.
    double score = 0.0;
    for (int i = 0; i < dv.size(); ++i) {
      for (int j = 0; j < qv.size(); ++j) {
        if (dv.get(i).equals(qv.get(j))) {
          score = 1.0;
          break;
        }
      }
    }
    System.out.println("naive score is " + score);
    return score;  //To change body of created methods use File | Settings | File Templates.
  }

  public void setSignalType(SignalType type) {
    this.signalType = type;
  }
}
