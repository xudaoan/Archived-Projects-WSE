package edu.nyu.cs.cs2580;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.util.*;

public class QueryHandler implements HttpHandler {
  private static String plainResponse =
          "Request received, but I am not smart enough to echo yet!\n";

  private Ranker _ranker;
  private static final String logPath = "results/hw1.4-log.tsv";
  private PrintWriter logWriter;

  public QueryHandler(Ranker ranker) throws IOException {
    _ranker = ranker;
    logWriter = new PrintWriter(new BufferedWriter(new FileWriter(logPath, true)));
  }

  @Override
  protected void finalize() throws Throwable {
    super.finalize();    //To change body of overridden methods use File | Settings | File Templates.
    logWriter.close();
  }

  public static Map<String, String> getQueryMap(String query) {
    String[] params = query.split("&");
    Map<String, String> map = new HashMap<String, String>();
    for (String param : params) {
      String name = param.split("=")[0];
      String value = param.split("=")[1];
      map.put(name, value);
    }
    return map;
  }

  public void handle(HttpExchange exchange) throws IOException {
    boolean renderHtml = false;
    String requestMethod = exchange.getRequestMethod();
    if (!requestMethod.equalsIgnoreCase("GET")) {  // GET requests only.
      return;
    }

    // Print the user request header.
    Headers requestHeaders = exchange.getRequestHeaders();
    System.out.println("Incoming request: ");
    for (String key : requestHeaders.keySet()) {
      System.out.print(key + ":" + requestHeaders.get(key) + "; ");
    }
    //TODO: if no sessionID then should generate one
    String sessionId = null;
    if (requestHeaders.containsKey("Cookie")) {
      for (String cookieStr : requestHeaders.get("Cookie")) {
        System.out.println(cookieStr);
        String[] pair = cookieStr.split("=");
        String key = pair[0];
        String value = pair[1];
        if ("session_id".equals(key))
          sessionId = value;
      }
    }


    System.out.println();
    String queryResponse = "";
    String uriQuery = exchange.getRequestURI().getQuery();
    String uriPath = exchange.getRequestURI().getPath();

    if ((uriPath != null) && (uriQuery != null)) {

      Map<String, String> query_map = getQueryMap(uriQuery);
      Set<String> keys = query_map.keySet();
      if ("html".equals(query_map.get("format")))
        renderHtml = true;
      //manually set sessionId through query params
      if (keys.contains("sessionId"))
        sessionId = query_map.get("sessionId");

      if (sessionId == null)
        sessionId = generateSessionId();

      if (renderHtml)
        exchange.getResponseHeaders().set("Set-Cookie", "session_id=" + sessionId);
      if (uriPath.equals("/search")) {

        if (keys.contains("query")) {
          //deal with space separated words
          if (keys.contains("ranker")) {
            String ranker_type = query_map.get("ranker");
            // @CS2580: Invoke different ranking functions inside your
            // implementation of the Ranker class.
            if (ranker_type.equals("cosine")) {
              _ranker.setSignalType(Ranker.SignalType.COSINE);
            } else if (ranker_type.equals("QL")) {
              _ranker.setSignalType(Ranker.SignalType.QUERYLIKELYHOOD);
            } else if (ranker_type.equals("phrase")) {
              _ranker.setSignalType(Ranker.SignalType.PHRASE);
            } else if (ranker_type.equals("numviews")) {
              _ranker.setSignalType(Ranker.SignalType.NUMVIEWS);
            } else if (ranker_type.equals("linear")) {
              _ranker.setSignalType(Ranker.SignalType.LINEAR);
            } else {
              System.out.println("using default stupid ranker");
            }
          }


          // @CS2580: The following is instructor's simple ranker that does not
          // use the Ranker class.
          Vector<ScoredDocument> scoredDocumentVector = _ranker.runquery(query_map.get("query"));
          Collections.sort(scoredDocumentVector);
          //accquired document is revert sorted
          Iterator<ScoredDocument> itr = new Reversed<ScoredDocument>(scoredDocumentVector).iterator();
          ScoredDocument bestResult = null;
          double maxScore = -Double.MAX_VALUE;
          System.out.println(maxScore);
          while (itr.hasNext()) {
            ScoredDocument sd = itr.next();
            if (queryResponse.length() > 0) {
              queryResponse = queryResponse + "\n";
            }
            if (sd.get_score() > maxScore) {
              bestResult = sd;
              maxScore = sd.get_score();
            }
            String query = query_map.get("query");


            if (renderHtml) {
              String clickUrl = "/click?docId=" + sd.get_did() + "&query=" + query;
              queryResponse = queryResponse + "<div>" + query + "\t" + "<a href='" + clickUrl + "'>" + sd.asString() + "</a>" + "</div>";
            } else {
              queryResponse = queryResponse + query_map.get("query") + "\t" + sd.asString();
            }
            //search logging
            String action = "render";
            String time = Calendar.getInstance().getTime().toString();
            String documentId = new Integer(sd.get_did()).toString();
            logUserInteraction(sessionId, query, action, time, documentId);
          }

          if (queryResponse.length() > 0) {
            queryResponse = queryResponse + "\n";
          }

        }
      } else if (uriPath.equals("/click")) {
        //click logging
        String query = query_map.get("query");
        String action = "click";
        String time = Calendar.getInstance().getTime().toString();
        String documentId = query_map.get("docId");
        logUserInteraction(sessionId, query, action, time, documentId);
        Document doc = _ranker.getIndex().getDoc(Integer.parseInt(documentId));
        String content = "<h1>" + doc.get_title_string() + "</h1>" + "<p>" + doc.getContent() + "</p>";
        renderHtmlResponse(exchange, content);
      }
    }

    // Construct a simple response.
    if (renderHtml) {
      renderHtmlResponse(exchange, queryResponse);
    } else {
      renderTextResponse(exchange, queryResponse);
    }

  }

  private String generateSessionId() {

    String s = UUID.randomUUID().toString();
    System.out.println("\ngenerating new SessionID: " + s);
    return s;  //To change body of created methods use File | Settings | File Templates.
  }

  private void renderTextResponse(HttpExchange exchange, String queryResponse) throws IOException {
    Headers responseHeaders = exchange.getResponseHeaders();
    responseHeaders.set("Content-Type", "text/plain");
    exchange.sendResponseHeaders(200, 0);  // arbitrary number of bytes
    OutputStream responseBody = exchange.getResponseBody();
    responseBody.write(queryResponse.getBytes());
    responseBody.close();
  }

  private void renderHtmlResponse(HttpExchange exchange, String queryResponse) throws IOException {
    String responseContent = "<html>"
            + "<head>"
            + "<title>SearchEngine from Group11</title>"
            + "</head>"
            + "<body>";
    responseContent += queryResponse;
    responseContent += "</body></html>";

    Headers responseHeaders = exchange.getResponseHeaders();
    responseHeaders.set("Content-Type", "text/html");
    exchange.sendResponseHeaders(200, 0);  // arbitrary number of bytes
    OutputStream responseBody = exchange.getResponseBody();
    responseBody.write(responseContent.getBytes());
    responseBody.close();
  }

  private void logUserInteraction(String sessionId, String query, String action, String time, String documentId) {
    String sep = "\t";
    String logLine = sessionId + sep + query + sep + documentId + sep + action + sep + time;
    logWriter.println(logLine);
    logWriter.flush();
  }
}

class Reversed<T> implements Iterable<T> {
  private final List<T> original;

  public Reversed(List<T> original) {
    this.original = original;
  }

  public Iterator<T> iterator() {
    final ListIterator<T> i = original.listIterator(original.size());

    return new Iterator<T>() {
      public boolean hasNext() {
        return i.hasPrevious();
      }

      public T next() {
        return i.previous();
      }

      public void remove() {
        i.remove();
      }
    };
  }

  public static <T> Reversed<T> reversed(List<T> original) {
    return new Reversed<T>(original);
  }
}
