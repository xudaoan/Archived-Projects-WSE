pid=`ps aux| grep java | grep 25811 |grep -v grep | awk '{print $2}'`
if [[ ! $pid ]]; then
    echo "no such process"
    exit 1
fi

kill -9 $pid
