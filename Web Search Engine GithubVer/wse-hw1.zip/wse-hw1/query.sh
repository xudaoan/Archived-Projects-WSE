if [[ $# -ne 2 ]]; then
    echo "usage: ./query.sh [query] [cosine|QL|linear|phrase|numviews] 
cosine means vector space model where cosine value is used as similarity metric
QL means Query Likelyhood Model
linear means Simple Linear Model
phrase means Bigram Phrase Ranker
numviews means using number of views of a document as ranking signal
Example:
	./query.sh bing cosine
	./query.sh data%20mining QL"
    exit 1
fi
curl -s "http://localhost:25811/search?query=$1&ranker=$2&format=text&sessionId=123"
