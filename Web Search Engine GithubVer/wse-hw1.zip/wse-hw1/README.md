Web Search Engine Homework 1
============================

This is the homework1 from group11
-----------------------------
All the Results are put in the folder results.
To get result, run the following scripts using following commands:
./compile.sh                ## compile the code (section 1)
./start_search_engine.sh &  ## start the search engine (section 2.1)
./all.sh                    ## Regenerate all resulting files (section 2.2)

For Bonous part Through Browser (Click Logging)
please read "2.3.2 Click Logging"

after everything is done, use script
./stop_search_engin.sh      ## to stop the service

For other optional operations, please reference everything below

1. Compile
----------
Run compile.sh will compile the java classes. Make sure you compile the program before running i
	./compile.sh
	
2. Run the program
------------------
Before running any query, please make sure the search engine is already started

### 2.1 Start Search Engine
Run following command will start the search engine on port *25811*
	./start_search_engine.sh
run ./stop_search_engine.sh to stop it	
	
### 2.2 Re-generate all resulting files
all.sh generates following files by running queries and evaluations against words listed in data/queries.tsv. Notice that files in the results folder will be *deleted* and then *re-generated*
	./all.sh
Before running this script, please make sure you have started the search engine, the resulting files are put into result directory:

- hw1.1-vsm.tsv: query result for vector space model
- hw1.1-ql.tsv: query result using Query Likely Hood signal wher lambda = 0.5
- hw1.1-phrase.tsv: query result using phrase-based ranker
- hw1.1-numviews.tsv: query result using numviews as signal

- hw1.2-linear.tsv: query result using linear model
  Beta_Cosine = 0.25;
  Beta_QL = 0.25 * 15.0;
  Beta_Phrase = 0.25 * 0.015;
  Beta_Numviews = 0.25 * 0.00001;
  These beta values are set to change the weight of different ranking scores.
  Using these bata values, the adjusted weights are apporixmiately:
  (1.1~1.3) : (0.9~1.2) : (0 or 0.7~0.9) : (0.01 ~ 0.06)


- hw1.3-vsm.tsv: evaluation result for vector space model
- hw1.3-ql.tsv: evaluation result for Query Likely Hood Signal
- hw1.3-phrase.tsv: evaluation result for phrase-based ranker
- hw1.3-numviews.tsv: evaluation result using numviews as signal
- hw1.3-linear.tsv: evaluation result using linear model when Beta_cosine= *TODO*



### 2.3 Query
Following sections explains how to manually send a query and inspect the result
#### 2.3.1 Through Command Line(Text request)
Run ./query.sh without argument will show you the usage of the script
	./query.sh
To send a query, *keyword* and *RankingSignal* should be specified as follows
	./query.sh [query] [cosine|QL|linear|phrase|numviews]
An example is as follows
	./query.sh bing cosine
The output is like the following where the result is revert sorted by their relevance:
	bing	52	bing	0.8031299845645744
	bing	354	msn search	0.8019491873850855
	bing	344	live search	0.8019104277081214
	bing	98	comparison of web search engines	0.21493880115448472

#### 2.3.2 Bonus Part: Through Browser (Click Logging)
We implemented user tracking by the most common way which is to append Set-Cookie instruction as the header for each response. So if you open the search engine through a browser, the program would be able to track the entire session, as long as you don't close the browser, all the interactions will be attached to a unique session_id

Visit the following url in the browser to render the HTML page
	http://localhost:25811/search?query=bing&ranker=phrase&format=html
	
*Notice* 
- the format parameter is set to html to render the page correctly
- if the search consists multiple words, please use %20 to replace space in the url, e.g.
	http://localhost:25811/search?query=data%20mining&ranker=phrase&format=html
	
Then click on one of the result, the clicking will be logged to hw1.4-log.tsv, and the browser will be redirect to a page showing the content of the article e.g.:
	http://localhost:25811/click?docId=40&query=data%20mining

##### User log
While browsing the page through browser, hw1.4-log.tsv will record user interaction in the format of following:
	4189a192-4ad3-4176-a296-11de54493142	data mining	0	render	Wed Feb 27 11:58:16 EST 2013
	4189a192-4ad3-4176-a296-11de54493142	data mining	40	click	Wed Feb 27 11:59:39 EST 2013   

### 2.4 Evaluation
To show evaluation of a specific query, run:
	./query.sh [query] [signal_type] | ./eval.sh
	./query.sh bing QL | ./eval.sh 
Notice that multiple words in the query should be separated by %20
As mentioned in the home work requirement, evaluation result are reperesented in following format
	<query>	<precision@1>	<precision@5>	<precision@10>	<recall@1>	<recall@5>	<recall@10>	<fscore@1>	<fscore@5>	<fscore@10>	<precision@recall0.0>	<precision@recall0.1>	<precision@recall0.2>	<precision@recall0.3>	<precision@recall0.4>	<precision@recall0.5>	<precision@recall0.6>	<precision@recall0.7>	<precision@recall0.8>	<precision@recall0.9>	<precision@recall1.0>	<averagePrecision>	<NDCG@1>	<NDCG@5>	<NDCG@10>	<ReciprocalRank>

