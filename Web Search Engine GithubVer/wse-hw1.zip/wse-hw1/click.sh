if [[ $# -ne 2 ]]; then
    echo "usage: click.sh [docId] [queryTerm]"
    exit 1
fi
curl -s "http://localhost:25811/click?docId=$1&query=$2&sessionId=123"
